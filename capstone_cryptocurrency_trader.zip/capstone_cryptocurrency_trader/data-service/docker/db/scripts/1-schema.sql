CREATE TABLE IF NOT EXISTS cryptocurrencies(
  id INTEGER PRIMARY KEY,
  name VARCHAR NOT NULL
);

CREATE TABLE IF NOT EXISTS markets(
  id INTEGER PRIMARY KEY,
  owner_name VARCHAR NOT NULL,
  market_url TEXT,
  buying_crypto_id INT NOT NULL REFERENCES cryptocurrencies(id),
  selling_crypto_id INT NOT NULL REFERENCES cryptocurrencies(id)
);

CREATE TABLE IF NOT EXISTS historical_data(
  id INTEGER PRIMARY KEY,
  buy_value DECIMAL NOT NULL,
  sell_value DECIMAL NOT NULL,
  date DATE NOT NULL,
  fk_historical_data_on_cryptocurrencies INT NOT NULL REFERENCES cryptocurrencies(id)
);