
# Data Service

This submodule of the Cryptocurrency Trading project is responsible for managing cryptocurrency details, including their name, sell value, and buy value.

![Docker](https://img.shields.io/badge/docker-%230db7ed.svg?style=for-the-badge&logo=docker&logoColor=white)
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![Postgres](https://img.shields.io/badge/postgres-%23316192.svg?style=for-the-badge&logo=postgresql&logoColor=white)

## Deployment
This project is using docker to run database on it.

To deploy this project run docker-compose initializing PostgreSQL database

```docker
  docker compose -p project up -d
```

## Authors
This domain was implemented by [@lkawa](https://www.github.com/lkawa).

