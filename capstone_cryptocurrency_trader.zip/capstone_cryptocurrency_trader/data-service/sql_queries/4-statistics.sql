-- fetch cryptocurrencies and count of historical data for it
SELECT cryptocurrencies.name, HD.historical_data_count
FROM cryptocurrencies
JOIN
(
  	SELECT historical_data.fk_historical_data_on_cryptocurrencies AS crypto_fk, COUNT(*) as historical_data_count
	FROM historical_data
	GROUP BY crypto_fk
  ) AS HD ON cryptocurrencies.id = HD.crypto_fk