-- At least one full CRUD set of queries for your domain entity

-- CREATE
INSERT INTO cryptocurrencies (id, name) VALUES (1, 'Bitcoin');
INSERT INTO markets (id, owner_name, buying_crypto_id, selling_crypto_id) VALUES (1, 'John', 1, 2);
INSERT INTO historical_data (id, buy_value, sell_value, date, fk_historical_data_on_cryptocurrencies)
VALUES (1, 589.23, 601.45, '2023-01-01', 1); 

-- READ
SELECT * 
FROM  historical_data 
WHERE fk_historical_data_on_cryptocurrencies = 1;

-- UPDATE
UPDATE historical_data
SET buy_value = buy_value + 1
WHERE id = 1;

-- DELETE
DELETE FROM historical_data
WHERE fk_historical_data_on_cryptocurrencies = 1;