-- Cover all your use-cases implemented in OOD module using pure Java

-- find(Long id)
SELECT *
FROM historical_data
WHERE id = 1;

-- save(HistoricalData)
INSERT INTO historical_data (id, buy_value, sell_value, date, fk_historical_data_on_cryptocurrencies)
VALUES (1, 321.32, 316.12, '2024-02-20', 1);

-- delete
DELETE FROM historical_data
WHERE id = 1;

-- findAll(String cryptocurrencyName)
SELECT *
FROM historical_data
JOIN cryptocurrencies ON cryptocurrencies.id = historical_data.fk_historical_data_on_cryptocurrencies
WHERE cryptocurrencies.name = 'Bitcoin'