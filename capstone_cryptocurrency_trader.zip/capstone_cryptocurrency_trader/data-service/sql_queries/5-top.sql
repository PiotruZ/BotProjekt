-- fetch top 5 cryptocurrencies with most markets
SELECT cryptocurrencies.name, MC.markets_count
FROM cryptocurrencies
JOIN (SELECT markets.buying_crypto_id, COUNT(*) as markets_count
     	FROM markets
		GROUP BY markets.buying_crypto_id
     	ORDER BY markets_count DESC
     	LIMIT 5) 
AS MC ON MC.buying_crypto_id = cryptocurrencies.id
