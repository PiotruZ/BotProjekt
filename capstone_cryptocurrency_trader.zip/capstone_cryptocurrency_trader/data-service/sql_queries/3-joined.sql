/* fetch markets owners names with its selling and buying cryptocurrency names  */
SELECT owner_name, buying_crypto.name, selling_crypto.name
FROM markets
JOIN cryptocurrencies AS buying_crypto ON buying_crypto.id = markets.buying_crypto_id
JOIN cryptocurrencies AS selling_crypto ON selling_crypto.id = markets.selling_crypto_id
