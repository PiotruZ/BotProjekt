-- Search query with dynamic filters, pagination and sorting

-- page_num  = 3
-- page_size = 5

SELECT * 
FROM historical_data 
ORDER BY id 
OFFSET ((5 - 1) * 3)    -- ((page_size - 1) * page_num) 
ROWS FETCH NEXT 5 ROWS ONLY;    -- page_size
