package capstone.gd.cryptocurrency.service;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrenciesResponse;
import capstone.gd.cryptocurrency.repository.interfaces.CryptocurrencyRepository;
import net.bytebuddy.asm.Advice;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.swing.text.html.Option;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CryptocurrencyServiceImplTest {

    private static final Long ID = 1L;

    @Mock
    CryptocurrencyRepository repository;

    @InjectMocks
    CryptocurrencyServiceImpl service;

    @Test
    void findTest() {
        // given
        Cryptocurrency crypto = Cryptocurrency.builder().build();
        when(repository.find(ID)).thenReturn(Optional.of(crypto));

        // then
        assertTrue(service.find(ID).equals(Optional.of(crypto)));
        verify(repository).find(ID);
    }

    @Test
    void createTest() {
        // given
        Cryptocurrency crypto = Cryptocurrency.builder().build();
        when(repository.save(crypto)).thenReturn(crypto);

        // then
        assertTrue(service.create(crypto).equals(crypto));
        verify(repository).save(crypto);
    }

    @Test
    void updateTest() {
        // given
        Cryptocurrency crypto = Cryptocurrency.builder().build();

        // when
        service.update(crypto);

        // then
        verify(repository).save(crypto);
    }

    @Test
    void delete() {
        // given
        Cryptocurrency crypto = Cryptocurrency.builder().build();

        // when
        service.update(crypto);

        // then
        verify(repository).delete(crypto);
    }

    @Test
    void findAllTest() {
        // given
        List<Cryptocurrency> cryptocurrencies = List.of(Cryptocurrency.builder().build());
        when(repository.findAll()).thenReturn(cryptocurrencies);

        // then
        assertTrue(service.findAll().equals(cryptocurrencies));
        verify(repository).findAll();
    }

    @Test
    void findAllByDateTest() {
        // given
        List<Cryptocurrency> cryptocurrencies = List.of(Cryptocurrency.builder().build());
        LocalDate date = LocalDate.now();
        when(repository.findAllByDate(date)).thenReturn(cryptocurrencies);

        // then
        assertTrue(service.findAll(date).equals(cryptocurrencies));
        verify(repository).findAllByDate(date);
    }

    @Test
    void findAllByCryptocurrencyNameTest() {
        // given
        List<Cryptocurrency> cryptocurrencies = List.of(Cryptocurrency.builder().build());
        String name = "Bitcoin";
        when(repository.findAllByName(name)).thenReturn(cryptocurrencies);

        // then
        assertTrue(service.findAll(name).equals(cryptocurrencies));
        verify(repository).findAllByName(name);
    }

    @Test
    void findAllByCryptocurrencyNameAndDateTest() {
        // given
        String name = "Bitcoin";
        LocalDate date = LocalDate.now();
        Cryptocurrency crypto = Cryptocurrency.builder()
                .date(date)
                .name(name)
                .build();
        List<Cryptocurrency> cryptocurrencies = List.of(crypto);
        when(repository.findAllByName(name)).thenReturn(cryptocurrencies);

        // then
        assertTrue(service.findAll(name, date).equals(cryptocurrencies));
        verify(repository).findAllByName(name);
    }

    @Test
    void findAllByFilterObjectTest() {
        // given
        String name = "Bitcoin";
        LocalDate date = LocalDate.now();
        Cryptocurrency crypto = Cryptocurrency.builder()
                .date(date)
                .name(name)
                .build();
        List<Cryptocurrency> cryptocurrencies = List.of(crypto);
        when(repository.findAll(crypto)).thenReturn(cryptocurrencies);

        // then
        assertTrue(service.findAll(crypto).equals(cryptocurrencies));
        verify(repository).findAll(crypto);
    }
}