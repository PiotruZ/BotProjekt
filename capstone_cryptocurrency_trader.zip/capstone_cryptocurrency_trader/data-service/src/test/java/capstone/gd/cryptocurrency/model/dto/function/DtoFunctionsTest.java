package capstone.gd.cryptocurrency.model.dto.function;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.CreateCryptocurrencyRequest;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrenciesResponse;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrencyResponse;
import capstone.gd.cryptocurrency.model.dto.UpdateCryptocurrencyRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DtoFunctionsTest {

    public static final Long ID = 1L;
    public static final String CRYPTO_NAME = "bitcoin";
    public static final BigDecimal SELL_VALUE = BigDecimal.valueOf(100_000);
    public static final BigDecimal BUY_VALUE = BigDecimal.valueOf(120_000);
    public static final LocalDate DATE = LocalDate.now();

    Cryptocurrency cryptocurrency;

    @BeforeEach
    void setUp(){
        cryptocurrency = new Cryptocurrency(ID, CRYPTO_NAME, SELL_VALUE, BUY_VALUE, DATE);
    }

    @Test
    void cryptocurrencyToResponseFunctionTest() {
        GetCryptocurrencyResponse response = new CryptocurrencyToResponseFunction().apply(cryptocurrency);
        assertEquals(response.getId(), cryptocurrency.getId());
        assertEquals(response.getName(), cryptocurrency.getName());
        assertEquals(response.getDate(), cryptocurrency.getDate());
        assertEquals(response.getBuyValue(), cryptocurrency.getBuyValue());
        assertEquals(response.getSellValue(), cryptocurrency.getSellValue());
    }

    @Test
    void cryptocurrenciesToResponseFunctionTest() {
        List<Cryptocurrency> cryptocurrencies = List.of(cryptocurrency);
        GetCryptocurrenciesResponse response = new CryptocurrenciesToResponseFunction().apply(cryptocurrencies);
        Optional<GetCryptocurrenciesResponse.Cryptocurrency> responseCryptoOptional = response.getCryptocurrencies().stream().findFirst();
        assertTrue(responseCryptoOptional.isPresent());
        GetCryptocurrenciesResponse.Cryptocurrency responseCrypto = responseCryptoOptional.get();
        assertEquals(responseCrypto.getId(), cryptocurrency.getId());
        assertEquals(responseCrypto.getName(), cryptocurrency.getName());
        assertEquals(responseCrypto.getDate(), cryptocurrency.getDate());
        assertEquals(responseCrypto.getBuyValue(), cryptocurrency.getBuyValue());
        assertEquals(responseCrypto.getSellValue(), cryptocurrency.getSellValue());
    }

    @Test
    void requestToCryptocurrencyFunctionTest(){
        CreateCryptocurrencyRequest request = CreateCryptocurrencyRequest.builder()
                .id(cryptocurrency.getId())
                .name(cryptocurrency.getName())
                .sellValue(cryptocurrency.getSellValue())
                .buyValue(cryptocurrency.getBuyValue())
                .date(cryptocurrency.getDate())
                .build();

        assertEquals(new RequestToCryptocurrencyFunction().apply(request), cryptocurrency);
    }

    @Test
    void updateRequestToCryptocurrencyFunctionTest(){
        Cryptocurrency updatedCrypto =
                new Cryptocurrency(ID, CRYPTO_NAME + "changed", SELL_VALUE.add(BigDecimal.ONE), SELL_VALUE.add(BigDecimal.ONE), DATE.plusDays(1));
        UpdateCryptocurrencyRequest request = UpdateCryptocurrencyRequest.builder()
                .name(updatedCrypto.getName())
                .sellValue(updatedCrypto.getSellValue())
                .buyValue(updatedCrypto.getBuyValue())
                .date(updatedCrypto.getDate())
                .build();
        assertEquals(new UpdateRequestToCryptocurrencyFunction().apply(cryptocurrency, request), updatedCrypto);
    }
}