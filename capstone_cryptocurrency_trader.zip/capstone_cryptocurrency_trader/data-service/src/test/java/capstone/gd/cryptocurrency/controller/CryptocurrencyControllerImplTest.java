package capstone.gd.cryptocurrency.controller;

import capstone.gd.component.CryptocurrencyDtoFunctionFactory;
import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.CreateCryptocurrencyRequest;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrenciesResponse;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrencyResponse;
import capstone.gd.cryptocurrency.model.dto.UpdateCryptocurrencyRequest;
import capstone.gd.cryptocurrency.model.dto.function.CryptocurrenciesToResponseFunction;
import capstone.gd.cryptocurrency.model.dto.function.CryptocurrencyToResponseFunction;
import capstone.gd.cryptocurrency.model.dto.function.RequestToCryptocurrencyFunction;
import capstone.gd.cryptocurrency.model.dto.function.UpdateRequestToCryptocurrencyFunction;
import capstone.gd.cryptocurrency.service.interfaces.CryptocurrencyService;
import capstone.gd.exceptions.DuplicateKeyException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CryptocurrencyControllerImplTest {

    public static final Long ID = 1L;
    public static final String CRYPTO_NAME = "bitcoin";
    public static final BigDecimal SELL_VALUE = BigDecimal.valueOf(100_000);
    public static final BigDecimal BUY_VALUE = BigDecimal.valueOf(120_000);
    public static final LocalDate DATE = LocalDate.now();

    @Mock
    CryptocurrencyDtoFunctionFactory factory;

    @Mock
    CryptocurrencyService service;

    @InjectMocks
    CryptocurrencyControllerImpl controller;

    @Test
    void createCryptocurrencyTest() {
        //given
        CreateCryptocurrencyRequest request = CreateCryptocurrencyRequest.builder()
                .id(ID)
                .name(CRYPTO_NAME)
                .sellValue(SELL_VALUE)
                .buyValue(BUY_VALUE)
                .date(DATE)
                .build();
        Cryptocurrency crypto = Cryptocurrency.builder().build();
        given(service.create(any())).willReturn(crypto);
        RequestToCryptocurrencyFunction mock = mock(RequestToCryptocurrencyFunction.class);
        given(factory.requestToCryptocurrency()).willReturn(mock);
        given(mock.apply(any())).willReturn(crypto);

        assertTrue(controller.createCryptocurrency(request).equals(crypto));
    }

    @Test
    void createCryptocurrencyExceptionTest() {
        //given
        CreateCryptocurrencyRequest request = CreateCryptocurrencyRequest.builder()
                .id(ID)
                .name(CRYPTO_NAME)
                .sellValue(SELL_VALUE)
                .buyValue(BUY_VALUE)
                .date(DATE)
                .build();
        Cryptocurrency crypto = Cryptocurrency.builder().build();
        given(service.create(any())).willThrow(new DuplicateKeyException());
        RequestToCryptocurrencyFunction mock = mock(RequestToCryptocurrencyFunction.class);
        given(factory.requestToCryptocurrency()).willReturn(mock);
        given(mock.apply(any())).willReturn(crypto);

        assertTrue(controller.createCryptocurrency(request).equals(Cryptocurrency.builder().build()));
    }

    @Test
    void updateCryptocurrencyTest() {
        //given
        UpdateCryptocurrencyRequest request = UpdateCryptocurrencyRequest.builder()
                .name(CRYPTO_NAME)
                .buyValue(BUY_VALUE)
                .sellValue(SELL_VALUE)
                .date(DATE)
                .build();
        Cryptocurrency crypto = Cryptocurrency.builder().build();
        when(service.find(anyLong())).thenReturn(Optional.of(crypto));
        UpdateRequestToCryptocurrencyFunction mock = mock(UpdateRequestToCryptocurrencyFunction.class);
        when(factory.updateRequestToCryptocurrency()).thenReturn(mock);
        when(mock.apply(crypto, request)).thenReturn(crypto);

        //when
        controller.updateCryptocurrency(ID, request);

        //then
        verify(factory).updateRequestToCryptocurrency();
        verify(mock).apply(crypto, request);
        verify(service).update(crypto);
    }

    @Test
    void deleteCryptocurrencyDeleteExistingElementTest() {
        //given
        Cryptocurrency crypto = Cryptocurrency.builder().build();
        when(service.find(ID)).thenReturn(Optional.of(crypto));

        //when
        controller.deleteCryptocurrency(ID);

        //then
        verify(service).delete(crypto);
    }

    @Test
    void deleteCryptocurrencyDeleteNoExistingElementShouldThrowExceptionTest() {
        //given
        when(service.find(ID)).thenReturn(Optional.empty());

        //then
        assertThrows(NoSuchElementException.class, () -> controller.deleteCryptocurrency(ID));
    }

    @Test
    void getCryptocurrencyExistsingCryptocurrencyTest() {
        //given
        Cryptocurrency crypto = Cryptocurrency.builder().build();
        when(service.find(ID)).thenReturn(Optional.of(crypto));
        CryptocurrencyToResponseFunction mock = mock( CryptocurrencyToResponseFunction.class);
        when(factory.cryptocurrencyToResponse()).thenReturn(mock);
        GetCryptocurrencyResponse response = GetCryptocurrencyResponse.builder().build();
        when(mock.apply(crypto)).thenReturn(response);

        //then
        assertTrue(controller.getCryptocurrency(ID).equals(response));
        verify(factory).cryptocurrencyToResponse();
        verify(mock).apply(crypto);
    }

    @Nested
    class findAllTests {

        CryptocurrenciesToResponseFunction mock;

        @BeforeEach
        void init() {
            mock = mock(CryptocurrenciesToResponseFunction.class);
            when(factory.cryptocurrenciesToResponse()).thenReturn(mock);
            GetCryptocurrenciesResponse response = GetCryptocurrenciesResponse.builder().build();
            when(mock.apply(any(List.class))).thenReturn(response);
        }

        @Test
        void getAllCryptocurrenciesTest() {
            //given
            Cryptocurrency crypto = Cryptocurrency.builder().build();
            List<Cryptocurrency> cryptocurrencies = List.of(crypto);
            when(service.findAll()).thenReturn(cryptocurrencies);

            //when
            controller.getAllCryptocurrencies();

            //then
            verify(factory).cryptocurrenciesToResponse();
            verify(mock).apply(cryptocurrencies);
            verify(service).findAll();
        }

        @Test
        void getAllCryptocurrenciesFilterObjectTest() {
            //given
            Cryptocurrency crypto = Cryptocurrency.builder().build();
            List<Cryptocurrency> cryptocurrencies = List.of(crypto);
            Cryptocurrency filterObject = Cryptocurrency.builder().build();
            when(service.findAll(filterObject)).thenReturn(cryptocurrencies);

            //when
            controller.getCryptocurrencies(filterObject);

            //then
            verify(factory).cryptocurrenciesToResponse();
            verify(mock).apply(cryptocurrencies);
            verify(service).findAll(filterObject);
        }

        @Test
        void getAllCryptocurrenciesByNameTest() {
            //given
            Cryptocurrency crypto = Cryptocurrency.builder().build();
            List<Cryptocurrency> cryptocurrencies = List.of(crypto);
            String cryptoName = "Bitcoin";
            when(service.findAll(cryptoName)).thenReturn(cryptocurrencies);

            //when
            controller.getCryptocurrenciesByName(cryptoName);

            //then
            verify(factory).cryptocurrenciesToResponse();
            verify(mock).apply(cryptocurrencies);
            verify(service).findAll(cryptoName);
        }

        @Test
        void getAllCryptocurrenciesByDateTest() {
            //given
            Cryptocurrency crypto = Cryptocurrency.builder().build();
            List<Cryptocurrency> cryptocurrencies = List.of(crypto);
            LocalDate date = LocalDate.now();
            when(service.findAll(date)).thenReturn(cryptocurrencies);

            //when
            controller.getCryptocurrenciesByDate(date);

            //then
            verify(factory).cryptocurrenciesToResponse();
            verify(mock).apply(cryptocurrencies);
            verify(service).findAll(date);
        }

        @Test
        void getAllCryptocurrenciesByNameAndDate() {
            //given
            Cryptocurrency crypto = Cryptocurrency.builder().build();
            List<Cryptocurrency> cryptocurrencies = List.of(crypto);
            String cryptoName = "Bitcoin";
            LocalDate date = LocalDate.now();
            when(service.findAll(cryptoName, date)).thenReturn(cryptocurrencies);


            //when
            controller.getCryptocurrenciesByNameAndDate(cryptoName, date);

            //then
            verify(factory).cryptocurrenciesToResponse();
            verify(mock).apply(cryptocurrencies);
            verify(service).findAll(cryptoName, date);
        }
    }
}