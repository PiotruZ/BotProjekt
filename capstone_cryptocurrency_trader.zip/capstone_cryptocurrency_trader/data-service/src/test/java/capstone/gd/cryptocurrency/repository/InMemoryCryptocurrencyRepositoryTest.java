package capstone.gd.cryptocurrency.repository;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrenciesResponse;
import capstone.gd.cryptocurrency.repository.interfaces.CryptocurrencyRepository;
import capstone.gd.exceptions.DuplicateKeyException;
import net.bytebuddy.asm.Advice;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import javax.swing.text.html.Option;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

class InMemoryCryptocurrencyRepositoryTest {

    public static final Long ID = 1L;
    public static final String CRYPTO_NAME = "bitcoin";
    public static final BigDecimal SELL_VALUE = BigDecimal.valueOf(100_000);
    public static final BigDecimal BUY_VALUE = BigDecimal.valueOf(120_000);
    public static final LocalDate DATE = LocalDate.now();

    CryptocurrencyRepository repository;

    @BeforeEach
    void setUp(){
        repository = new InMemoryCryptocurrencyRepository();
    }

    @Test
    void saveNoDuplicationTest() {
        Cryptocurrency crypto = Cryptocurrency.builder().build();

        assertTrue(repository.save(crypto).equals(crypto));
        assertEquals(repository.findAll().size(), 1);
    }

    @Test
    void saveDuplicateKeyExceptionThrowTest() {
        Cryptocurrency crypto = new Cryptocurrency(ID, CRYPTO_NAME, SELL_VALUE, BUY_VALUE, DATE);

        repository.save(crypto);

        assertThrows(DuplicateKeyException.class, () -> repository.save(crypto).equals(crypto));
        assertEquals(repository.findAll().size(), 1);
    }

    @Test
    void deleteEmptyTest() {
        repository.delete(Cryptocurrency.builder().build());
    }

    @Test
    void deleteNotEmptyTest(){
        Cryptocurrency crypto = new Cryptocurrency(ID, CRYPTO_NAME, SELL_VALUE, BUY_VALUE, DATE);
        repository.save(crypto);

        repository.delete(crypto);

        assertFalse(repository.findAll().contains(crypto));
    }

    @Test
    void findNotFoundTest() {
        assertEquals(repository.find(ID), Optional.empty());
    }

    @Test
    void findFoundTest() {
        Cryptocurrency crypto = new Cryptocurrency(ID, CRYPTO_NAME, SELL_VALUE, BUY_VALUE, DATE);
        repository.save(crypto);

        assertEquals(repository.find(ID), Optional.of(crypto));
    }

    @Test
    void findAllTest() {
        repository.findAll();
    }

    @Test
    void findAllByNameFoundTest() {
        Cryptocurrency crypto = new Cryptocurrency(ID, CRYPTO_NAME, SELL_VALUE, BUY_VALUE, DATE);
        Cryptocurrency crypto2 = new Cryptocurrency(ID+1, CRYPTO_NAME+"2", SELL_VALUE, BUY_VALUE, DATE);
        repository.save(crypto);
        repository.save(crypto2);

        List<Cryptocurrency> cryptocurrencies = repository.findAllByName(CRYPTO_NAME);

        assertTrue(cryptocurrencies.contains(crypto));
        assertEquals(cryptocurrencies.size(), 1);
    }

    @Test
    void findAllByNameNoResultsTest() {
        Cryptocurrency crypto = new Cryptocurrency(ID, CRYPTO_NAME, SELL_VALUE, BUY_VALUE, DATE);
        repository.save(crypto);

        List<Cryptocurrency> cryptocurrencies = repository.findAllByName(CRYPTO_NAME+"2");

        assertEquals(cryptocurrencies.size(), 0);
    }

    @Nested
    class findAllByFilterObjectTests {

        Cryptocurrency crypto1;
        Cryptocurrency crypto2;

        @BeforeEach
        void setUp(){
            crypto1 = new Cryptocurrency(ID, CRYPTO_NAME+"1", SELL_VALUE, BUY_VALUE, DATE);
            crypto2 = new Cryptocurrency(ID+1, CRYPTO_NAME+"2", SELL_VALUE.add(BigDecimal.ONE), BUY_VALUE.add(BigDecimal.ONE), DATE.plusDays(1));
            repository.save(crypto1);
            repository.save(crypto2);
        }

        @Test
        void findAllByFilterObjectAllFieldsNullShouldReturnAllEntitiesTest() {
            Cryptocurrency filterObject = Cryptocurrency.builder().build();

            assertTrue(repository.findAll(filterObject).contains(crypto1));
        }

        @Test
        void findAllByFilterObjectFilterByNameShouldReturnOneEntityInListTest() {
            Cryptocurrency filterObject = Cryptocurrency.builder()
                    .name(crypto1.getName())
                    .build();

            List<Cryptocurrency> cryptocurrencies = repository.findAll(filterObject);

            assertTrue(cryptocurrencies.contains(crypto1));
            assertEquals(cryptocurrencies.size(), 1);
        }

        @Test
        void findAllByFilterObjectFilterByBuyValueShouldReturnOneEntityInListTest() {
            Cryptocurrency filterObject = Cryptocurrency.builder()
                    .buyValue(crypto1.getBuyValue())
                    .build();

            List<Cryptocurrency> cryptocurrencies = repository.findAll(filterObject);

            assertTrue(cryptocurrencies.contains(crypto1));
            assertEquals(cryptocurrencies.size(), 1);
        }

        @Test
        void findAllByFilterObjectFilterBySellValueShouldReturnOneEntityInListTest() {
            Cryptocurrency filterObject = Cryptocurrency.builder()
                    .sellValue(crypto1.getSellValue())
                    .build();

            List<Cryptocurrency> cryptocurrencies = repository.findAll(filterObject);

            assertTrue(cryptocurrencies.contains(crypto1));
            assertEquals(cryptocurrencies.size(), 1);
        }

        @Test
        void findAllByFilterObjectFilterByDateShouldReturnOneEntityInListTest() {
            Cryptocurrency filterObject = Cryptocurrency.builder()
                    .date(crypto1.getDate())
                    .build();

            List<Cryptocurrency> cryptocurrencies = repository.findAll(filterObject);

            assertTrue(cryptocurrencies.contains(crypto1));
            assertEquals(cryptocurrencies.size(), 1);
        }
    }

    @Test
    void findAllByDateFoundTest() {
        Cryptocurrency crypto = new Cryptocurrency(ID, CRYPTO_NAME, SELL_VALUE, BUY_VALUE, DATE);
        Cryptocurrency crypto2 = new Cryptocurrency(ID+1, CRYPTO_NAME+"2", SELL_VALUE, BUY_VALUE, DATE.plusDays(1));
        repository.save(crypto);
        repository.save(crypto2);

        List<Cryptocurrency> cryptocurrencies = repository.findAllByDate(DATE);

        assertTrue(cryptocurrencies.contains(crypto));
        assertEquals(cryptocurrencies.size(), 1);
    }

    @Test
    void findAllByDateNoResultsTest() {
        Cryptocurrency crypto = new Cryptocurrency(ID, CRYPTO_NAME, SELL_VALUE, BUY_VALUE, DATE.plusDays(1));
        repository.save(crypto);

        List<Cryptocurrency> cryptocurrencies = repository.findAllByDate(DATE);

        assertEquals(cryptocurrencies.size(), 0);
    }
}