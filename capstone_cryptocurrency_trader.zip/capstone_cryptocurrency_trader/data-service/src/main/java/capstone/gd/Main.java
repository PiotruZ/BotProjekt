package capstone.gd;

import capstone.gd.component.CryptocurrencyDtoFunctionFactory;
import capstone.gd.cryptocurrency.controller.CryptocurrencyControllerImpl;
import capstone.gd.cryptocurrency.controller.interfaces.CryptocurrencyController;
import capstone.gd.cryptocurrency.model.dto.CreateCryptocurrencyRequest;
import capstone.gd.cryptocurrency.repository.InMemoryCryptocurrencyRepository;
import capstone.gd.cryptocurrency.repository.interfaces.CryptocurrencyRepository;
import capstone.gd.cryptocurrency.service.CryptocurrencyServiceImpl;
import capstone.gd.cryptocurrency.service.interfaces.CryptocurrencyService;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        CryptocurrencyRepository cryptocurrencyRepository = new InMemoryCryptocurrencyRepository();
        CryptocurrencyService cryptocurrencyService = new CryptocurrencyServiceImpl(cryptocurrencyRepository);
        CryptocurrencyController cryptocurrencyController = new CryptocurrencyControllerImpl(cryptocurrencyService, new CryptocurrencyDtoFunctionFactory());

        CreateCryptocurrencyRequest crypto = CreateCryptocurrencyRequest.builder()
                .id(1L)
                .name("Bitcoin")
                .sellValue(BigDecimal.valueOf(100_000))
                .buyValue(BigDecimal.valueOf(120_000))
                .date(LocalDate.now())
                .build();

        cryptocurrencyController.createCryptocurrency(crypto);
        cryptocurrencyController.createCryptocurrency(crypto);
        System.out.println(cryptocurrencyController.getAllCryptocurrencies());
        System.out.println(cryptocurrencyController.getCryptocurrency(1L));
    }
}