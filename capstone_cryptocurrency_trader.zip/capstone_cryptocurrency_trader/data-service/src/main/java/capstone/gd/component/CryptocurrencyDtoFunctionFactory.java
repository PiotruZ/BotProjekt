package capstone.gd.component;

import capstone.gd.cryptocurrency.model.dto.function.CryptocurrenciesToResponseFunction;
import capstone.gd.cryptocurrency.model.dto.function.CryptocurrencyToResponseFunction;
import capstone.gd.cryptocurrency.model.dto.function.RequestToCryptocurrencyFunction;
import capstone.gd.cryptocurrency.model.dto.function.UpdateRequestToCryptocurrencyFunction;

public class CryptocurrencyDtoFunctionFactory {

    public CryptocurrencyToResponseFunction cryptocurrencyToResponse(){
        return new CryptocurrencyToResponseFunction();
    }

    public CryptocurrenciesToResponseFunction cryptocurrenciesToResponse(){
        return new CryptocurrenciesToResponseFunction();
    }

    public RequestToCryptocurrencyFunction requestToCryptocurrency(){
        return new RequestToCryptocurrencyFunction();
    }

    public UpdateRequestToCryptocurrencyFunction updateRequestToCryptocurrency(){
        return new UpdateRequestToCryptocurrencyFunction();
    }

}
