package capstone.gd.cryptocurrency.model.dto.function;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrenciesResponse;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrencyResponse;

import java.util.function.Function;

public class CryptocurrencyToResponseFunction implements Function<Cryptocurrency, GetCryptocurrencyResponse> {
    @Override
    public GetCryptocurrencyResponse apply(Cryptocurrency cryptocurrency) {
        return GetCryptocurrencyResponse.builder()
                .id(cryptocurrency.getId())
                .name(cryptocurrency.getName())
                .sellValue(cryptocurrency.getSellValue())
                .buyValue(cryptocurrency.getBuyValue())
                .date(cryptocurrency.getDate())
                .build();
    }
}
