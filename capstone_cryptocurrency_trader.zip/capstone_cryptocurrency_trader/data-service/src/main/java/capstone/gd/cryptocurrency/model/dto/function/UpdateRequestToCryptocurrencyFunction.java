package capstone.gd.cryptocurrency.model.dto.function;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.UpdateCryptocurrencyRequest;
import lombok.Builder;

import java.util.function.BiFunction;

/**
 * Returns new instance of {@link Cryptocurrency} based on provided request.
 * Sets up editable fields taking values from request.
 * Rest of immutable values stay the same.
 */
public class UpdateRequestToCryptocurrencyFunction implements BiFunction<Cryptocurrency, UpdateCryptocurrencyRequest, Cryptocurrency> {
    @Override
    public Cryptocurrency apply(Cryptocurrency cryptocurrency, UpdateCryptocurrencyRequest request) {
        return Cryptocurrency.builder()
                .id(cryptocurrency.getId())
                .name(request.getName())
                .sellValue(request.getSellValue())
                .buyValue(request.getBuyValue())
                .date(request.getDate())
                .build();
    }
}
