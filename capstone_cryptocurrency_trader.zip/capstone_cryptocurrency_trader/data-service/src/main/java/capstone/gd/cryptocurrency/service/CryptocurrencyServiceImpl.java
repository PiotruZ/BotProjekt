package capstone.gd.cryptocurrency.service;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.repository.interfaces.CryptocurrencyRepository;
import capstone.gd.cryptocurrency.service.interfaces.CryptocurrencyService;
import capstone.gd.exceptions.DuplicateKeyException;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
public class CryptocurrencyServiceImpl implements CryptocurrencyService {

    private final CryptocurrencyRepository repository;

    @Override
    public Optional<Cryptocurrency> find(Long id) {
        return repository.find(id);
    }

    @Override
    public Cryptocurrency create(Cryptocurrency cryptocurrency) {
//        if (repository.findAll().stream()
//                .anyMatch(c -> c.getId().equals(cryptocurrency.getId()))){
//            throw new DuplicateKeyException("Element with this id already exists.");
//        }
        return repository.save(cryptocurrency);
    }

    @Override
    public void update(Cryptocurrency cryptocurrency) {
        repository.save(cryptocurrency);
    }

    @Override
    public void delete(Cryptocurrency cryptocurrency) {
        repository.delete(cryptocurrency);
    }

    @Override
    public List<Cryptocurrency> findAll() {
        return repository.findAll();
    }

    @Override
    public List<Cryptocurrency> findAll(LocalDate date) {
        return repository.findAllByDate(date);
    }

    @Override
    public List<Cryptocurrency> findAll(String name) {
        return repository.findAllByName(name);
    }

    @Override
    public List<Cryptocurrency> findAll(String name, LocalDate date) {
        return repository.findAllByName(name).stream()
                .filter(crypto -> crypto.getDate().isEqual(date))
                .toList();
    }

    @Override
    public List<Cryptocurrency> findAll(Cryptocurrency filterObject) {
        return repository.findAll(filterObject);
    }

}
