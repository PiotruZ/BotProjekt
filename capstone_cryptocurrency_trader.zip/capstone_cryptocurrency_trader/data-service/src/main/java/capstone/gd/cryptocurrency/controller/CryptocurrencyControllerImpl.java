package capstone.gd.cryptocurrency.controller;

import capstone.gd.component.CryptocurrencyDtoFunctionFactory;
import capstone.gd.cryptocurrency.controller.interfaces.CryptocurrencyController;
import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.CreateCryptocurrencyRequest;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrenciesResponse;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrencyResponse;
import capstone.gd.cryptocurrency.model.dto.UpdateCryptocurrencyRequest;
import capstone.gd.cryptocurrency.service.interfaces.CryptocurrencyService;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.util.NoSuchElementException;

@RequiredArgsConstructor
public class CryptocurrencyControllerImpl implements CryptocurrencyController {

    private final CryptocurrencyService service;

    private final CryptocurrencyDtoFunctionFactory dtoFactory;

    @Override
    public Cryptocurrency createCryptocurrency(CreateCryptocurrencyRequest request) {
        try {
            return service.create(dtoFactory.requestToCryptocurrency().apply(request));
        } catch (Exception exception){
            System.err.println(exception.getMessage());
        }
        return Cryptocurrency.builder().build();
    }

    @Override
    public void updateCryptocurrency(Long id, UpdateCryptocurrencyRequest request) {
        service.find(id).ifPresent(
                crypto -> service.update(dtoFactory.updateRequestToCryptocurrency().apply(crypto, request))
        );
    }

    @Override
    public void deleteCryptocurrency(Long id) {
        service.find(id)
                .ifPresentOrElse(
                        service::delete,
                        () -> {
                            // user should not be informed that cryptocurrency data hasn't existed (?)
                            throw new NoSuchElementException();
                        }
                );
    }

    @Override
    public GetCryptocurrencyResponse getCryptocurrency(Long id) {
        return service.find(id)
                .map(dtoFactory.cryptocurrencyToResponse())
                .orElseThrow(NoSuchElementException::new); // todo: create appropriate exceptions
    }

    @Override
    public GetCryptocurrenciesResponse getAllCryptocurrencies() {
        return dtoFactory.cryptocurrenciesToResponse().apply(service.findAll());
    }

    @Override
    public GetCryptocurrenciesResponse getCryptocurrencies(Cryptocurrency filterObject) {
        return dtoFactory.cryptocurrenciesToResponse().apply(service.findAll(filterObject));
    }

    @Override
    public GetCryptocurrenciesResponse getCryptocurrenciesByName(String name) {
        return dtoFactory.cryptocurrenciesToResponse().apply(service.findAll(name));
    }

    @Override
    public GetCryptocurrenciesResponse getCryptocurrenciesByDate(LocalDate date) {
        return dtoFactory.cryptocurrenciesToResponse().apply(service.findAll(date));
    }

    @Override
    public GetCryptocurrenciesResponse getCryptocurrenciesByNameAndDate(String name, LocalDate date) {
        return dtoFactory.cryptocurrenciesToResponse().apply(service.findAll(name, date));
    }
}
