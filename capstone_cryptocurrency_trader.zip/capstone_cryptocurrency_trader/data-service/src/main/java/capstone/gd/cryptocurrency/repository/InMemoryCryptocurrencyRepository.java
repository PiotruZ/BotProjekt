package capstone.gd.cryptocurrency.repository;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.repository.interfaces.CryptocurrencyRepository;
import capstone.gd.exceptions.DuplicateKeyException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InMemoryCryptocurrencyRepository implements CryptocurrencyRepository {

    private final List<Cryptocurrency> cryptocurrencies;

    public InMemoryCryptocurrencyRepository() {
        cryptocurrencies = new ArrayList<>();
    }

    @Override
    public Cryptocurrency save(Cryptocurrency entity) {
        if (cryptocurrencies.stream().anyMatch(crypto -> crypto.getId().equals(entity.getId()))){
            throw new DuplicateKeyException("Element with this id already exists.");
        }
        cryptocurrencies.add(entity);
        return entity;
    }

    @Override
    public void delete(Cryptocurrency entity) {
        cryptocurrencies.remove(entity);
    }

    @Override
    public Optional<Cryptocurrency> find(Long id) {
        return cryptocurrencies.stream().filter(crypto -> crypto.getId().equals(id)).findFirst();
    }

    @Override
    public List<Cryptocurrency> findAll() {
        return new ArrayList<>(cryptocurrencies);
    }

    @Override
    public List<Cryptocurrency> findAllByName(String name) {
        return cryptocurrencies.stream().filter(crypto -> crypto.getName().equals(name)).toList();
    }

    @Override
    public List<Cryptocurrency> findAll(Cryptocurrency filterObject) {
        return cryptocurrencies.stream()
                .filter(crypto -> filterObject.getName() == null || crypto.getName().equals(filterObject.getName()))
                .filter(crypto -> filterObject.getSellValue() == null || crypto.getSellValue().equals(filterObject.getSellValue()))
                .filter(crypto -> filterObject.getBuyValue() == null || crypto.getBuyValue().equals(filterObject.getBuyValue()))
                .filter(crypto -> filterObject.getDate() == null || crypto.getDate().isEqual(filterObject.getDate()))
                .toList();
    }

    @Override
    public List<Cryptocurrency> findAllByDate(LocalDate date) {
        return cryptocurrencies.stream().filter(crypto -> crypto.getDate().isEqual(date)).toList();
    }

}
