package capstone.gd.cryptocurrency.service.interfaces;

import capstone.gd.cryptocurrency.model.Cryptocurrency;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface CryptocurrencyService {

    Optional<Cryptocurrency> find(Long id);

    Cryptocurrency create(Cryptocurrency cryptocurrency);

    void delete(Cryptocurrency cryptocurrency);

    void update(Cryptocurrency cryptocurrency);

    List<Cryptocurrency> findAll();

    List<Cryptocurrency> findAll(LocalDate date);

    List<Cryptocurrency> findAll(String name);

    List<Cryptocurrency> findAll(String name, LocalDate date);

    List<Cryptocurrency> findAll(Cryptocurrency filterObject);
}
