package capstone.gd.exceptions;

public class DuplicateKeyException extends RuntimeException{

    private static final String DEFAULT_MESSAGE = "Entity with following primary key already exists!";

    public DuplicateKeyException(String message){
        super(message);
    }
    public DuplicateKeyException(){
        this(DEFAULT_MESSAGE);
    }
}
