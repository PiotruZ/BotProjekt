package capstone.gd.cryptocurrency.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Builder
@AllArgsConstructor
@Data
public class Cryptocurrency {

    /**
     *  Unique id (primary key).
     */
    private Long id;

    /**
     * Name of the cryptocurrency.
     */
    private String name;

    /**
     * Cryptocurrency sell value.
     */
    private BigDecimal sellValue;

    /**
     * Cryptocurrency buy value.
     */
    private BigDecimal buyValue;

    /**
     * The date to which this data relates.
     */
    private LocalDate date;

}
