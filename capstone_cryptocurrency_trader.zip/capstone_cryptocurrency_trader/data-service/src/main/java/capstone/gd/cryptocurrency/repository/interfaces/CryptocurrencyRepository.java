package capstone.gd.cryptocurrency.repository.interfaces;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.repository.Repository;

import java.time.LocalDate;
import java.util.List;

public interface CryptocurrencyRepository extends Repository<Cryptocurrency> {

    List<Cryptocurrency> findAllByDate(LocalDate date);

    List<Cryptocurrency> findAllByName(String name);

    List<Cryptocurrency> findAll(Cryptocurrency filterObject);

}
