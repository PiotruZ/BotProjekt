package capstone.gd.cryptocurrency.model.dto.function;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.CreateCryptocurrencyRequest;

import java.util.function.Function;

/**
 * Returns new instance of {@link Cryptocurrency} based on request {@link CreateCryptocurrencyRequest}
 */
public class RequestToCryptocurrencyFunction implements Function<CreateCryptocurrencyRequest, Cryptocurrency> {

    @Override
    public Cryptocurrency apply(CreateCryptocurrencyRequest request) {
        return Cryptocurrency.builder()
                .id(request.getId())
                .name(request.getName())
                .sellValue(request.getSellValue())
                .buyValue(request.getBuyValue())
                .date(request.getDate())
                .build();
    }

}
