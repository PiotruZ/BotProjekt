package capstone.gd.cryptocurrency.model.dto;

import lombok.Builder;
import lombok.Data;
import lombok.Singular;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@ToString
@Builder
@Data
public class GetCryptocurrenciesResponse {

    /**
     * Represents single Cryptocurrency in list. Useful if we don't want
     * to share whole objects like {@link capstone.gd.cryptocurrency.model.Cryptocurrency}
     */
    @Builder
    @Data
    public static class Cryptocurrency{

        /**
         *  Unique id (primary key).
         */
        private Long id;

        /**
         * Name of the cryptocurrency.
         */
        private String name;

        /**
         * Cryptocurrency sell value.
         */
        private BigDecimal sellValue;

        /**
         * Cryptocurrency buy value.
         */
        private BigDecimal buyValue;

        /**
         * The date to which this data relates.
         */
        private LocalDate date;

    }

    /**
     * Allows to add elements in @Builder.
     */
    @Singular
    private List<Cryptocurrency> cryptocurrencies;

}
