package capstone.gd.cryptocurrency.controller.interfaces;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.CreateCryptocurrencyRequest;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrenciesResponse;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrencyResponse;
import capstone.gd.cryptocurrency.model.dto.UpdateCryptocurrencyRequest;

import java.time.LocalDate;

public interface CryptocurrencyController {

    Cryptocurrency createCryptocurrency(CreateCryptocurrencyRequest request);

    void updateCryptocurrency(Long id, UpdateCryptocurrencyRequest request);

    void deleteCryptocurrency(Long id);

    GetCryptocurrencyResponse getCryptocurrency(Long id);

    GetCryptocurrenciesResponse getAllCryptocurrencies();

    /**
     * @param filterObject
     * @return cryptocurrencies whose fields are equal to the fields of the filterObject object
     */
    GetCryptocurrenciesResponse getCryptocurrencies(Cryptocurrency filterObject);

    GetCryptocurrenciesResponse getCryptocurrenciesByName(String name);

    GetCryptocurrenciesResponse getCryptocurrenciesByDate(LocalDate date);

    GetCryptocurrenciesResponse getCryptocurrenciesByNameAndDate(String name, LocalDate date);

}
