package capstone.gd.cryptocurrency.model.dto.function;

import capstone.gd.cryptocurrency.model.Cryptocurrency;
import capstone.gd.cryptocurrency.model.dto.GetCryptocurrenciesResponse;

import java.util.List;
import java.util.function.Function;

public class CryptocurrenciesToResponseFunction implements Function<List<Cryptocurrency>, GetCryptocurrenciesResponse> {
    @Override
    public GetCryptocurrenciesResponse apply(List<Cryptocurrency> cryptocurrencyList) {
        return GetCryptocurrenciesResponse.builder()
                .cryptocurrencies(cryptocurrencyList.stream()
                        .map(crypto -> GetCryptocurrenciesResponse.Cryptocurrency.builder()
                                .id(crypto.getId())
                                .name(crypto.getName())
                                .sellValue(crypto.getSellValue())
                                .buyValue(crypto.getBuyValue())
                                .date(crypto.getDate())
                                .build())
                        .toList())
                .build();
    }
}
