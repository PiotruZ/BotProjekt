# User service #

Microservice responsible for processing users data.

## Technologies : #
 - Java 17
 - Maven
 - Docker

## Database installation #

To run docker container with database run command:

```
docker compose up -d
```
You will also need .env file with database configuration.
Ask admin for .env file.