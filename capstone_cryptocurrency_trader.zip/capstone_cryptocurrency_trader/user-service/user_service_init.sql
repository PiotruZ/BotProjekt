create table if not exists roles (
id serial primary key,
role varchar(10)
);

insert into roles (id, role)
values
(1,'ADMIN'),
(2,'USER')
ON CONFLICT DO NOTHING;

create table if not exists users (
id serial primary key,
login varchar(100),
password varchar(100),
email varchar(100),
phone_number varchar(50),
role_id integer,
constraint fk_role_id foreign key(role_id) references roles(id)
);


create table if not exists tokens(
id serial primary key,
expired_at timestamp,
user_id integer,
constraint fk_user_id foreign key(user_id) references users(id)
);

create table if not exists logged_users (
user_id integer,
token_id integer,
primary key (user_id, token_id),
	constraint fk_users foreign key(user_id) references users(id),
	constraint fk_tokens foreign key(token_id) references tokens(id)
)


