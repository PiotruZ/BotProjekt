package capstone.gd.repository;

import capstone.gd.model.user.UserEntity;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UserRepositoryJdbcImpl implements UserRepository {

  private static final String READ_ALL_QUERY = "SELECT * FROM users";
  private static final String SAVE_QUERY = """
          INSERT INTO users
          (login, password, email, phone_number)
          VALUES(?,?,?,?)
      """;
  private static final String CHANGE_PASSWORD_QUERY = "UPDATE users SET password=? WHERE id=?";
  private static final String GET_BY_LOGIN_QUERY = "SELECT * FROM users WHERE login =?";
  private static final String GET_BY_ID_QUERY = "SELECT * FROM users WHERE id =?";
  private final JdbcManager jdbcManager;

  public UserRepositoryJdbcImpl(JdbcManager jdbcManager) {
    this.jdbcManager = jdbcManager;
  }

  @Override
  public List<UserEntity> readAll() {
    return jdbcManager.findMany(READ_ALL_QUERY, UserEntity::new);
  }

  @Override
  public Optional<UserEntity> getByUserId(Integer userId) {
    UserEntity user = jdbcManager.findOne(GET_BY_ID_QUERY, UserEntity::new, userId);
    return Optional.of(user);
  }

  @Override
  public Optional<UserEntity> getUserByLogin(String login) {
    UserEntity user = jdbcManager.findOne(GET_BY_LOGIN_QUERY, UserEntity::new, login);
    return Optional.of(user);
  }

  @Override
  public void save(UserEntity user) {
    jdbcManager.execute(SAVE_QUERY, user.getLogin(), user.getPassword(), user.getEmail(), user.getPhoneNumber());
  }

  @Override
  public void changePassword(UserEntity user, String newPassword) {
    jdbcManager.execute(CHANGE_PASSWORD_QUERY, newPassword, user.getId());
  }
}
