package capstone.gd;

import capstone.gd.controller.UserController;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Profile;

@SpringBootApplication
@Profile("dev")
public class App {

  public static void main(String[] args) {
    ApplicationContext context = SpringApplication.run(App.class, args);
    UserController userController = context.getBean(UserController.class);
    userController.start();
  }
}