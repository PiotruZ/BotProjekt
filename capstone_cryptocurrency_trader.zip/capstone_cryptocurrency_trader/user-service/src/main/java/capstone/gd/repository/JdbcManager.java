package capstone.gd.repository;

import capstone.gd.exception.DataNotFoundException;
import capstone.gd.exception.DatabaseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

@Component
public class JdbcManager {

  public static final String EXCEPTION_OCCURRED_DURING_EXECUTING_QUERY = "Exception occurred during executing query\n";
  public static final String NO_DATA_FOUND_FOR_QUERY = "No data found for query: ";
  private final Logger LOGGER = LoggerFactory.getLogger(JdbcManager.class);
  @Value("${postgres.db}")
  private final String databaseName;
  @Value("${postgres.user}")
  private final String user;
  @Value("${postgres.password}")
  private final String password;

  public JdbcManager(String databaseName,
                     String user,
                     String password) {
    this.databaseName = databaseName;
    this.user = user;
    this.password = password;
  }

  public void execute(String query, Object... args) {
    try (Connection connection = DriverManager
        .getConnection(databaseName, user, password);
         PreparedStatement preparedStatement = connection.prepareStatement(query)) {
      LOGGER.info("Executing execute query: " + query + " with " + args.length + " arguments");
      for (int i = 0; i < args.length; i++) {
        preparedStatement.setObject(i + 1, args[i]);
      }
      preparedStatement.executeUpdate();
      LOGGER.info("Query " + query + " executed successfully");
    } catch (SQLException e) {
      throw new DatabaseException(EXCEPTION_OCCURRED_DURING_EXECUTING_QUERY + e.getMessage());
    }
  }

  public <T> T findOne(String query, Function<ResultSet, T> mapper, Object... args) {
    try (Connection connection = DriverManager
        .getConnection(databaseName, user, password);
         PreparedStatement preparedStatement = connection.prepareStatement(query)) {
      LOGGER.info("Executing findOne query: " + query + " with " + args.length + " arguments");
      for (int i = 0; i < args.length; i++) {
        preparedStatement.setObject(i + 1, args[i]);
      }
      try (ResultSet resultSet = preparedStatement.executeQuery()) {
        if (!resultSet.next()) {
          throw new DataNotFoundException(NO_DATA_FOUND_FOR_QUERY + query);
        }
        T result = mapper.apply(resultSet);
        LOGGER.info("Query " + query + " executed successfully");
        return result;
      }
    } catch (SQLException e) {
      throw new DatabaseException(EXCEPTION_OCCURRED_DURING_EXECUTING_QUERY + e.getMessage());
    }
  }

  public <T> List<T> findMany(String query, Function<ResultSet, T> mapper, Object... args) {
    List<T> results = new ArrayList<>();
    try (Connection connection = DriverManager
        .getConnection(databaseName, user, password);
         PreparedStatement preparedStatement = connection.prepareStatement(query)) {
      LOGGER.info("Executing findMany query: " + query + " with " + args.length + " arguments");
      for (int i = 0; i < args.length; i++) {
        preparedStatement.setObject(i + 1, args[i]);
      }
      try (ResultSet resultSet = preparedStatement.executeQuery()) {
        while (resultSet.next()) {
          T result = mapper.apply(resultSet);
          results.add(result);
        }
        LOGGER.info("Query " + query + " executed successfully");
      }
    } catch (SQLException e) {
      throw new DatabaseException(EXCEPTION_OCCURRED_DURING_EXECUTING_QUERY + e.getMessage());
    }
    return results;
  }
}
