package capstone.gd.model.user;

import java.io.Serial;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;


public class UserEntity implements Serializable {

  @Serial
  private static final long serialVersionUID = -6231220496615820865L;
  private Integer id;
  private String login;
  private String password;
  private String email;
  private String phoneNumber;
  private Integer roleId;

  public UserEntity() {
  }

  public UserEntity(ResultSet resultSet) {
    try {
      this.id = resultSet.getInt("id");
      this.login = resultSet.getString("login");
      this.password = resultSet.getString("password");
      this.email = resultSet.getString("email");
      this.phoneNumber = resultSet.getString("phone_number");
      this.roleId = resultSet.getInt("role_id");
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  public UserEntity(String login, String password, String email, String phoneNumber) {
    this.login = login;
    this.password = password;
    this.email = email;
    this.phoneNumber = phoneNumber;
  }

  public int getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public String getLogin() {
    return login;
  }

  public void setLogin(String login) {
    this.login = login;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public Integer getRoleId() {
    return roleId;
  }

  public void setRoleId(Integer roleId) {
    this.roleId = roleId;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) return true;
    if (!(object instanceof UserEntity that)) return false;
    return Objects.equals(id, that.id) && Objects.equals(email, that.email) && Objects.equals(phoneNumber, that.phoneNumber) && Objects.equals(login, that.login) && Objects.equals(password, that.password) && roleId == that.roleId;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, email, phoneNumber, login, password, roleId);
  }

  @Override
  public String toString() {
    return "UserEntity{" +
        "id=" + id +
        ", email='" + email + '\'' +
        ", phoneNumber='" + phoneNumber + '\'' +
        ", login='" + login + '\'' +
        ", password='" + password + '\'' +
        ", roleId=" + roleId +
        '}';
  }
}
