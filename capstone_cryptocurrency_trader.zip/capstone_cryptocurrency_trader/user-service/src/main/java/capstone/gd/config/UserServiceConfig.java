package capstone.gd.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.time.LocalDateTime;
import java.util.Scanner;

@Configuration
public class UserServiceConfig {

  private final Environment environment;
  public static final int TOKEN_TIME_EXPIRATION_IN_MINUTES = 5;

  public UserServiceConfig(Environment environment) {
    this.environment = environment;
  }

  public static LocalDateTime getExpirationTime() {
    return LocalDateTime.now().withNano(0).plusMinutes(TOKEN_TIME_EXPIRATION_IN_MINUTES);
  }

  @Bean(name = "databaseName")
  public String getDatabaseName() {
    return environment.getProperty("postgres.db");
  }

  @Bean(name = "user")
  public String getUser() {
    return environment.getProperty("postgres.user");
  }

  @Bean(name = "password")
  public String getPassword() {
    return environment.getProperty("postgres.password");
  }

  @Bean
  public Scanner getScanner() {
    return new Scanner(System.in);
  }
}
