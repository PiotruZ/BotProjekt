package capstone.gd.exception;

public class DatabaseException extends RuntimeException {

  public DatabaseException(String message) {
    super(message);
  }
}
