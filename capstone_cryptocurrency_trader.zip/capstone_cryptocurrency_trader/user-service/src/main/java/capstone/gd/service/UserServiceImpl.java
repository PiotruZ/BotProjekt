package capstone.gd.service;

import capstone.gd.config.UserServiceConfig;
import capstone.gd.model.token.Token;
import capstone.gd.model.user.UserEntity;
import capstone.gd.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

  public static final String USER_NOT_FOUND = "User not found";
  public static final int ADMIN_ROLE_ID = 1;
  public static final int USER_ROLE_ID = 2;
  private final UserRepository userRepository;
  private final AuthenticationService authenticationService;
  private final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

  public UserServiceImpl(UserRepository userRepository, AuthenticationService authenticationService) {
    this.userRepository = userRepository;
    this.authenticationService = authenticationService;
  }

  @Override
  public Optional<Token> login(String login, String password) {
    if (!authenticationService.checkIfUserExists(login)) {
      LOGGER.info("User with login: " + login + " does not exist");
      return Optional.empty();
    }
    if (!authenticationService.checkIfPasswordMatches(login, password)) {
      LOGGER.info("Password is invalid");
      return Optional.empty();
    }
    LOGGER.info("User with login: " + login + " is now logged");
    return userRepository.getUserByLogin(login)
        .map(UserEntity::getId)
        .map(id -> new Token(id,
            UserServiceConfig.getExpirationTime()));
  }

  @Override
  public void register(String login, String password, String email, String phoneNumber) {
    List<UserEntity> users = new ArrayList<>();
    if (userRepository.readAll() != null) {
      users = userRepository.readAll();
    }
    UserEntity userEntity = new UserEntity(login, password, email, phoneNumber);
    userEntity.setRoleId(USER_ROLE_ID);
    userEntity.setId(users.size());
    users.add(userEntity);
    userRepository.save(userEntity);
    LOGGER.info("User with login: " + login + " was registered");
  }

  @Override
  public UserEntity getUser(Integer userId) {
    return userRepository
        .getByUserId(userId)
        .orElseThrow(() -> new RuntimeException(USER_NOT_FOUND));
  }

  @Override
  public List<UserEntity> listAll(Token token) {
    Integer roleId = userRepository
        .getByUserId(token.getId())
        .orElseThrow(() -> new RuntimeException(USER_NOT_FOUND))
        .getRoleId();
    if (!roleId.equals(ADMIN_ROLE_ID)) {
      LOGGER.info("User has no access");
      return Collections.emptyList();
    } else {
      return userRepository.readAll();
    }
  }

  @Override
  public void changePassword(Token token, String newPassword) {
    UserEntity userEntity = userRepository
        .getByUserId(token.getId())
        .orElseThrow(() -> new RuntimeException(USER_NOT_FOUND));
    userRepository.changePassword(userEntity, newPassword);
  }
}
