package capstone.gd.controller;

import capstone.gd.exception.BadCredentialsException;
import capstone.gd.model.token.Token;
import capstone.gd.service.UserService;
import org.springframework.stereotype.Controller;

import java.util.Scanner;

@Controller
public class UserController {
  public static final String USER_MENU = """
      Select from menu by typing proper number:
      1. register
      2. login
      3. print user data
      4. list all user(only for admin)
      5. change password
      """;
  public static final String BAD_CREDENTIALS = "Bad credentials";
  private static final String ENTER_PHONE_NUMBER = "Enter phone number";
  private static final String ENTER_LOGIN = "Enter login";
  private static final String ENTER_EMAIL = "Enter email";
  private static final String ENTER_PASSWORD = "Enter password";
  private final Scanner scanner;
  private final UserService userService;

  public UserController(Scanner scanner, UserService userService) {
    this.scanner = scanner;
    this.userService = userService;
  }

  public void start() {
    String selectedOption = enterOption();
    switch (selectedOption) {
      case "1" -> userService.register(enterLogin(), enterPassword(), enterEmail(), enterPhoneNumber());
      case "2" -> userService.login(enterLogin(), enterPassword());
      case "3" -> {
        Token token = userService.login(enterLogin(), enterPassword()).
            orElseThrow(() -> new BadCredentialsException(BAD_CREDENTIALS));
        System.out.println(userService.getUser(token.getId()));

      }
      case "4" -> {
        Token token = userService.login(enterLogin(), enterPassword()).
            orElseThrow(() -> new BadCredentialsException(BAD_CREDENTIALS));
        System.out.println(userService.listAll(token).toString());
      }
      case "5" -> {
        Token token = userService.login(enterLogin(), enterPassword()).
            orElseThrow(() -> new BadCredentialsException(BAD_CREDENTIALS));
        userService.changePassword(token, enterPassword());
      }
    }
  }

  private String enterOption() {
    System.out.println(USER_MENU);
    return scanner.nextLine();
  }

  private String enterLogin() {
    System.out.println(ENTER_LOGIN);
    return scanner.nextLine();
  }

  private String enterPassword() {
    System.out.println(ENTER_PASSWORD);
    return scanner.nextLine();
  }

  private String enterEmail() {
    System.out.println(ENTER_EMAIL);
    return scanner.nextLine();
  }

  private String enterPhoneNumber() {
    System.out.println(ENTER_PHONE_NUMBER);
    return scanner.nextLine();
  }
}
