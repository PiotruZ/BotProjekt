package capstone.gd.service;

import capstone.gd.model.user.UserEntity;
import capstone.gd.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

  private final UserRepository userRepository;

  public AuthenticationServiceImpl(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @Override
  public boolean checkIfUserExists(String login) {
    List<UserEntity> users = userRepository.readAll();
    return users.stream().anyMatch(u -> u.getLogin().equals(login));
  }

  @Override
  public boolean checkIfPasswordMatches(String login, String password) {
    List<UserEntity> users = userRepository.readAll();
    Optional<UserEntity> userEntity = users.stream().filter(u -> u.getLogin().equals(login)).findFirst();
    return userEntity.map(user -> user.getPassword().equals(password)).orElse(false);
  }
}
