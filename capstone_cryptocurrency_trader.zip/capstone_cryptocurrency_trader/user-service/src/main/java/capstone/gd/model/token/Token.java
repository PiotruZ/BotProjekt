package capstone.gd.model.token;

import java.time.LocalDateTime;
import java.util.Objects;

public class Token {

  private Integer id;
  private LocalDateTime expired;

  public Token(Integer id, LocalDateTime expired) {
    this.id = id;
    this.expired = expired;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public LocalDateTime getExpired() {
    return expired;
  }

  public void setExpired(LocalDateTime expired) {
    this.expired = expired;
  }

  @Override
  public String toString() {
    return "Token{" +
        "id=" + id +
        ", expired=" + expired +
        '}';
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) return true;
    if (!(object instanceof Token token)) return false;
    return Objects.equals(id, token.id) && Objects.equals(expired, token.expired);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, expired);
  }
}
