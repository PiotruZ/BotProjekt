package capstone.gd.service;

import capstone.gd.model.token.Token;
import capstone.gd.model.user.UserEntity;

import java.util.List;
import java.util.Optional;

public interface UserService {

  Optional<Token> login(String login, String password);

  void register(String login, String password, String email, String phoneNumber);

  UserEntity getUser(Integer userId);

  List<UserEntity> listAll(Token token);

  void changePassword(Token token, String newPassword);
}
