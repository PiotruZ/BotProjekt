package capstone.gd.repository;

import capstone.gd.model.user.UserEntity;

import java.util.List;
import java.util.Optional;

public interface UserRepository {

  List<UserEntity> readAll();

  void save(UserEntity user);

  Optional<UserEntity> getByUserId(Integer userId);

  Optional<UserEntity> getUserByLogin(String login);

  void changePassword(UserEntity user, String newPassword);
}
