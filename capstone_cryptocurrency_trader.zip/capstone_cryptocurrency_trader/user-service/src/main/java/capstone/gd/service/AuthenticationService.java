package capstone.gd.service;

public interface AuthenticationService {
  boolean checkIfUserExists(String login);

  boolean checkIfPasswordMatches(String login, String password);
}
