package capstone.gd.model.user;

public enum Role {
  USER,
  ADMIN
}
