drop table if exists users;
create table users (
id serial primary key,
login varchar(100),
password varchar(100),
email varchar(100),
phone_number varchar(50),
role_id integer
);
insert into users (login, password, email, phone_number) values('login','password','email@email.com','123456');



