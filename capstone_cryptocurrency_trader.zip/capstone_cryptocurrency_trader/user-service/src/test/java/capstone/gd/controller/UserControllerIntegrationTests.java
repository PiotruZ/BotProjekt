package capstone.gd.controller;

import capstone.gd.TestConfig;
import capstone.gd.exception.BadCredentialsException;
import capstone.gd.model.token.Token;
import capstone.gd.model.user.UserEntity;
import capstone.gd.service.AuthenticationService;
import capstone.gd.service.UserService;
import capstone.gd.utils.SqlUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Optional;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;


@ActiveProfiles("test")
@ContextConfiguration(classes = TestConfig.class)
@SpringBootTest
@ExtendWith(MockitoExtension.class)
class UserControllerIntegrationTests {

  @Autowired
  private UserService userService;
  @Autowired
  private AuthenticationService authenticationService;
  @MockBean
  private Scanner scanner;
  @Autowired
  private UserController userController;

  @BeforeAll
  public static void setUp() throws Exception {
    try (Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "")) {
      SqlUtils.executeInitScript(connection);
    }
  }

  @Test
  void shouldRegisterSuccessfullyTest() {
    assertFalse(authenticationService.checkIfUserExists("login2"));
    when(scanner.nextLine()).thenReturn("1").thenReturn("login2").thenReturn("password2").thenReturn("email2@email.com").thenReturn("54321");
    userController.start();
    assertTrue(authenticationService.checkIfUserExists("login2"));
  }

  @Test
  void shouldLoginSuccessfullyTest() {
    when(scanner.nextLine()).thenReturn("2").thenReturn("login").thenReturn("password");
    userController.start();
    Optional<Token> token = userService.login("login", "password");
    assertEquals(1, token.get().getId());
  }

  @Test
  void shouldThrowExceptionWhenLoginWithBadCredentialsTest() {
    when(scanner.nextLine()).thenReturn("3").thenReturn("login").thenReturn("wrongPassword");
    assertThrows(BadCredentialsException.class, () -> userController.start());
  }

  @Test
  void shouldChangePasswordSuccessfullyTest() {
    UserEntity user = userService.getUser(1);
    assertEquals("password", user.getPassword());
    when(scanner.nextLine()).thenReturn("5").thenReturn("login").thenReturn("password").thenReturn("newPassword");
    userController.start();
    UserEntity updatedUser = userService.getUser(1);
    assertEquals("newPassword", updatedUser.getPassword());
  }
}