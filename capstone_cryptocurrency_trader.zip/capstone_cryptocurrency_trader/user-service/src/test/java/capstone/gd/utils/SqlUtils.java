package capstone.gd.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Statement;

public class SqlUtils {

  public static void executeInitScript(Connection connection) throws Exception {
    try (BufferedReader reader = new BufferedReader(new FileReader("src/test/resources/db-init.sql"));
         Statement statement = connection.createStatement()
    ) {
      String line;
      StringBuilder sql = new StringBuilder();
      while ((line = reader.readLine()) != null) {
        sql.append(line);
        if (line.trim().endsWith(";")) {
          statement.execute(sql.toString());
          sql.setLength(0);
        }
      }
    }
  }
}
