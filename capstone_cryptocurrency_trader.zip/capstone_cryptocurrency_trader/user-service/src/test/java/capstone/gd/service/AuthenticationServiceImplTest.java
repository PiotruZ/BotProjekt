package capstone.gd.service;

import capstone.gd.model.user.UserEntity;
import capstone.gd.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthenticationServiceImplTest {

  private static final String LOGIN = "testLogin";
  private static final String PASSWORD = "testPassword";
  private static final String EMAIL = "testemail@email.com";
  private static final String PHONE_NUMBER = "123456789";
  @Mock
  private UserRepository userRepository;
  @InjectMocks
  private AuthenticationServiceImpl authenticationService;

  @Test
  void shouldReturnTrueWhenUserExistsTest() {
    List<UserEntity> users = createUsers();
    when(userRepository.readAll()).thenReturn(users);
    assertTrue(authenticationService.checkIfUserExists(LOGIN));
  }

  @Test
  void shouldReturnFalseWhenUserNotExistTest() {
    List<UserEntity> users = createUsers();
    when(userRepository.readAll()).thenReturn(users);
    assertFalse(authenticationService.checkIfUserExists("nonExistingLogin"));
  }

  @Test
  void shouldReturnTrueWhenPasswordMatchesTest() {
    List<UserEntity> users = createUsers();
    when(userRepository.readAll()).thenReturn(users);
    assertTrue(authenticationService.checkIfPasswordMatches(LOGIN, PASSWORD));
  }

  @Test
  void shouldReturnFalseWhenPasswordDoNotMatchTest() {
    List<UserEntity> users = createUsers();
    when(userRepository.readAll()).thenReturn(users);
    assertFalse(authenticationService.checkIfPasswordMatches(LOGIN, "wrongPassword"));
  }

  private List<UserEntity> createUsers() {
    List<UserEntity> users = new ArrayList<>();
    UserEntity userEntity = new UserEntity(LOGIN, PASSWORD, EMAIL, PHONE_NUMBER);
    users.add(userEntity);
    return users;
  }
}