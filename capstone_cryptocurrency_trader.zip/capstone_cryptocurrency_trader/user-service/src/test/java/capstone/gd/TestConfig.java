package capstone.gd;

import capstone.gd.repository.JdbcManager;
import capstone.gd.repository.UserRepositoryJdbcImpl;
import capstone.gd.service.AuthenticationService;
import capstone.gd.service.AuthenticationServiceImpl;
import capstone.gd.service.UserService;
import capstone.gd.service.UserServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.Scanner;

@ComponentScan("capstone.gd.controller")
@Configuration
@Profile("test")
public class TestConfig {

  @Bean
  public Scanner scanner() {
    return new Scanner(System.in);
  }

  @Bean
  public UserService userService() {
    return new UserServiceImpl(new UserRepositoryJdbcImpl(new JdbcManager("jdbc:h2:~/test", "sa", ""))
        , new AuthenticationServiceImpl(new UserRepositoryJdbcImpl(new JdbcManager("jdbc:h2:~/test", "sa", ""))));
  }

  @Bean
  public AuthenticationService authenticationService() {
    return new AuthenticationServiceImpl(new UserRepositoryJdbcImpl(new JdbcManager("jdbc:h2:~/test", "sa", "")));
  }
}
