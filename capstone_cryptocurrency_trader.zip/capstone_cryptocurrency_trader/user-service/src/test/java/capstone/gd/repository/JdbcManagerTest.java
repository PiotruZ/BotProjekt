package capstone.gd.repository;

import capstone.gd.TestConfig;
import capstone.gd.exception.DataNotFoundException;
import capstone.gd.model.user.UserEntity;
import capstone.gd.utils.SqlUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@ContextConfiguration(classes = TestConfig.class)
@ActiveProfiles("test")
class JdbcManagerTest {
  private JdbcManager jdbcManager;

  @BeforeAll
  public static void setUp() throws Exception {
    try (Connection connection = DriverManager.getConnection("jdbc:h2:~/test", "sa", "")) {
      SqlUtils.executeInitScript(connection);
    }
  }

  @BeforeEach
  public void init() {
    jdbcManager = new JdbcManager("jdbc:h2:~/test", "sa", "");
  }

  @Test
  void shouldReadAllUsersTest() {
    String query = "SELECT * FROM users";
    List<UserEntity> users = jdbcManager.findMany(query, UserEntity::new);
    assertEquals(1, users.size());
  }

  @Test
  void shouldGetUserByLoginSuccessfullyTest() {
    String query = "SELECT * FROM users WHERE login=?";
    UserEntity user = jdbcManager.findOne(query, UserEntity::new, "login");
    assertEquals(1, user.getId());
  }

  @Test
  void shouldGetUserByIdSuccessfullyTest() {
    String query = "SELECT * FROM users WHERE id=?";
    UserEntity user = jdbcManager.findOne(query, UserEntity::new, 1);
    assertEquals("login", user.getLogin());
  }

  @Test
  void shouldThrowExceptionWhenNoResultsFoundTest() {
    String query = "SELECT * FROM users WHERE login=?";
    assertThrows(DataNotFoundException.class, () -> jdbcManager.findOne(query, UserEntity::new, "badLogin"));
  }

  @Test
  void shouldChangePasswordSuccessfullyTest() {
    String selectByLoginQuery = "SELECT * FROM users WHERE login=?";
    UserEntity user = jdbcManager.findOne(selectByLoginQuery, UserEntity::new, "login");
    assertEquals("password", user.getPassword());
    String updateQuery = "UPDATE users SET password='newPassword' WHERE login=?";
    jdbcManager.execute(updateQuery, user.getLogin());
    UserEntity updatedUser = jdbcManager.findOne(selectByLoginQuery, UserEntity::new, "login");
    assertEquals("newPassword", updatedUser.getPassword());
  }
}