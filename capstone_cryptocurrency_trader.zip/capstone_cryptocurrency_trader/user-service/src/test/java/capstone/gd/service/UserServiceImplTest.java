package capstone.gd.service;


import capstone.gd.model.token.Token;
import capstone.gd.model.user.UserEntity;
import capstone.gd.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

  private static final String LOGIN = "testLogin";
  private static final String PASSWORD = "testPassword";
  private static final String EMAIL = "testemail@email.com";
  private static final String PHONE_NUMBER = "123456789";
  private static final int ID = 1;
  @Mock
  private UserRepository userRepository;
  @Mock
  private AuthenticationService authenticationService;
  @InjectMocks
  UserServiceImpl userService;

  @Test
  void shouldReturnTokenWhenUserLoginSuccessfullyTest() {
    UserEntity userEntity = new UserEntity(LOGIN,
        PASSWORD,
        EMAIL,
        PHONE_NUMBER);
    userEntity.setId(ID);
    when(authenticationService.checkIfUserExists(LOGIN)).thenReturn(true);
    when(authenticationService.checkIfPasswordMatches(LOGIN, PASSWORD)).thenReturn(true);
    when(userRepository.getUserByLogin(LOGIN)).thenReturn(Optional.of(userEntity));
    Optional<Token> tokenOptional = userService.login(LOGIN, PASSWORD);
    assertEquals(new Token(ID, LocalDateTime.now().withNano(0).plusMinutes(5)), tokenOptional.get());
  }

  @Test
  void shouldReturnEmptyTokenWhenLoginNotExistTest() {
    when(authenticationService.checkIfUserExists(LOGIN)).thenReturn(false);
    Optional<Token> tokenOptional = userService.login(LOGIN, PASSWORD);
    assertEquals(Optional.empty(), tokenOptional);
  }

  @Test
  void shouldReturnEmptyTokenWhenPasswordNotMatchTest() {
    when(authenticationService.checkIfUserExists(LOGIN)).thenReturn(true);
    when(authenticationService.checkIfPasswordMatches(LOGIN, PASSWORD)).thenReturn(false);
    Optional<Token> tokenOptional = userService.login(LOGIN, PASSWORD);
    assertEquals(Optional.empty(), tokenOptional);
  }

  @Test
  void shouldRegisterSuccessfullyTest() {
    when(userRepository.readAll()).thenReturn(new ArrayList<>());
    userService.register(LOGIN, PASSWORD, EMAIL, PHONE_NUMBER);
    assertEquals(1, userRepository.readAll().size());
    assertEquals(LOGIN, userRepository.readAll().get(0).getLogin());
  }

  @Test
  void shouldGetUserDataSuccessfullyTest() {
    UserEntity userEntity = new UserEntity(LOGIN,
        PASSWORD,
        EMAIL,
        PHONE_NUMBER);
    userEntity.setId(ID);
    userEntity.setRoleId(2);
    when(userRepository.getByUserId(ID)).thenReturn(Optional.of(userEntity));
    UserEntity user = userService.getUser(ID);
    assertEquals(userEntity, user);
  }

  @Test
  void shouldThrowExceptionWhenGetsNonExistingUserTest() {
    assertThrows(RuntimeException.class, () -> userService.getUser(1));
  }

  @Test
  void shouldReturnListOfUsersWhenLoggedAsAdminTest() {
    UserEntity userEntity = new UserEntity(LOGIN,
        PASSWORD,
        EMAIL,
        PHONE_NUMBER);
    userEntity.setId(ID);
    userEntity.setRoleId(1);
    UserEntity userEntity2 = new UserEntity("login2",
        "password2",
        "email2",
        "phoneNumber2");
    userEntity2.setId(2);
    when(userRepository.getByUserId(1)).thenReturn(Optional.of(userEntity));
    when(userRepository.readAll()).thenReturn(List.of(userEntity, userEntity2));
    Token token = new Token(1, LocalDateTime.now().withNano(0));
    List<UserEntity> users = userService.listAll(token);
    assertEquals(2, users.size());
    assertEquals(LOGIN, users.get(0).getLogin());
  }

  @Test
  void shouldReturnEmptyListWhenLoggedAsUserTest() {
    UserEntity userEntity = new UserEntity(LOGIN,
        PASSWORD,
        EMAIL,
        PHONE_NUMBER);
    userEntity.setId(ID);
    userEntity.setRoleId(2);
    when(userRepository.getByUserId(ID)).thenReturn(Optional.of(userEntity));
    Token token = new Token(ID, LocalDateTime.now().withNano(0));
    List<UserEntity> users = userService.listAll(token);
    assertEquals(Collections.emptyList(), users);
  }

  @Test
  void shouldThrowExceptionWhenListsUsersWithInvalidTokenTest() {
    Token token = new Token(ID, LocalDateTime.now().withNano(0));
    assertThrows(RuntimeException.class, () -> userService.listAll(token));
  }
}