package orderexecutionservice.capstone.gd.service;

import orderexecutionservice.capstone.gd.apiclient.TradingApiClient;
import orderexecutionservice.capstone.gd.dto.ReportDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.entity.TransactionEntity;
import orderexecutionservice.capstone.gd.mapper.TransactionMapper;
import orderexecutionservice.capstone.gd.model.TransactionType;
import orderexecutionservice.capstone.gd.repository.TransactionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderExecutionServiceImplTest {

    public static final String BROKER_1 = "Broker1";
    public static final String VAL_100 = "100.00";
    public static final String CRYPTO = "BTC";

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private TradingApiClient tradingApiClient;

    @Mock
    TransactionMapper transactionMapper;

    @InjectMocks
    private OrderExecutionServiceImpl orderExecutionService;

    @Test
    void testGetBalance() {
        // given
        int userId = 1;

        Map<String, BigDecimal> balances = new HashMap<>();
        balances.put("USD", new BigDecimal(VAL_100));
        balances.put(CRYPTO, new BigDecimal("0.50"));
        BigDecimal sumBalance = new BigDecimal("100.50");

        ReportDto expectedReport = new ReportDto("User with id: " + userId, balances, sumBalance);

        when(tradingApiClient.getBalance(userId)).thenReturn(balances);

        // when
        ReportDto actualReport = orderExecutionService.getBalance(userId);

        // then
        assertEquals(expectedReport, actualReport);
        verify(tradingApiClient).getBalance(userId);

    }

    @Test
    void testGetTransactionHistory() {
        // given
        int userId = 1;

        TransactionEntity transactionEntity = new TransactionEntity(1, userId, BROKER_1, CRYPTO, BigDecimal.ONE, TransactionType.BUY.getValue());
        TransactionDto transactionDto = new TransactionDto(userId, BROKER_1, CRYPTO, BigDecimal.ONE, TransactionType.BUY.getValue());
        List<TransactionEntity> repositoryTransactions = Collections.singletonList(transactionEntity);
        List<TransactionDto> expectedTransactions = Collections.singletonList(transactionDto);

        when(transactionRepository.getUserTransactions(userId)).thenReturn(repositoryTransactions);
        when(transactionMapper.entityToDto(transactionEntity)).thenReturn(transactionDto);

        // when
        List<TransactionDto> actualTransactions = orderExecutionService.getTransactionHistory(userId);

        // then
        assertEquals(expectedTransactions, actualTransactions);
        verify(transactionRepository).getUserTransactions(userId);
    }

    @Test
    void testExecuteTransaction() {
        // given
        int userId = 1;
        TransactionDto transactionDto = new TransactionDto(1, BROKER_1, CRYPTO, BigDecimal.ONE, TransactionType.BUY.getValue());
        TransactionEntity transactionEntity = new TransactionEntity(0, userId, BROKER_1, CRYPTO, BigDecimal.ONE, TransactionType.BUY.getValue());
        when(transactionMapper.dtoToEntity(transactionDto)).thenReturn(transactionEntity);

        // when
        orderExecutionService.executeTransaction(transactionDto);

        // then
        verify(tradingApiClient).performTransaction(transactionDto);
        verify(transactionRepository).saveTransaction(any(TransactionEntity.class));
    }

}