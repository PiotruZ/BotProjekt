package orderexecutionservice.capstone.gd.utils;

import orderexecutionservice.capstone.gd.dto.TransactionDto;

import java.math.BigDecimal;

public class TransactionTestDataUtils {

    private TransactionTestDataUtils() {
    }

    public static TransactionDto createTransactionDto1(){
        return TransactionDto.builder()
                .userId(1)
                .type("Buy")
                .amount(BigDecimal.valueOf(34))
                .brokerName("Broker1")
                .cryptocurrencyName("BTC")
                .build();
    }

    public static TransactionDto createTransactionDto2(){
        return TransactionDto.builder()
                .userId(1)
                .type("Buy")
                .amount(BigDecimal.valueOf(4))
                .brokerName("Broker1")
                .cryptocurrencyName("ETH")
                .build();
    }

    public static TransactionDto createTransactionDto3(){
        return TransactionDto.builder()
                .userId(1)
                .type("Sell")
                .amount(BigDecimal.valueOf(127))
                .brokerName("Broker1")
                .cryptocurrencyName("DOGE")
                .build();
    }

}
