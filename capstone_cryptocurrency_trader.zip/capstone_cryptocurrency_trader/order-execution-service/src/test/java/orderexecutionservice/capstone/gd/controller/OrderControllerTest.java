package orderexecutionservice.capstone.gd.controller;

import orderexecutionservice.capstone.gd.dto.ReportDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.model.TransactionType;
import orderexecutionservice.capstone.gd.service.OrderExecutionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderControllerTest {

    public static final String BROKER_1 = "Broker1";
    public static final String VAL_100 = "100.00";
    public static final String CRYPTO = "BTC";

    @Mock
    private OrderExecutionService orderExecutionService;

    @InjectMocks
    private OrderControllerImpl orderController;

    @Test
    void testGetBalance() {
        // given
        int userId = 1;
        String username = "user1";
        Map<String, BigDecimal> balances = new HashMap<>();
        balances.put("USD", new BigDecimal(VAL_100));
        balances.put(CRYPTO, new BigDecimal("0.5"));
        BigDecimal sumBalance = new BigDecimal("100.50");

        ReportDto expectedReport = new ReportDto(username, balances, sumBalance);
        when(orderExecutionService.getBalance(userId)).thenReturn(expectedReport);

        // when
        ReportDto actualReport = orderController.getBalance(userId);

        // then
        assertEquals(expectedReport, actualReport);
        verify(orderExecutionService).getBalance(userId);
    }

    @Test
    void testGetTransactionHistory() {
        // given
        int userId = 1;

        BigDecimal amount = new BigDecimal("0.1");
        TransactionDto expectedTransaction = new TransactionDto(userId, BROKER_1, CRYPTO, amount, TransactionType.BUY.getValue());

        List<TransactionDto> transactions = Collections.singletonList(expectedTransaction);
        when(orderExecutionService.getTransactionHistory(userId)).thenReturn(transactions);

        // when
        List<TransactionDto> actualTransactions = orderController.getTransactionHistory(userId);

        // then
        assertEquals(Collections.singletonList(expectedTransaction), actualTransactions);
        verify(orderExecutionService).getTransactionHistory(userId);
    }

    @Test
    void testExecuteTransaction() {
        // given
        int userId = 1;
        TransactionDto transactionDto = new TransactionDto(userId, BROKER_1, CRYPTO, BigDecimal.ONE, TransactionType.BUY.getValue());

        // when
        orderController.executeTransaction(transactionDto);

        // then
        verify(orderExecutionService).executeTransaction(transactionDto);
    }
}
