package orderexecutionservice.capstone.gd.apiclient;

import orderexecutionservice.capstone.gd.dto.ApiKeyDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.model.BrokerAccount;
import orderexecutionservice.capstone.gd.model.TransactionType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TradingApiClientTest {
    public static final String BROKER_1 = "Broker1";
    public static final String BROKER_2 = "Broker2";
    public static final String VAL_100 = "100.00";
    public static final String VAL_50 = "50.00";
    public static final String CRYPTO = "BTC";

    @Mock
    private Map<Integer, List<ApiKeyDto>> mockApiKeys;

    @Mock
    private Map<Integer, List<BrokerAccount>> mockUserBalances;

    @InjectMocks
    private TradingApiClient tradingApiClient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetBalance() {
        // given
        int userId = 1;
        List<BrokerAccount> brokerAccounts = List.of(
                new BrokerAccount(userId, BROKER_1, new BigDecimal(VAL_100)),
                new BrokerAccount(userId, BROKER_2, new BigDecimal(VAL_50))
        );
        when(mockUserBalances.get(userId)).thenReturn(brokerAccounts);

        // when
        Map<String, BigDecimal> result = tradingApiClient.getBalance(userId);

        // then
        assertEquals(2, result.size());
        assertEquals(new BigDecimal(VAL_100), result.get(BROKER_1));
        assertEquals(new BigDecimal(VAL_50), result.get(BROKER_2));
    }

    @Test
    void testPerformTransaction() {
        // given
        int userId = 1;
        TransactionDto transaction = new TransactionDto(userId, BROKER_1, CRYPTO, new BigDecimal(VAL_50), TransactionType.BUY.getValue());
        when(mockUserBalances.get(userId)).thenReturn(null);

        // when
        tradingApiClient.performTransaction(transaction);

        // then
        verify(mockUserBalances).put(eq(userId), anyList());
    }

    @Test
    void testPerformTransactionWithExistingBroker() {
        // given
        int userId = 1;
        TransactionDto transaction = new TransactionDto(userId, BROKER_1, CRYPTO, new BigDecimal(VAL_50), TransactionType.BUY.getValue());
        BrokerAccount existingAccount = new BrokerAccount(userId, BROKER_1, new BigDecimal(VAL_100));
        List<BrokerAccount> existingAccounts = Collections.singletonList(existingAccount);

        when(mockUserBalances.get(userId)).thenReturn(existingAccounts);

        // when
        tradingApiClient.performTransaction(transaction);

        // then
        assertEquals(new BigDecimal("150.00"), existingAccount.getBalance());
    }
}