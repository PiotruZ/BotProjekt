package orderexecutionservice.capstone.gd.repository;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

@SpringBootTest
@ActiveProfiles("test")
class DatabaseManagerTest {

    @Autowired
    private DatabaseManager databaseManager;

    @BeforeAll
    public static void setUp() throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1", "sa", "")) {
            executeSqlScript(connection, "src/test/resources/create_table.sql");
            executeSqlScript(connection, "src/test/resources/insert_data.sql");
        }
    }

    @Test
    public void testFindOne() {
        String query = "SELECT name FROM brokers WHERE id = ?";
        String result = databaseManager.findOne(query, rs -> {
            try {
                return rs.getString("name");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }, 1);

        assertEquals("Broker1", result);
    }

    @Test
    public void testFindMany() {
        String query = "SELECT name FROM brokers WHERE id > ? ORDER BY id";
        List<String> results = databaseManager.findMany(query, rs -> {
            try {
                return rs.getString("name");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }, 1);

        assertEquals("Broker2", results.get(0));
        assertEquals("Broker3", results.get(1));
    }

    @Test
    public void testExecute() {
        String insertQuery = "INSERT INTO brokers (name) VALUES (?)";
        String selectQuery = "SELECT COUNT(*) FROM brokers WHERE name = ?";

        databaseManager.execute(insertQuery, preparedStatement -> {
            try {
                preparedStatement.setString(1, "TestBroker1");
            } catch (SQLException e) {
                fail("Error setting parameters: " + e.getMessage());
            }
        });

        Integer count = databaseManager.findOne(selectQuery, rs -> {
            try {
                return rs.getInt(1);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }, "TestBroker1");

        assertEquals(1, count);
    }

    @Test
    public void testExecuteWithConsumer() {
        String insertQuery = "INSERT INTO brokers (name) VALUES (?)";
        databaseManager.execute(insertQuery, "TestBroker2");

        String selectQuery = "SELECT COUNT(*) FROM brokers WHERE name = ?";
        Integer count = databaseManager.findOne(selectQuery, rs -> {
            try {
                return rs.getInt(1);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }, "TestBroker2");

        assertEquals(1, count);
    }

    private static void executeSqlScript(Connection connection, String scriptPath) throws Exception {
        try (BufferedReader reader = new BufferedReader(new FileReader(scriptPath));
             Statement statement = connection.createStatement()
        ) {
            String line;
            StringBuilder sql = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                sql.append(line);
                if (line.trim().endsWith(";")) {
                    statement.execute(sql.toString());
                    sql.setLength(0);
                }
            }
        }
    }
}