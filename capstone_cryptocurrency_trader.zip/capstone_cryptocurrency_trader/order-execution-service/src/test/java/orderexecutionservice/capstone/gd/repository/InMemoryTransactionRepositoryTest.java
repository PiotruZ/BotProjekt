package orderexecutionservice.capstone.gd.repository;

import orderexecutionservice.capstone.gd.entity.TransactionEntity;
import orderexecutionservice.capstone.gd.model.TransactionType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class InMemoryTransactionRepositoryTest {

    public static final String BROKER_1 = "Broker1";
    public static final String BROKER_2 = "Broker2";
    public static final String VAL_20 = "20.00";
    public static final String VAL_30 = "30.00";
    public static final String VAL_50 = "50.00";
    public static final String CRYPTO = "BTC";
    public static final String CRYPTO2 = "ETH";

    private InMemoryTransactionRepository repository;

    @BeforeEach
    void setUp() {
        repository = new InMemoryTransactionRepository();
    }

    @Test
    void testSaveTransactionAndGetTransaction() {
        // given
        TransactionEntity transaction = new TransactionEntity(1, 1, BROKER_1, CRYPTO, new BigDecimal(VAL_50), TransactionType.BUY.getValue());

        // when
        repository.saveTransaction(transaction);
        Optional<TransactionEntity> retrievedTransaction = repository.getTransaction(transaction.getId());

        // then
        assertTrue(retrievedTransaction.isPresent());
        assertEquals(transaction, retrievedTransaction.get());
    }

    @Test
    void testGetTransactionWithNonexistentId() {
        // when
        Optional<TransactionEntity> retrievedTransaction = repository.getTransaction(1);

        // then
        assertFalse(retrievedTransaction.isPresent());
    }

    @Test
    void testGetUserTransactions() {
        // given
        int userId = 1;
        int secondUserId = 2;
        TransactionEntity transaction1 = new TransactionEntity(0, userId, BROKER_1, CRYPTO, new BigDecimal(VAL_50), TransactionType.BUY.getValue());
        TransactionEntity transaction2 = new TransactionEntity(0, userId, BROKER_2, CRYPTO2, new BigDecimal(VAL_30), TransactionType.BUY.getValue());
        TransactionEntity transaction3 = new TransactionEntity(0, secondUserId, BROKER_1, "BTC", new BigDecimal(VAL_20), TransactionType.BUY.getValue());

        // when
        repository.saveTransaction(transaction1);
        repository.saveTransaction(transaction2);
        repository.saveTransaction(transaction3);
        List<TransactionEntity> user1Transactions = repository.getUserTransactions(1);
        List<TransactionEntity> user2Transactions = repository.getUserTransactions(2);

        // then
        assertEquals(List.of(transaction1, transaction2), user1Transactions);
        assertEquals(List.of(transaction3), user2Transactions);
    }

}