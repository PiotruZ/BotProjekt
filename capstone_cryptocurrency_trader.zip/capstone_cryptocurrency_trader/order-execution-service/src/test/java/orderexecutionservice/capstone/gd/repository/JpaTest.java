package orderexecutionservice.capstone.gd.repository;

import jakarta.persistence.EntityExistsException;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import orderexecutionservice.capstone.gd.entity.Broker;
import orderexecutionservice.capstone.gd.entity.Transaction;
import orderexecutionservice.capstone.gd.model.TransactionType;
import orderexecutionservice.capstone.gd.repository.jpa.BrokerJpaRepository;
import orderexecutionservice.capstone.gd.repository.jpa.TransactionJpaRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;


@Slf4j
@ActiveProfiles("test")
@Sql(scripts = "classpath:clean_db.sql", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
@DataJpaTest
public class JpaTest {

    @Autowired
    EntityManager entityManager;

    @Autowired
    TransactionJpaRepository transactionJpaRepository;

    @Autowired
    BrokerJpaRepository brokerJpaRepository;


    @Test
    void saveParentUsingRepositorySaveWithoutId() {
        //given
        Broker broker = getBrokerWithNameAndNoTransactions();

        //when
        brokerJpaRepository.save(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();

        //then
        assertThat(brokers.size()).isEqualTo(1);
        assertThat(brokers.contains(broker)).isTrue();
    }

    @Test
    void saveParentUsingEntityManagerPersistWithoutId() {
        //given
        Broker broker = getBrokerWithNameAndNoTransactions();

        //when
        entityManager.persist(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();

        //then
        assertThat(brokers.size()).isEqualTo(1);
        assertThat(brokers.contains(broker)).isTrue();
    }

    @Test
    void saveParentUsingEntityManagerMergeWithoutId() {
        //given
        Broker broker = getBrokerWithNameAndNoTransactions();

        //when
        entityManager.merge(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();

        //then
        assertThat(brokers.size()).isEqualTo(1);
        assertThat(brokers.contains(broker)).isTrue();
    }

    @Test
    void saveParentUsingRepositorySaveWithId() {
        //given
        Broker broker = Broker.builder()
                .id(1L)
                .name("Broker123")
                .build();

        //when
        brokerJpaRepository.save(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();

        //then
        assertThat(brokers.size()).isEqualTo(1);
        assertThat(brokers.contains(broker)).isTrue();
    }

    @Test
    void saveParentUsingEntityManagerPersistWithId() {
        //given
        Broker broker = Broker.builder()
                .id(1L)
                .name("Broker1234")
                .build();
        //when, then
        assertThrows(EntityExistsException.class, () -> entityManager.persist(broker));

        // broker with id is considered to be detached entity because it has id
    }

    @Test
    void saveParentUsingEntityManagerMergeWithId() {
        //given
        Broker broker = Broker.builder()
                .id(1L)
                .name("Broker12345")
                .build();
        //when
        entityManager.merge(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();

        //then
        assertThat(brokers.size()).isEqualTo(1);
        assertThat(brokers.contains(broker)).isTrue();
    }

    @Test
    void overrideParentWithRepositorySave() {
        //given
        String newName = "Broker4323454354";
        Broker broker = Broker.builder()
                .id(1L)
                .name("Broker432")
                .build();

        Broker broker2 = Broker.builder()
                .id(1L)
                .name(newName)
                .build();

        //when
        brokerJpaRepository.save(broker);
        Broker savedBroker = brokerJpaRepository.save(broker2);
        entityManager.flush();

        Optional<Broker> brokerFromDB = brokerJpaRepository.findById(savedBroker.getId());

        //then
        brokerFromDB.ifPresentOrElse(
                b -> assertThat(b.getName()).isEqualTo(newName),
                () -> fail("Broker not found in db")
        );

    }

    @Test
    void overrideParentWithEntityManagerPersist() {
        //given
        String newName = "Broker4323454354";
        Broker broker = getBrokerWithNameAndNoTransactions();
        Broker broker2 = Broker.builder()
                .id(1L)
                .name(newName)
                .build();

        //when, then
        entityManager.persist(broker);
        assertThrows(EntityExistsException.class, () -> entityManager.persist(broker2));
        // second broker is considered to be detached entity and exception is thrown
    }

    @Test
    void overrideParentWithEntityManagerMerge() {
        //given
        String changedName = "Broker4323454354";
        Broker broker = new Broker(1L, "Broker432", null);
        Broker merged = entityManager.merge(broker);
        Broker broker2 = new Broker(merged.getId(), changedName, null);

        //when
        entityManager.merge(broker2);
        List<Broker> brokers = brokerJpaRepository.findAll();

        //then
        assertThat(brokers.size()).isEqualTo(1);
        assertThat(brokers.get(0).getName()).isEqualTo(changedName);
        // update executed
    }

    @Test
    void saveParentWithChildrenNotInDatabaseJpaRepository() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        brokerJpaRepository.save(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(brokers.get(0).getTransactions()).contains(transactions.get(0));

    }

    @Test
    void saveParentWithChildrenNotInDatabaseEntityManagerPersist() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        entityManager.persist(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(brokers.get(0).getTransactions()).contains(transactions.get(0));
    }

    @Test
    void saveParentWithChildrenNotInDatabaseEntityManagerMerge() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        entityManager.merge(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(brokers.get(0).getTransactions().contains(transactions.get(0))).isTrue();

    }

    @Test
    void saveParentWithChildrenInDatabaseJpaRepository() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        transactionJpaRepository.save(transaction1);
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        brokerJpaRepository.save(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(brokers.get(0).getTransactions().contains(transactions.get(0))).isTrue();
    }

    @Test
    void saveParentWithChildrenInDatabaseEntityManagerPersist() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        entityManager.persist(transaction1);
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        entityManager.persist(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(brokers.get(0).getTransactions().contains(transactions.get(0))).isTrue();

    }

    @Test
    void saveParentWithChildrenInDatabaseEntityManagerMerge() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        entityManager.persist(transaction1);
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        entityManager.merge(broker);
        List<Broker> brokers = brokerJpaRepository.findAll();
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(brokers.get(0).getTransactions()).contains(transactions.get(0));
    }

    @Test
    void saveChildWithParentInitializedButNotInDBJpaRepository() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        transactionJpaRepository.save(transaction1);

        //then
        assertThrows(IllegalStateException.class, () -> entityManager.flush());
        // Trying to save child with parent that is not already in database ends with exception because cascade is defined only on parent
    }

    @Test
    void saveChildWithParentInitializedButNotInDBEntityManagerPersist() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        entityManager.persist(transaction1);

        //then
        assertThrows(IllegalStateException.class, () -> entityManager.flush());
        // Trying to save child with parent that is not already in database ends with exception because cascade is defined only on parent
    }

    @Test
    void saveChildWithParentInitializedButNotInDBEntityManagerMerge() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        broker.addTransaction(transaction1);

        //when
        entityManager.merge(transaction1);

        //then
        assertThrows(IllegalStateException.class, () -> entityManager.flush());
        // Trying to save child with parent that is not already in database ends with exception because cascade is defined only on parent
    }

    @Test
    void saveChildWithParentInitializedButDetachedFromContextJpaRepository() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        brokerJpaRepository.save(broker);
        entityManager.flush();
        entityManager.detach(broker);
        entityManager.flush();
        broker.addTransaction(transaction1);

        //when
        transactionJpaRepository.save(transaction1);
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(transactions.get(0).getBroker()).isEqualTo(broker);
    }

    @Test
    void saveChildWithParentInitializedButDetachedFromContextEntityManagerPersist() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        entityManager.persist(broker);
        entityManager.flush();
        entityManager.detach(broker);
        entityManager.flush();
        broker.addTransaction(transaction1);

        //when
        entityManager.persist(transaction1);
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(transactions.get(0).getBroker()).isEqualTo(broker);
    }

    @Test
    void saveChildWithParentInitializedButDetachedFromContextEntityManagerMerge() {
        //given
        Transaction transaction1 = getBuy10BtcTransaction();
        Broker broker = getBrokerWithNameAndNoTransactions();
        entityManager.persist(broker);
        entityManager.flush();
        entityManager.detach(broker);
        entityManager.flush();
        broker.addTransaction(transaction1);

        //when
        entityManager.merge(transaction1);
        List<Transaction> transactions = transactionJpaRepository.findAll();

        //then
        assertThat(transactions.get(0).getBroker()).isEqualTo(broker);
    }

    @Test
    void fetchModifyAndDoNotSave() {
        //given
        String newName = "new name";
        Broker broker = getBrokerWithNameAndNoTransactions();

        //when
        Broker savedBroker = brokerJpaRepository.save(broker);
        entityManager.flush();
        brokerJpaRepository.findById(savedBroker.getId()).ifPresent(
                b -> b.setName(newName)
        );
        entityManager.flush();

        //then
        brokerJpaRepository.findById(savedBroker.getId()).ifPresent(
                b -> assertThat(b.getName()).isEqualTo(newName)
        );
    }

    @Test
    @Transactional
    void fetchModifyAndDoNotSaveInTransaction() {
        //given
        String newName = "new name";
        Broker broker = getBrokerWithNameAndNoTransactions();

        //when
        Broker savedBroker = brokerJpaRepository.save(broker);
        entityManager.flush();
        brokerJpaRepository.findById(savedBroker.getId()).ifPresent(
                b -> b.setName(newName)
        );
        entityManager.flush();

        //then
        brokerJpaRepository.findById(savedBroker.getId()).ifPresent(
                b -> assertThat(b.getName()).isEqualTo(newName)
        );
    }

    private static Broker getBrokerWithNameAndNoTransactions() {
        return Broker.builder()
                .name("Broker123")
                .transactions(new HashSet<>())
                .build();
    }

    private static Transaction getBuy10BtcTransaction() {
        return Transaction.builder()
                .amount(BigDecimal.TEN)
                .type(TransactionType.BUY.getValue())
                .userId(1)
                .cryptocurrencyName("BTC")
                .build();
    }

}
