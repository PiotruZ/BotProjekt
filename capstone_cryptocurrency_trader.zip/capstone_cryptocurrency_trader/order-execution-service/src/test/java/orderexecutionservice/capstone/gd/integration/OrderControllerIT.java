package orderexecutionservice.capstone.gd.integration;

import orderexecutionservice.capstone.gd.controller.OrderController;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.entity.TransactionEntity;
import orderexecutionservice.capstone.gd.repository.TransactionRepository;
import orderexecutionservice.capstone.gd.utils.TransactionTestDataUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
public class OrderControllerIT {
    public static final String JDBC_URL = "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1";

    @Autowired
    OrderController orderController;

    @Autowired
    TransactionRepository transactionRepository;

    @BeforeAll
    public static void setUp() throws Exception {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, "sa", "")) {
            executeSqlScript(connection, "src/test/resources/create_table.sql");
        }
    }

    @BeforeEach
    void init() throws Exception {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, "sa", "")) {
            executeSqlScript(connection, "src/test/resources/clean_db.sql");
            executeSqlScript(connection, "src/test/resources/insert_brokers.sql");
        }
    }

    @Test
    void testExecuteTransaction(){
        //given
        TransactionDto transactionDto = TransactionTestDataUtils.createTransactionDto1();

        //when
        orderController.executeTransaction(transactionDto);
        List<TransactionEntity> userTransactions = transactionRepository.getUserTransactions(transactionDto.userId());

        //then
        assertThat(userTransactions.size()).isEqualTo(1);
    }

    @Test
    void testExecuteSomeTransactions(){
        //given
        int userId = 1;
        TransactionDto transactionDto1 = TransactionTestDataUtils.createTransactionDto1().toBuilder().userId(userId).build();
        TransactionDto transactionDto2 = TransactionTestDataUtils.createTransactionDto2().toBuilder().userId(userId).build();
        TransactionDto transactionDto3 = TransactionTestDataUtils.createTransactionDto3().toBuilder().userId(userId).build();
        BigDecimal expectedSum = transactionDto1.amount().add(transactionDto2.amount()).add(transactionDto3.amount());

        //when
        orderController.executeTransaction(transactionDto1);
        orderController.executeTransaction(transactionDto2);
        orderController.executeTransaction(transactionDto3);
        List<TransactionEntity> userTransactions = transactionRepository.getUserTransactions(1);
        BigDecimal userSum = userTransactions.stream().map(TransactionEntity::getAmount).reduce(BigDecimal::add).orElse(BigDecimal.ZERO).stripTrailingZeros();

        //then
        assertThat(userTransactions.size()).isEqualTo(3);
        assertThat(userSum).isEqualTo(expectedSum);
    }

    @Test
    void testGetTransactionHistory(){
        //given
        int userId = 1;
        TransactionDto transactionDto1 = TransactionTestDataUtils.createTransactionDto1().toBuilder().userId(userId).build();
        TransactionDto transactionDto2 = TransactionTestDataUtils.createTransactionDto2().toBuilder().userId(userId).build();
        TransactionDto transactionDto3 = TransactionTestDataUtils.createTransactionDto3().toBuilder().userId(userId).build();

        //when
        orderController.executeTransaction(transactionDto1);
        orderController.executeTransaction(transactionDto2);
        orderController.executeTransaction(transactionDto3);
        List<TransactionDto> userTransactions = orderController.getTransactionHistory(1);

        //then
        assertThat(userTransactions.size()).isEqualTo(3);
    }


    private static void executeSqlScript(Connection connection, String scriptPath) throws Exception {
        try (BufferedReader reader = new BufferedReader(new FileReader(scriptPath));
             Statement statement = connection.createStatement()
        ) {
            String line;
            StringBuilder sql = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                sql.append(line);
                if (line.trim().endsWith(";")) {
                    statement.execute(sql.toString());
                    sql.setLength(0);
                }
            }
        }
    }

}
