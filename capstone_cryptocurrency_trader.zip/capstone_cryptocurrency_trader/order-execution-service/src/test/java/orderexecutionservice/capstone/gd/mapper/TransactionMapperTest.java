package orderexecutionservice.capstone.gd.mapper;

import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.entity.TransactionEntity;
import orderexecutionservice.capstone.gd.model.TransactionType;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class TransactionMapperTest {

    public static final String BROKER_1 = "Broker1";
    public static final String VAL_50 = "50.00";
    public static final String CRYPTO = "BTC";

    @Test
    void testEntityToDto() {
        // given
        TransactionEntity transactionEntity = new TransactionEntity(1, 1,BROKER_1, CRYPTO, new BigDecimal(VAL_50), TransactionType.BUY.getValue());
        TransactionMapper transactionMapper = new TransactionMapper();

        // when
        TransactionDto transactionDto = transactionMapper.entityToDto(transactionEntity);

        // then
        assertEquals(1, transactionDto.userId());
        assertEquals(BROKER_1, transactionDto.brokerName());
        assertEquals(CRYPTO, transactionDto.cryptocurrencyName());
        assertEquals(new BigDecimal(VAL_50), transactionDto.amount());
    }

    @Test
    void testDtoToEntity() {
        // given
        TransactionDto transactionDto = new TransactionDto(1, BROKER_1, CRYPTO, new BigDecimal(VAL_50), TransactionType.BUY.getValue());
        TransactionMapper transactionMapper = new TransactionMapper();

        // when
        TransactionEntity transactionEntity = transactionMapper.dtoToEntity(transactionDto);

        // then
        assertEquals(0, transactionEntity.getId());
        assertEquals(1, transactionEntity.getUserId());
        assertEquals(BROKER_1, transactionEntity.getBrokerName());
        assertEquals(CRYPTO, transactionEntity.getCryptocurrencyName());
        assertEquals(new BigDecimal(VAL_50), transactionEntity.getAmount());
    }
}
