CREATE TABLE IF NOT EXISTS brokers(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS api_keys(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    broker_id BIGINT NOT NULL,
    api_key VARCHAR(255) NOT NULL,
    FOREIGN KEY (broker_id) REFERENCES brokers(id)
);

CREATE TABLE IF NOT EXISTS transactions(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    broker_id BIGINT NOT NULL,
    cryptocurrency VARCHAR(5),
    amount NUMERIC,
    transaction_type VARCHAR(10),
    FOREIGN KEY (broker_id) REFERENCES brokers(id)
);
