DELETE FROM transactions where 1=1;
DELETE FROM api_keys where 1=1;
DELETE FROM brokers where 1=1;
