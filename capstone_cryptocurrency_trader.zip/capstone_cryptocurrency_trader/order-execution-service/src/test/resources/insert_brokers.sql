INSERT INTO brokers (name) VALUES
('Broker1'),
('Broker2'),
('Broker3'),
('Broker4'),
('Broker5');