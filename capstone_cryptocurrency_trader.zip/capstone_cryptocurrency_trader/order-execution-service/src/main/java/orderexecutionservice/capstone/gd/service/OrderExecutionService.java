package orderexecutionservice.capstone.gd.service;

import orderexecutionservice.capstone.gd.dto.ReportDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;

import java.util.List;

public interface OrderExecutionService {
    ReportDto getBalance(Integer userId);
    List<TransactionDto> getTransactionHistory(Integer userId);
    void executeTransaction(TransactionDto transactionDto);
}
