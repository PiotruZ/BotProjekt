package orderexecutionservice.capstone.gd.dto;

import java.math.BigDecimal;
import java.util.Map;

public record ReportDto(String username, Map<String, BigDecimal> balances, BigDecimal sumBalance) {
}
