package orderexecutionservice.capstone.gd.repository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

@Slf4j
@Component
@RequiredArgsConstructor
public final class DatabaseManager {

    private final DataSource dataSource;

    public void execute(String query, Object... args) {
        try (Connection connection = dataSource.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)
        ) {

            for (int i = 0; i < args.length; i++) {
                preparedStatement.setObject(i + 1, args[i]);
            }

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            log.warn(e.getMessage());
        }
    }


    public void execute(String query, Consumer<PreparedStatement> consumer) {

        try (Connection connection = dataSource.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)
        ) {

            consumer.accept(preparedStatement);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            log.warn(e.getMessage());
        }
    }

    public <T> T findOne(String query, Function<ResultSet, T> mapper, Object... args) {
        try (Connection connection = dataSource.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)
        ) {

            for (int i = 0; i < args.length; i++) {
                preparedStatement.setObject(i + 1, args[i]);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (!resultSet.next()) {
                    throw new RuntimeException("Result set is empty!");
                }
                return mapper.apply(resultSet);
            }

        } catch (SQLException e) {
            log.warn(e.getMessage());
            return null;
        }
    }


    public <T> List<T> findMany(String query, Function<ResultSet, T> mapper, Object... args) {
        List<T> resultList = new ArrayList<>();
        try (Connection connection = dataSource.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)
        ) {

            for (int i = 0; i < args.length; i++) {
                preparedStatement.setObject(i + 1, args[i]);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    T mappedResult = mapper.apply(resultSet);
                    resultList.add(mappedResult);
                }
            }

        } catch (SQLException e) {
            log.warn(e.getMessage());
        }
        return resultList;
    }

}
