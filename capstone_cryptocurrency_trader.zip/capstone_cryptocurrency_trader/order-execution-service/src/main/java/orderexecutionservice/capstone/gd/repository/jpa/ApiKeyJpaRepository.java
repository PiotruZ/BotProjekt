package orderexecutionservice.capstone.gd.repository.jpa;

import orderexecutionservice.capstone.gd.entity.ApiKey;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApiKeyJpaRepository extends JpaRepository<ApiKey, Long> {
}
