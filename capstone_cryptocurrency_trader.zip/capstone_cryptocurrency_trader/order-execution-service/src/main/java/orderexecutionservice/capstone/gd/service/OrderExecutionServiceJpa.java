package orderexecutionservice.capstone.gd.service;

import lombok.AllArgsConstructor;
import orderexecutionservice.capstone.gd.apiclient.TradingApiClient;
import orderexecutionservice.capstone.gd.dto.ReportDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.entity.Broker;
import orderexecutionservice.capstone.gd.entity.Transaction;
import orderexecutionservice.capstone.gd.mapper.TransactionJpaMapper;
import orderexecutionservice.capstone.gd.repository.jpa.BrokerJpaRepository;
import orderexecutionservice.capstone.gd.repository.jpa.TransactionJpaRepository;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
@Primary
@AllArgsConstructor
public class OrderExecutionServiceJpa implements OrderExecutionService {
    private final TransactionJpaRepository transactionRepository;
    private final BrokerJpaRepository brokerJpaRepository;
    private final TradingApiClient tradingApiClient;
    private final TransactionJpaMapper transactionMapper;

    @Override
    public ReportDto getBalance(Integer userId) {
        Map<String, BigDecimal> balance = tradingApiClient.getBalance(userId);

        BigDecimal sum = BigDecimal.ZERO;
        for (BigDecimal amount : balance.values()) {
            sum = sum.add(amount);
        }

        // TODO: call to user Service for username associated with this id

        return new ReportDto("User with id: " + userId, balance, sum);
    }

    @Override
    public List<TransactionDto> getTransactionHistory(Integer userId) {
        return transactionRepository.findByUserId(userId)
                .stream()
                .map(transactionMapper::entityToDto)
                .toList();
    }

    @Override
    public void executeTransaction(TransactionDto transactionDto) {

        String brokerName = transactionDto.brokerName();
        Broker broker = brokerJpaRepository.findByName(brokerName);

        Transaction transactionEntity = transactionMapper.dtoToEntity(transactionDto, broker);

        tradingApiClient.performTransaction(transactionDto);
        transactionRepository.save(transactionEntity);
    }
}
