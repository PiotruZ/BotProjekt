package orderexecutionservice.capstone.gd.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@AllArgsConstructor
public class TransactionEntity {
        @Setter
        private int id;
        @Setter
        private int userId;
        private String brokerName;
        private String cryptocurrencyName;
        private BigDecimal amount;
        private String type;
}
