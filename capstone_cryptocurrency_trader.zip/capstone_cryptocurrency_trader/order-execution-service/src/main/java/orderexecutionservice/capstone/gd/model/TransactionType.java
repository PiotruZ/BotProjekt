package orderexecutionservice.capstone.gd.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum TransactionType {
    BUY("Buy"),
    SELL("Sell");

    private final String value;
}
