package orderexecutionservice.capstone.gd.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
@Getter
@Setter
@AllArgsConstructor
public class BrokerAccount {
    private int userId;
    private String broker;
    private BigDecimal balance;
}
