package orderexecutionservice.capstone.gd.apiclient;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import orderexecutionservice.capstone.gd.dto.ApiKeyDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.model.BrokerAccount;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@AllArgsConstructor
public class TradingApiClient {
    private Map<Integer, List<ApiKeyDto>> apiKeys;
    private Map<Integer, List<BrokerAccount>> userBalances;

    public Map<String, BigDecimal> getBalance(Integer userId) {
        List<BrokerAccount> brokerAccounts = userBalances.get(userId);
        HashMap<String, BigDecimal> balancesByBroker = new HashMap<>();

        for (BrokerAccount brokerAccount : brokerAccounts) {
            balancesByBroker.put(brokerAccount.getBroker(), brokerAccount.getBalance());
        }

        return balancesByBroker;
    }

    public void performTransaction(TransactionDto transactionDto) {
        if (transactionDto == null) {
            log.error("Error couldn't perform transaction: transaction is null");
            return;
        }

        log.info("Performing transaction in " + transactionDto.brokerName() + " for amount: " + transactionDto.amount().toString() + " " + transactionDto.cryptocurrencyName());
        List<BrokerAccount> brokerAccounts = userBalances.get(transactionDto.userId());

        if (brokerAccounts == null) {
            BrokerAccount brokerAccount = new BrokerAccount(transactionDto.userId(), transactionDto.brokerName(), transactionDto.amount());
            List<BrokerAccount> list = new ArrayList<>();
            list.add(brokerAccount);
            userBalances.put(transactionDto.userId(), list);
        } else {
            brokerAccounts.stream()
                    .filter(brokerAccount -> brokerAccount.getBroker().equals(transactionDto.brokerName()))
                    .findFirst()
                    .ifPresentOrElse(
                            brokerAccount -> brokerAccount.setBalance(brokerAccount.getBalance().add(transactionDto.amount())),
                            () -> brokerAccounts.add(new BrokerAccount(transactionDto.userId(), transactionDto.brokerName(), transactionDto.amount()))
                    );
        }
    }
}
