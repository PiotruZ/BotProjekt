package orderexecutionservice.capstone.gd.repository;


import orderexecutionservice.capstone.gd.entity.TransactionEntity;

import java.util.List;
import java.util.Optional;

public interface TransactionRepository {
    void saveTransaction(TransactionEntity transaction);
    Optional<TransactionEntity> getTransaction(int id);
    List<TransactionEntity> getUserTransactions(int userId);
}
