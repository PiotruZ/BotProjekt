package orderexecutionservice.capstone.gd.controller;

import lombok.AllArgsConstructor;
import orderexecutionservice.capstone.gd.dto.ReportDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.service.OrderExecutionService;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@AllArgsConstructor
public class OrderControllerImpl implements OrderController {

    private final OrderExecutionService orderExecutionService;

    @Override
    public ReportDto getBalance(Integer userId) {
        return orderExecutionService.getBalance(userId);
    }

    @Override
    public List<TransactionDto> getTransactionHistory(Integer userId) {
        return orderExecutionService.getTransactionHistory(userId);
    }

    @Override
    public void executeTransaction(TransactionDto transactionDto) {
        orderExecutionService.executeTransaction(transactionDto);
    }
}
