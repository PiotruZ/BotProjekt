package orderexecutionservice.capstone.gd.apiclient;

import orderexecutionservice.capstone.gd.dto.ApiKeyDto;
import orderexecutionservice.capstone.gd.model.BrokerAccount;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
public class TradingApiClientConfig {

    @Bean
    TradingApiClient tradingApiClient() {
        Map<Integer, List<ApiKeyDto>> apiKeys = new HashMap<>();
        ApiKeyDto apiKeyDto = new ApiKeyDto(1, "Broker1", "abc123def456ghi789jkl012");
        apiKeys.put(1, new ArrayList<>(List.of(apiKeyDto)));

        Map<Integer, List<BrokerAccount>> balances = new HashMap<>();
        BrokerAccount brokerAccount = new BrokerAccount(1, "Broker1", BigDecimal.ZERO);
        balances.put(1, new ArrayList<>(List.of(brokerAccount)));

        return new TradingApiClient(apiKeys, balances);
    }

}
