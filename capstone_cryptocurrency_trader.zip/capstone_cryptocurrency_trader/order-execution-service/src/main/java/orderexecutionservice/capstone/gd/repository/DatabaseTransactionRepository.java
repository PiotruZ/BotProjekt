package orderexecutionservice.capstone.gd.repository;

import lombok.RequiredArgsConstructor;
import orderexecutionservice.capstone.gd.entity.TransactionEntity;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class DatabaseTransactionRepository implements TransactionRepository {

    private final DatabaseManager databaseManager;

    @Override
    public void saveTransaction(TransactionEntity transaction) {
        String brokerName = transaction.getBrokerName();

        Integer brokerId = databaseManager.findOne("SELECT id FROM brokers WHERE name=?", rs -> {
            try {
                return rs.getInt("id");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }, brokerName);

        String query = """
                        INSERT INTO transactions (user_id, broker_id, cryptocurrency, amount, transaction_type)
                        VALUES (?, ?, ?, ?, ?);
                        """;

        databaseManager.execute(
                query,
                transaction.getUserId(),
                brokerId,
                transaction.getCryptocurrencyName(),
                transaction.getAmount(),
                transaction.getType()
        );
    }

    @Override
    public Optional<TransactionEntity> getTransaction(int id) {
        String query = "SELECT id, user_id, broker_id, cryptocurrency, amount, transaction_type FROM transactions WHERE id=?";

        return Optional.ofNullable(databaseManager.findOne(query, resultSet -> {
            try {
                int brokerId = resultSet.getInt("broker_id");
                String brokerName = databaseManager.findOne("SELECT name FROM brokers WHERE id=?", rs -> {
                    try {
                        return rs.getString("name");
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }, brokerId);

                return new TransactionEntity(
                        resultSet.getInt("id"),
                        resultSet.getInt("user_id"),
                        brokerName,
                        resultSet.getString("cryptocurrency"),
                        resultSet.getBigDecimal("amount"),
                        resultSet.getString("transaction_type")

                );
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }, id));
    }

    @Override
    public List<TransactionEntity> getUserTransactions(int userId) {
        String query = "SELECT id, user_id, broker_id, cryptocurrency, amount, transaction_type FROM transactions WHERE user_id=?";

        return databaseManager.findMany(query, resultSet -> {
            try {
                int brokerId = resultSet.getInt("broker_id");
                String brokerName = databaseManager.findOne("SELECT name FROM brokers WHERE id=?", rs -> {
                    try {
                        return rs.getString("name");
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }, brokerId);

                return new TransactionEntity(
                        resultSet.getInt("id"),
                        resultSet.getInt("user_id"),
                        brokerName,
                        resultSet.getString("cryptocurrency"),
                        resultSet.getBigDecimal("amount"),
                        resultSet.getString("transaction_type")

                );
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }, userId);
    }
}
