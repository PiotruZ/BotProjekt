package orderexecutionservice.capstone.gd.repository.jpa;

import orderexecutionservice.capstone.gd.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransactionJpaRepository extends JpaRepository<Transaction, Long> {
        List<Transaction> findByUserId(int userId);
}
