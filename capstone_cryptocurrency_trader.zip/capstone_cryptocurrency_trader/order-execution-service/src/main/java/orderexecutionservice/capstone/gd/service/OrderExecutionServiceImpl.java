package orderexecutionservice.capstone.gd.service;

import lombok.AllArgsConstructor;
import orderexecutionservice.capstone.gd.apiclient.TradingApiClient;
import orderexecutionservice.capstone.gd.dto.ReportDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.entity.TransactionEntity;
import orderexecutionservice.capstone.gd.mapper.TransactionMapper;
import orderexecutionservice.capstone.gd.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
@AllArgsConstructor
public class OrderExecutionServiceImpl implements OrderExecutionService{
    private final TransactionRepository transactionRepository;
    private final TradingApiClient tradingApiClient;
    private final TransactionMapper transactionMapper;

    @Override
    public ReportDto getBalance(Integer userId) {
        Map<String, BigDecimal> balance = tradingApiClient.getBalance(userId);

        BigDecimal sum = BigDecimal.ZERO;
        for (BigDecimal amount : balance.values()) {
            sum = sum.add(amount);
        }

        // TODO: call to user Service for username associated with this id

        return new ReportDto("User with id: " + userId, balance, sum);
    }

    @Override
    public List<TransactionDto> getTransactionHistory(Integer userId) {
        return transactionRepository.getUserTransactions(userId)
                .stream()
                .map(transactionMapper::entityToDto)
                .toList();
    }

    @Override
    public void executeTransaction(TransactionDto transactionDto) {
        TransactionEntity transactionEntity = transactionMapper.dtoToEntity(transactionDto);
        tradingApiClient.performTransaction(transactionDto);
        transactionRepository.saveTransaction(transactionEntity);
    }
}

