package orderexecutionservice.capstone.gd.dto;

import lombok.Builder;

import java.math.BigDecimal;


@Builder(toBuilder = true)
public record TransactionDto(int userId, String brokerName, String cryptocurrencyName, BigDecimal amount, String type) {
}
