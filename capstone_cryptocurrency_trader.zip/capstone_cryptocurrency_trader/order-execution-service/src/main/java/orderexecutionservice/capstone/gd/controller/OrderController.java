package orderexecutionservice.capstone.gd.controller;

import orderexecutionservice.capstone.gd.dto.ReportDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;

import java.util.List;

public interface OrderController {
    ReportDto getBalance(Integer userId);
    List<TransactionDto> getTransactionHistory(Integer userId);
    void executeTransaction(TransactionDto transaction);
}
