package orderexecutionservice.capstone.gd.mapper;

import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.entity.Broker;
import orderexecutionservice.capstone.gd.entity.Transaction;
import org.springframework.stereotype.Component;

@Component
public class TransactionJpaMapper {

    public TransactionDto entityToDto(Transaction transaction) {
        return new TransactionDto(
                transaction.getUserId(),
                transaction.getBroker().getName(),
                transaction.getCryptocurrencyName(),
                transaction.getAmount(),
                transaction.getType()
        );
    }

    public Transaction dtoToEntity(TransactionDto transactionDto, Broker broker) {
        return new Transaction(
                null,
                transactionDto.userId(),
                broker,
                transactionDto.cryptocurrencyName(),
                transactionDto.amount(),
                transactionDto.type()
        );
    }

}
