package orderexecutionservice.capstone.gd;

import orderexecutionservice.capstone.gd.controller.OrderController;
import orderexecutionservice.capstone.gd.dto.ReportDto;
import orderexecutionservice.capstone.gd.dto.TransactionDto;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.math.BigDecimal;
import java.util.List;

@SpringBootApplication
public class Main {
    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(Main.class, args);

        OrderController orderController = context.getBean(OrderController.class);

        ReportDto balance = orderController.getBalance(1);
        System.out.println("Balance: " + balance);


        TransactionDto bitcoin = new TransactionDto(1, "Broker1", "BTC", BigDecimal.ONE, "Buy");
        TransactionDto bitcoin2 = new TransactionDto(1, "Broker2", "BTC", BigDecimal.ONE, "Buy");

        orderController.executeTransaction(bitcoin);
        orderController.executeTransaction(bitcoin);
        orderController.executeTransaction(bitcoin2);

        List<TransactionDto> transactionHistory = orderController.getTransactionHistory(1);

        System.out.println("\nTransaction history for user with id 1: \n");
        System.out.println("Number of transactions: " + transactionHistory.size());
        System.out.println();

        for (TransactionDto transactionDto : transactionHistory) {
            System.out.println(transactionDto);
        }

        System.out.println("Balance dor user with id 1: " + orderController.getBalance(1));
    }

}