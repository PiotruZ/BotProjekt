package orderexecutionservice.capstone.gd.dto;

public record ApiKeyDto(int userId, String brokerName, String key) {
}
