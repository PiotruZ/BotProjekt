package orderexecutionservice.capstone.gd.repository.jpa;

import orderexecutionservice.capstone.gd.entity.Broker;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BrokerJpaRepository extends JpaRepository<Broker, Long> {

    Broker findByName(String name);
}
