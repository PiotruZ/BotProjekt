package orderexecutionservice.capstone.gd.mapper;

import orderexecutionservice.capstone.gd.dto.TransactionDto;
import orderexecutionservice.capstone.gd.entity.TransactionEntity;
import org.springframework.stereotype.Component;

@Component
public class TransactionMapper {
    public TransactionDto entityToDto(TransactionEntity transactionEntity) {
        return new TransactionDto(
                transactionEntity.getUserId(),
                transactionEntity.getBrokerName(),
                transactionEntity.getCryptocurrencyName(),
                transactionEntity.getAmount(),
                transactionEntity.getType()
        );
    }

    public TransactionEntity dtoToEntity(TransactionDto transactionDto) {
        return new TransactionEntity(
                0,
                transactionDto.userId(),
                transactionDto.brokerName(),
                transactionDto.cryptocurrencyName(),
                transactionDto.amount(),
                transactionDto.type()
        );
    }
}
