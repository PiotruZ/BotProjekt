package orderexecutionservice.capstone.gd.repository;

import orderexecutionservice.capstone.gd.entity.TransactionEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InMemoryTransactionRepository implements TransactionRepository {
    private final List<TransactionEntity> database = new ArrayList<>();

    @Override
    public void saveTransaction(TransactionEntity transaction) {
        transaction.setId(nextId());
        database.add(transaction);
    }

    @Override
    public Optional<TransactionEntity> getTransaction(int id) {
        for (TransactionEntity transactionEntity : database) {
            if (transactionEntity.getId() == id) {
                return Optional.of(transactionEntity);
            }
        }
        return Optional.empty();
    }

    @Override
    public List<TransactionEntity> getUserTransactions(int userId) {
        return database.stream()
                .filter(transactionEntity -> transactionEntity.getUserId() == userId)
                .toList();
    }

    private int nextId() {
        return database.size() + 1;
    }
}
