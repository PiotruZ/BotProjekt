## General info
This is OrderExecutionService responsible for executing transactions and storing data about previous user transactions. Service also enables checking user account balance.    

## Setup
To run this service, install database locally using docker-compose.

```
$ docker-compose up
```

Note: You need to ask service creator for .env file that contains credentials to database

## ERD Diagram
![ERD diagram](database%20schema.png)

## Querying Data with SQL Domain Task
![task](querying-data-with-sql-domain.png)