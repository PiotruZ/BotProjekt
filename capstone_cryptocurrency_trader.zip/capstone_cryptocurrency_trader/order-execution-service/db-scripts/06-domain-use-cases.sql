-- Cover all your use-cases implemented in OOD module using pure Java

-- get user api key to specified broker account
SELECT * FROM api_keys ak
WHERE broker_id = 1 AND user_id = 5;

-- get user transactions
SELECT t.id, t.user_id, t.cryptocurrency, t.amount, t.transaction_type, b.name AS broker_name  FROM transactions t
JOIN brokers b ON b.id = t.broker_id
WHERE t.user_id  = 2;

-- find broker by name
SELECT * FROM brokers b
WHERE b.name = 'Broker4';

-- save executed transaction
INSERT INTO transactions (user_id, broker_id, cryptocurrency, amount, transaction_type)
VALUES (2, 4, 'ETH', 2, 'Buy');