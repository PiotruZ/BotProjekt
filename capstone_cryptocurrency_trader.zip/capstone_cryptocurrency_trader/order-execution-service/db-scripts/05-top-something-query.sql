-- Top-something query (for example return authors and number of books they wrote ordered by books count)

-- query to fetch brokers with number of transactions that is related to them ordered by number of transactions
SELECT b.name, count(*) AS transactions FROM transactions t
JOIN brokers b ON b.id = t.broker_id
GROUP BY b.name
ORDER BY transactions DESC

