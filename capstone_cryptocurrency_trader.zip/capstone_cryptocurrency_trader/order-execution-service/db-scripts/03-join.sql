-- Search query with joined data for your use-cases
-- (for example when we fetching a Book for our library main page, we need to see whole Author name, so it should be joined)

-- fetching transactions with broker name joined
SELECT t.id, t.user_id, t.cryptocurrency, t.amount, t.transaction_type, b.name AS broker_name
FROM transactions t
JOIN brokers b ON t.broker_id = b.id
ORDER BY t.transaction_type;
