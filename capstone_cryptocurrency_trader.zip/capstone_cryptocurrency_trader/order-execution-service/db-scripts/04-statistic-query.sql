-- Statistic query; can be not related to your use-cases (for example return authors and number of books they wrote)

-- query to fetch brokers with number of transactions that is related to them
SELECT b.name, count(*) AS transactions FROM transactions t
JOIN brokers b ON b.id = t.broker_id
GROUP BY b.name