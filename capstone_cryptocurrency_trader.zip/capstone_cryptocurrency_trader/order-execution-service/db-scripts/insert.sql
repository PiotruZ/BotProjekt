INSERT INTO brokers (name) VALUES
('Broker1'),
('Broker2'),
('Broker3'),
('Broker4'),
('Broker5');

INSERT INTO api_keys (user_id, broker_id, api_key) VALUES
(1, 1, 'api_key_user1_broker1'),
(2, 2, 'api_key_user2_broker2'),
(3, 3, 'api_key_user3_broker3'),
(4, 4, 'api_key_user4_broker4'),
(5, 5, 'api_key_user5_broker5'),
(1, 2, 'api_key_user1_broker2'),
(2, 3, 'api_key_user2_broker3'),
(3, 4, 'api_key_user3_broker4'),
(4, 5, 'api_key_user4_broker5'),
(5, 1, 'api_key_user5_broker1');

INSERT INTO transactions (user_id, broker_id, cryptocurrency, amount, transaction_type) VALUES
(1, 1, 'BTC', 2.5, 'Buy'),
(2, 2, 'ETH', 5.0, 'Sell'),
(3, 3, 'XRP', 10.0, 'Buy'),
(4, 4, 'LTC', 7.5, 'Sell'),
(5, 5, 'BTC', 3.0, 'Buy'),
(1, 2, 'ETH', 4.0, 'Sell'),
(2, 3, 'XRP', 8.0, 'Buy'),
(3, 4, 'LTC', 6.0, 'Sell'),
(4, 5, 'BTC', 1.5, 'Buy'),
(5, 1, 'ETH', 2.0, 'Sell');
