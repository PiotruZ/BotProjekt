-- At least one full CRUD set of queries for your domain entity

-- Create
INSERT INTO transactions (user_id, broker_id, cryptocurrency, amount, transaction_type)
VALUES (1, 1, 'BTC', 2, 'Buy');

-- Read
SELECT * FROM transactions c
WHERE user_id = 1;

-- Update
UPDATE transactions
SET amount = amount +1
WHERE user_id = 1;

-- Delete
DELETE FROM transactions
WHERE user_id = 1 AND cryptocurrency = 'ETH';

