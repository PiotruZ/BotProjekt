-- Search query with dynamic filters, pagination and sorting

-- page_num = 2
-- page_size = 3
-- filter - cryptocurrency='BTC'
-- sorting by id


SELECT *
FROM transactions t
WHERE cryptocurrency ='BTC'
ORDER BY id
LIMIT 3 -- page_size = 3
OFFSET (2 - 1) * 3; -- (page_num - 1) * page_size;