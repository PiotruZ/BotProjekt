CREATE TABLE IF NOT EXISTS brokers(
	id SERIAL PRIMARY KEY,
	name VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS api_keys(
	id SERIAL PRIMARY KEY,
	user_id INT NOT NULL,
	broker_id INT NOT NULL,
	api_key VARCHAR(255) NOT NULL,
	CONSTRAINT fk_api_keys_on_brokers FOREIGN KEY (broker_id) REFERENCES brokers(id)
);

CREATE TABLE IF NOT EXISTS transactions(
	id SERIAL PRIMARY KEY,
	user_id INT NOT NULL,
	broker_id INT NOT NULL,
	cryptocurrency VARCHAR(5),
	amount NUMERIC,
	transaction_type VARCHAR(5),
	CONSTRAINT fk_transactions_on_brokers FOREIGN KEY (broker_id) REFERENCES brokers(id)
);