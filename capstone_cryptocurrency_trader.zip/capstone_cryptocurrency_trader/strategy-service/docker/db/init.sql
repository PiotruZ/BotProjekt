CREATE TABLE IF NOT EXISTS user_preferences (
    user_preferences_id SERIAL PRIMARY KEY,
    portfolio_allocation_percentage DECIMAL NOT NULL,
    stop_loss_percentage DECIMAL NOT NULL,
    take_profit_percentage DECIMAL NOT NULL
);

CREATE TABLE IF NOT EXISTS trading_strategy (
    strategy_id SERIAL PRIMARY KEY,
    strategy_name VARCHAR(255) NOT NULL,
    strategy_type VARCHAR(50) NOT NULL,
    user_preferences_id BIGINT UNIQUE,
    FOREIGN KEY (user_preferences_id) REFERENCES user_preferences(user_preferences_id) ON DELETE CASCADE
);