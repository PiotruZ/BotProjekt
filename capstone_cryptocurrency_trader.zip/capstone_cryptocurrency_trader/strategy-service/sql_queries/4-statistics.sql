-- Statistic query; can be not related to your use-cases
-- (for example return authors and number of books they wrote)

-- Number of strategies per type of strategy
SELECT strategy_type, COUNT(strategy_id) AS number_of_strategies
FROM trading_strategy
GROUP BY strategy_type;
