-- Search query with dynamic filters, pagination and sorting

-- :strategy_name, :strategy_type, :page_num, page_size - variables give by user
SELECT *
FROM trading_strategy
WHERE
    (:strategy_name IS NULL OR strategy_name ILIKE '%' || :strategy_name || '%')
    AND (:strategy_type IS NULL OR strategy_type = :strategy_type) --filters, can use both or none
ORDER BY strategy_name ASC
OFFSET (:page_num - 1) * :page_size; --skip amount of strategies that can be filled in previous pages
FETCH NEXT :page_size ROWS ONLY; --only fetch amount of strategies that fit in page of :page_size size
