-- Top-something query
-- (for example return authors and number of books they wrote ordered by books count)

--  Trading strategies with user preferences' highest portfolio allocation percentage
SELECT ts.strategy_id, ts.strategy_name, ts.strategy_type, up.portfolio_allocation_percentage
FROM trading_strategy ts
JOIN user_preferences up ON ts.user_preferences_id = up.user_preferences_id
ORDER BY up.portfolio_allocation_percentage DESC
LIMIT 5;