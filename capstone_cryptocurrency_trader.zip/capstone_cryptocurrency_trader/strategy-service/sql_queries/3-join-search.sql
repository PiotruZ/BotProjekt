-- Search query with joined data for your use-cases
-- (for example when we fetching a Book for our library main page,
-- we need to see whole Author name, so it should be joined)

-- Complete details of user preferences along with id of trading strategy
-- that references given user preferences
SELECT up.user_preferences_id, up.portfolio_allocation_percentage, up.stop_loss_percentage, up.take_profit_percentage,
       ts.strategy_id
FROM user_preferences up
INNER JOIN trading_strategy ts ON up.user_preferences_id = ts.user_preferences_id;
