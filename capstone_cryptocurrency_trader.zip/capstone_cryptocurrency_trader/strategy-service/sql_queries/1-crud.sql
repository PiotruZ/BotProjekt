-- At least one full CRUD set of queries for your domain entity

--CREATE
INSERT INTO trading_strategy (strategy_name, strategy_type, user_preferences_id)
VALUES ('Trend Following', 'TREND_FOLLOWING', 1);
--READ
SELECT * FROM trading_strategy WHERE strategy_id = 1;
--UPDATE
UPDATE trading_strategy
SET strategy_name = 'Mean Reversion', strategy_type = 'MEAN_REVERSION'
WHERE strategy_id = 1;
--DELETE
DELETE FROM trading_strategy WHERE strategy_id = 1;