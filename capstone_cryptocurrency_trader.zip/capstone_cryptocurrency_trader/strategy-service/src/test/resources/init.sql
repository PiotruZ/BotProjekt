DROP TABLE IF EXISTS trading_strategy;
DROP TABLE IF EXISTS user_preferences;

CREATE TABLE IF NOT EXISTS user_preferences (
    user_preferences_id SERIAL PRIMARY KEY,
    portfolio_allocation_percentage DECIMAL NOT NULL,
    stop_loss_percentage DECIMAL NOT NULL,
    take_profit_percentage DECIMAL NOT NULL
);

CREATE TABLE IF NOT EXISTS trading_strategy (
    strategy_id SERIAL PRIMARY KEY,
    strategy_name VARCHAR(255) NOT NULL,
    strategy_type VARCHAR(50) NOT NULL,
    user_preferences_id BIGINT UNIQUE,
    FOREIGN KEY (user_preferences_id) REFERENCES user_preferences(user_preferences_id)
);

-- Insert sample user preferences
INSERT INTO user_preferences (portfolio_allocation_percentage, stop_loss_percentage, take_profit_percentage) VALUES (50.0, 5.0, 10.0);
INSERT INTO user_preferences (portfolio_allocation_percentage, stop_loss_percentage, take_profit_percentage) VALUES (60.0, 10.0, 15.0);
INSERT INTO user_preferences (portfolio_allocation_percentage, stop_loss_percentage, take_profit_percentage) VALUES (70.0, 15.0, 20.0);

-- Insert sample trading strategies, assuming user_preferences_id values are 1, 2, and 3 respectively
INSERT INTO trading_strategy (strategy_name, strategy_type, user_preferences_id) VALUES ('Strategy One', 'MEAN_REVERSION', 1);
INSERT INTO trading_strategy (strategy_name, strategy_type, user_preferences_id) VALUES ('Strategy Two', 'TREND_FOLLOWING', 2);
INSERT INTO trading_strategy (strategy_name, strategy_type, user_preferences_id) VALUES ('Strategy Three', 'MEAN_REVERSION', 3);
