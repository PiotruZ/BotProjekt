DROP TABLE IF EXISTS user_preferences;

CREATE TABLE IF NOT EXISTS user_preferences (
    user_preferences_id SERIAL PRIMARY KEY,
    portfolio_allocation_percentage DECIMAL NOT NULL,
    stop_loss_percentage DECIMAL NOT NULL,
    take_profit_percentage DECIMAL NOT NULL
);

INSERT INTO user_preferences (portfolio_allocation_percentage, stop_loss_percentage, take_profit_percentage)
SELECT random()*100, random()*10, random()*15
FROM generate_series(1, 2000000);
