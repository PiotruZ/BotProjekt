package capstone.gd.mapper;

import capstone.gd.dto.MeanReversionStrategyDTO;
import capstone.gd.dto.StatisticalArbitrageStrategyDTO;
import capstone.gd.dto.TrendFollowingStrategyDTO;
import capstone.gd.dto.UserPreferencesDTO;
import capstone.gd.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class TradingStrategyMapperTest {

    private TradingStrategyMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = Mappers.getMapper(TradingStrategyMapper.class);
    }

    @Test
    void trendFollowingStrategyToDTOTest() {

        UserPreferences userPreferences = new UserPreferences();
        userPreferences.setPortfolioAllocationPercentage(new BigDecimal("50"));
        userPreferences.setStopLossPercentage(new BigDecimal("5"));
        userPreferences.setTakeProfitPercentage(new BigDecimal("10"));

        MovingAverage movingAverage1 = new MovingAverage();
        movingAverage1.setPeriod(14);
        movingAverage1.setValue(new BigDecimal("1.5"));

        MovingAverage movingAverage2 = new MovingAverage();
        movingAverage2.setPeriod(12);
        movingAverage2.setValue(new BigDecimal("1.4"));

        RsiSettings rsiSettings = new RsiSettings();
        rsiSettings.setPeriod(14);
        rsiSettings.setOverboughtThreshold(new BigDecimal("70"));
        rsiSettings.setOversoldThreshold(new BigDecimal("30"));

        MacdSettings macdSettings = new MacdSettings();
        macdSettings.setShortTermEMA(12.0);
        macdSettings.setLongTermEMA(26.0);
        macdSettings.setSignalLine(9.0);

        TrendFollowingStrategy strategy = new TrendFollowingStrategy();
        strategy.setStrategyId(1L);
        strategy.setStrategyName("Sample Trend Following Strategy");
        strategy.setStrategyType(StrategyType.TREND_FOLLOWING);
        strategy.setUserPreferences(userPreferences);
        strategy.setMovingAverages(List.of(movingAverage1, movingAverage2));
        strategy.setMacdSettings(macdSettings);
        strategy.setRsiSettings(rsiSettings);

        TrendFollowingStrategyDTO dto = mapper.trendFollowingStrategyToDTO(strategy);

        assertEquals(strategy.getStrategyId(), dto.strategyId());
        assertEquals(strategy.getStrategyName(), dto.strategyName());

        assertNotNull(dto.userPreferencesDTO());
        assertEquals(userPreferences.getPortfolioAllocationPercentage(), dto.userPreferencesDTO().portfolioAllocationPercentage());
        assertEquals(userPreferences.getStopLossPercentage(), dto.userPreferencesDTO().stopLossPercentage());
        assertEquals(userPreferences.getTakeProfitPercentage(), dto.userPreferencesDTO().takeProfitPercentage());

        assertEquals(strategy.getMovingAverages().get(0).getPeriod(), dto.movingAverages().get(0).getPeriod());
        assertEquals(strategy.getMovingAverages().get(0).getValue(), dto.movingAverages().get(0).getValue());

        assertEquals(strategy.getMacdSettings().getShortTermEMA(), dto.macdSettings().getShortTermEMA(), 0.001);
        assertEquals(strategy.getMacdSettings().getLongTermEMA(), dto.macdSettings().getLongTermEMA(), 0.001);
        assertEquals(strategy.getMacdSettings().getSignalLine(), dto.macdSettings().getSignalLine(), 0.001);

        assertEquals(strategy.getRsiSettings().getPeriod(), dto.rsiSettings().getPeriod());
        assertEquals(strategy.getRsiSettings().getOverboughtThreshold(), dto.rsiSettings().getOverboughtThreshold());
        assertEquals(strategy.getRsiSettings().getOversoldThreshold(), dto.rsiSettings().getOversoldThreshold());
    }

    @Test
    void dtoToTrendFollowingStrategyTest() {

        MovingAverage movingAverage1 = new MovingAverage();
        movingAverage1.setPeriod(14);
        movingAverage1.setValue(new BigDecimal("1.5"));

        MovingAverage movingAverage2 = new MovingAverage();
        movingAverage2.setPeriod(12);
        movingAverage2.setValue(new BigDecimal("1.4"));

        RsiSettings rsiSettings = new RsiSettings();
        rsiSettings.setPeriod(14);
        rsiSettings.setOverboughtThreshold(new BigDecimal("70"));
        rsiSettings.setOversoldThreshold(new BigDecimal("30"));

        MacdSettings macdSettings = new MacdSettings();
        macdSettings.setShortTermEMA(12.0);
        macdSettings.setLongTermEMA(26.0);
        macdSettings.setSignalLine(9.0);

        TrendFollowingStrategyDTO dto = new TrendFollowingStrategyDTO(
                1L,
                "Sample Trend Following Strategy",
                new UserPreferencesDTO(1L, new BigDecimal("50"), new BigDecimal("5"), new BigDecimal("10")),
                List.of(movingAverage1, movingAverage2),
                macdSettings,
                rsiSettings
        );

        TrendFollowingStrategy strategy = mapper.dtoToTrendFollowingStrategy(dto);

        assertEquals(dto.strategyId(), strategy.getStrategyId());
        assertEquals(dto.strategyName(), strategy.getStrategyName());
        assertEquals(StrategyType.TREND_FOLLOWING, strategy.getStrategyType());

        assertNotNull(strategy.getUserPreferences());
        assertEquals(dto.userPreferencesDTO().portfolioAllocationPercentage(), strategy.getUserPreferences().getPortfolioAllocationPercentage());
        assertEquals(dto.userPreferencesDTO().stopLossPercentage(), strategy.getUserPreferences().getStopLossPercentage());
        assertEquals(dto.userPreferencesDTO().takeProfitPercentage(), strategy.getUserPreferences().getTakeProfitPercentage());

        assertEquals(dto.movingAverages().get(0).getPeriod(), strategy.getMovingAverages().get(0).getPeriod());
        assertEquals(dto.movingAverages().get(0).getValue(), strategy.getMovingAverages().get(0).getValue());

        assertEquals(dto.macdSettings().getShortTermEMA(), strategy.getMacdSettings().getShortTermEMA(), 0.001);
        assertEquals(dto.macdSettings().getLongTermEMA(), strategy.getMacdSettings().getLongTermEMA(), 0.001);
        assertEquals(dto.macdSettings().getSignalLine(), strategy.getMacdSettings().getSignalLine(), 0.001);

        assertEquals(dto.rsiSettings().getPeriod(), strategy.getRsiSettings().getPeriod());
        assertEquals(dto.rsiSettings().getOverboughtThreshold(), strategy.getRsiSettings().getOverboughtThreshold());
        assertEquals(dto.rsiSettings().getOversoldThreshold(), strategy.getRsiSettings().getOversoldThreshold());
    }

    @Test
    void meanReversionStrategyToDTOTest() {

        UserPreferences userPreferences = new UserPreferences();
        userPreferences.setPortfolioAllocationPercentage(new BigDecimal("50"));
        userPreferences.setStopLossPercentage(new BigDecimal("5"));
        userPreferences.setTakeProfitPercentage(new BigDecimal("10"));

        PriceRange priceRange = new PriceRange();
        priceRange.setLowerBound(new BigDecimal("100"));
        priceRange.setUpperBound(new BigDecimal("200"));

        AveragePriceData averagePriceData = new AveragePriceData();
        averagePriceData.setAveragePrice(new BigDecimal("150"));

        MeanReversionStrategy strategy = new MeanReversionStrategy();
        strategy.setStrategyId(1L);
        strategy.setStrategyName("Mean Reversion Strategy Sample");
        strategy.setStrategyType(StrategyType.MEAN_REVERSION);
        strategy.setUserPreferences(userPreferences);
        strategy.setPriceRange(priceRange);
        strategy.setAveragePriceData(averagePriceData);

        MeanReversionStrategyDTO dto = mapper.meanReversionStrategyToDTO(strategy);

        assertEquals(strategy.getStrategyId(), dto.strategyId());
        assertEquals(strategy.getStrategyName(), dto.strategyName());

        assertNotNull(dto.userPreferencesDTO());

        assertNotNull(dto.userPreferencesDTO());
        assertEquals(userPreferences.getPortfolioAllocationPercentage(), dto.userPreferencesDTO().portfolioAllocationPercentage());
        assertEquals(userPreferences.getStopLossPercentage(), dto.userPreferencesDTO().stopLossPercentage());
        assertEquals(userPreferences.getTakeProfitPercentage(), dto.userPreferencesDTO().takeProfitPercentage());

        assertEquals(strategy.getPriceRange().getLowerBound(), dto.priceRange().getLowerBound());
        assertEquals(strategy.getPriceRange().getUpperBound(), dto.priceRange().getUpperBound());

        assertEquals(strategy.getAveragePriceData().getAveragePrice(), dto.averagePriceData().getAveragePrice());
    }

    @Test
    void dtoToMeanReversionStrategyTest() {

        PriceRange priceRange = new PriceRange();
        priceRange.setLowerBound(new BigDecimal("100"));
        priceRange.setUpperBound(new BigDecimal("200"));

        AveragePriceData averagePriceData = new AveragePriceData();
        averagePriceData.setAveragePrice(new BigDecimal("150"));

        MeanReversionStrategyDTO dto = new MeanReversionStrategyDTO(
                1L,
                "Mean Reversion Strategy Sample",
                new UserPreferencesDTO(1L, new BigDecimal("60"), new BigDecimal("6"), new BigDecimal("12")),
                priceRange,
                averagePriceData
        );

        MeanReversionStrategy strategy = mapper.dtoToMeanReversionStrategy(dto);

        assertEquals(dto.strategyId(), strategy.getStrategyId());
        assertEquals(dto.strategyName(), strategy.getStrategyName());
        assertEquals(StrategyType.MEAN_REVERSION, strategy.getStrategyType());

        assertNotNull(strategy.getUserPreferences());
        assertEquals(dto.userPreferencesDTO().portfolioAllocationPercentage(), strategy.getUserPreferences().getPortfolioAllocationPercentage());
        assertEquals(dto.userPreferencesDTO().stopLossPercentage(), strategy.getUserPreferences().getStopLossPercentage());
        assertEquals(dto.userPreferencesDTO().takeProfitPercentage(), strategy.getUserPreferences().getTakeProfitPercentage());

        assertEquals(dto.priceRange().getLowerBound(), strategy.getPriceRange().getLowerBound());
        assertEquals(dto.priceRange().getUpperBound(), strategy.getPriceRange().getUpperBound());

        assertEquals(dto.averagePriceData().getAveragePrice(), strategy.getAveragePriceData().getAveragePrice());
    }

    @Test
    void statisticalArbitrageStrategyToDTOTest() {

        UserPreferences userPreferences = new UserPreferences();
        userPreferences.setUserPreferencesId(1L);
        userPreferences.setPortfolioAllocationPercentage(new BigDecimal("70"));
        userPreferences.setStopLossPercentage(new BigDecimal("7"));
        userPreferences.setTakeProfitPercentage(new BigDecimal("14"));

        StockPair stockPair = new StockPair();
        stockPair.setStockA("AAPL");
        stockPair.setStockB("MSFT");

        CorrelationCoefficient coefficient = new CorrelationCoefficient();
        coefficient.setStockPair(stockPair);
        coefficient.setCoefficient(new BigDecimal("0.95"));

        PriceDevationThreshold threshold = new PriceDevationThreshold();
        threshold.setThreshold(new BigDecimal("0.05"));

        StatisticalArbitrageStrategy strategy = new StatisticalArbitrageStrategy();
        strategy.setStrategyId(1L);
        strategy.setStrategyName("Statistical Arbitrage Strategy Sample");
        strategy.setStrategyType(StrategyType.STATISTICAL_ARBITRAGE);
        strategy.setUserPreferences(userPreferences);
        strategy.setCorrelatedStockPairs(Collections.singletonList(stockPair));
        strategy.setCorrelationCoefficients(Collections.singletonList(coefficient));
        strategy.setPriceDevationThreshold(threshold);

        StatisticalArbitrageStrategyDTO dto = mapper.statisticalArbitrageStrategyToDTO(strategy);

        assertEquals(strategy.getStrategyId(), dto.strategyId());
        assertEquals(strategy.getStrategyName(), dto.strategyName());
        assertEquals(StrategyType.STATISTICAL_ARBITRAGE, strategy.getStrategyType());

        assertNotNull(dto.userPreferencesDTO());

        assertNotNull(dto.userPreferencesDTO());
        assertEquals(userPreferences.getPortfolioAllocationPercentage(), dto.userPreferencesDTO().portfolioAllocationPercentage());
        assertEquals(userPreferences.getStopLossPercentage(), dto.userPreferencesDTO().stopLossPercentage());
        assertEquals(userPreferences.getTakeProfitPercentage(), dto.userPreferencesDTO().takeProfitPercentage());

        assertEquals(strategy.getCorrelatedStockPairs().get(0).getStockA(), dto.correlatedStockPairs().get(0).getStockA());

        assertEquals(strategy.getCorrelationCoefficients().get(0).getCoefficient(), dto.correlationCoefficients().get(0).getCoefficient());

        assertEquals(strategy.getPriceDevationThreshold().getThreshold(), dto.priceDevationThreshold().getThreshold());
    }

    @Test
    void dtoToStatisticalArbitrageStrategyTest() {

        StockPair stockPair = new StockPair();
        stockPair.setStockA("AAPL");
        stockPair.setStockB("MSFT");

        CorrelationCoefficient coefficient = new CorrelationCoefficient();
        coefficient.setStockPair(stockPair);
        coefficient.setCoefficient(new BigDecimal("0.95"));

        PriceDevationThreshold threshold = new PriceDevationThreshold();
        threshold.setThreshold(new BigDecimal("0.05"));

        StatisticalArbitrageStrategyDTO dto = new StatisticalArbitrageStrategyDTO(
                1L,
                "Statistical Arbitrage Strategy Sample",
                new UserPreferencesDTO(1L, new BigDecimal("70"), new BigDecimal("7"), new BigDecimal("14")),
                List.of(stockPair),
                List.of(coefficient),
                threshold
        );

        StatisticalArbitrageStrategy strategy = mapper.dtoToStatisticalArbitrageStrategy(dto);

        assertEquals(dto.strategyId(), strategy.getStrategyId());
        assertEquals(dto.strategyName(), strategy.getStrategyName());

        assertNotNull(strategy.getUserPreferences());
        assertEquals(dto.userPreferencesDTO().portfolioAllocationPercentage(), strategy.getUserPreferences().getPortfolioAllocationPercentage());
        assertEquals(dto.userPreferencesDTO().stopLossPercentage(), strategy.getUserPreferences().getStopLossPercentage());
        assertEquals(dto.userPreferencesDTO().takeProfitPercentage(), strategy.getUserPreferences().getTakeProfitPercentage());

        assertNotNull(strategy.getCorrelatedStockPairs());
        assertEquals(dto.correlatedStockPairs().get(0).getStockA(), strategy.getCorrelatedStockPairs().get(0).getStockA());
        assertEquals(dto.correlatedStockPairs().get(0).getStockB(), strategy.getCorrelatedStockPairs().get(0).getStockB());

        assertNotNull(strategy.getCorrelationCoefficients());
        assertEquals(dto.correlationCoefficients().get(0).getCoefficient(), strategy.getCorrelationCoefficients().get(0).getCoefficient());

        assertNotNull(strategy.getPriceDevationThreshold());
        assertEquals(dto.priceDevationThreshold().getThreshold(), strategy.getPriceDevationThreshold().getThreshold());
    }

}
