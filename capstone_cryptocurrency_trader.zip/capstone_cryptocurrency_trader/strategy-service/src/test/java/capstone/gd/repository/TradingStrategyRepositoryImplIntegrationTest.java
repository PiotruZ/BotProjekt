package capstone.gd.repository;

import capstone.gd.model.StrategyType;
import capstone.gd.model.TradingStrategy;
import capstone.gd.model.UserPreferences;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.h2.tools.RunScript;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class TradingStrategyRepositoryImplIntegrationTest {
    private static TradingStrategyRepositoryImpl repository;

    @BeforeEach
    void setup() {
        // Configure the HikariCP connection pool to use H2 database
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH");
        config.setUsername("test");
        config.setPassword("");
        DataSource dataSource = new HikariDataSource(config);

        // Initialize the repository
        repository = new TradingStrategyRepositoryImpl(dataSource);

        // Use H2's RunScript to execute SQL script
        try (Connection conn = dataSource.getConnection()) {
            InputStream inputStream = TradingStrategyRepositoryImplIntegrationTest.class.getClassLoader().getResourceAsStream("init.sql");
            if (inputStream == null) {
                throw new RuntimeException("init.sql file not found");
            }
            // Run the script using H2's utility
            RunScript.execute(conn, new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        } catch (SQLException e) {
            throw new RuntimeException("Error executing init.sql script", e);
        }
    }

    @Test
    void testSaveStrategyIntegration() throws Exception {

        UserPreferences userPreferences = new UserPreferences();
        userPreferences.setPortfolioAllocationPercentage(new BigDecimal("50"));
        userPreferences.setStopLossPercentage(new BigDecimal("10"));
        userPreferences.setTakeProfitPercentage(new BigDecimal("20"));

        TradingStrategy strategy = new TradingStrategy();
        strategy.setStrategyName("Test Strategy");
        strategy.setStrategyType(StrategyType.TREND_FOLLOWING);
        strategy.setUserPreferences(userPreferences);

        repository.saveStrategy(strategy);

//         Fetch the saved strategy from the database and verify it
        Optional<TradingStrategy> fetchedStrategy = repository.findStrategyByID(strategy.getStrategyId());
        assertTrue(fetchedStrategy.isPresent());
        fetchedStrategy.ifPresent(s -> {
            assertEquals("Test Strategy", s.getStrategyName());
            assertEquals(StrategyType.TREND_FOLLOWING, s.getStrategyType());
            assertNotNull(s.getUserPreferences());
            assertEquals(0, new BigDecimal("50").compareTo(s.getUserPreferences().getPortfolioAllocationPercentage()));
            assertEquals(0, new BigDecimal("10").compareTo(s.getUserPreferences().getStopLossPercentage()));
            assertEquals(0, new BigDecimal("20").compareTo(s.getUserPreferences().getTakeProfitPercentage()));
        });
    }

    @Test
    void testFindStrategyByIDIntegration() throws Exception {

        long knownStrategyId = 1L;

        Optional<TradingStrategy> result = repository.findStrategyByID(knownStrategyId);

        // Verify the strategy is found
        assertTrue(result.isPresent());
        result.ifPresent(strategy -> {
            assertEquals(knownStrategyId, strategy.getStrategyId());
        });
    }

    @Test
    void testGetAllStrategiesIntegration() throws Exception {

        List<TradingStrategy> strategies = repository.getAllStrategies();

        // Verify there are 3 fetched strategies (init.sql inserts 3)
        assertEquals(3, strategies.size());
    }

    @Test
    void testFindStrategyByNameIntegration() throws Exception {
        String expectedStrategyName = "Strategy One";

        Optional<TradingStrategy> result = repository.findStrategyByName(expectedStrategyName);

        assertTrue(result.isPresent());
        result.ifPresent(strategy -> {
            assertEquals(expectedStrategyName, strategy.getStrategyName());
        });
    }

    @Test
    void testDeleteStrategyIntegration() throws Exception {

        long strategyIdToDelete = 1L;

        repository.deleteStrategy(strategyIdToDelete);

        // Verify strategy no longer exists
        Optional<TradingStrategy> result = repository.findStrategyByID(strategyIdToDelete);
        assertFalse(result.isPresent());
    }
}
