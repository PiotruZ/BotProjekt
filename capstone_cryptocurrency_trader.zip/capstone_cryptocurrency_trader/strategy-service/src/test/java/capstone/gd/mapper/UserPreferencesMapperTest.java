package capstone.gd.mapper;

import capstone.gd.dto.UserPreferencesDTO;
import capstone.gd.model.UserPreferences;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class UserPreferencesMapperTest {

    private UserPreferencesMapper mapper;

    @BeforeEach
    public void setUp() {
        mapper = UserPreferencesMapper.INSTANCE;
    }

    @Test
    public void shouldMapUserPreferencesToDTO() {

        UserPreferences userPreferences = new UserPreferences();
        userPreferences.setUserPreferencesId(0L);
        userPreferences.setPortfolioAllocationPercentage(new BigDecimal("50"));
        userPreferences.setStopLossPercentage(new BigDecimal("5"));
        userPreferences.setTakeProfitPercentage(new BigDecimal("10"));

        UserPreferencesDTO dto = mapper.userPreferencesToDTO(userPreferences);

        assertNotNull(dto);
        assertEquals(userPreferences.getUserPreferencesId(), dto.userPreferencesId());
        assertEquals(0, userPreferences.getPortfolioAllocationPercentage().compareTo(dto.portfolioAllocationPercentage()));
        assertEquals(0, userPreferences.getStopLossPercentage().compareTo(dto.stopLossPercentage()));
        assertEquals(0, userPreferences.getTakeProfitPercentage().compareTo(dto.takeProfitPercentage()));
    }

    @Test
    public void shouldMapDTOToUserPreferences() {

        UserPreferencesDTO dto = new UserPreferencesDTO(0L, new BigDecimal("50"), new BigDecimal("5"), new BigDecimal("10"));

        UserPreferences userPreferences = mapper.dtoToUserPreferences(dto);

        assertNotNull(userPreferences);
        assertEquals(dto.userPreferencesId(), userPreferences.getUserPreferencesId());
        assertEquals(0, dto.portfolioAllocationPercentage().compareTo(userPreferences.getPortfolioAllocationPercentage()));
        assertEquals(0, dto.stopLossPercentage().compareTo(userPreferences.getStopLossPercentage()));
        assertEquals(0, dto.takeProfitPercentage().compareTo(userPreferences.getTakeProfitPercentage()));
    }
}
