package capstone.gd.service;

import capstone.gd.model.TradingStrategy;
import capstone.gd.repository.TradingStrategyRepository;
import capstone.gd.repository.exception.NoStrategiesFoundException;
import capstone.gd.repository.exception.StrategyNotDeletedException;
import capstone.gd.repository.exception.StrategyNotFoundException;
import capstone.gd.repository.exception.StrategyNotSavedException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TradingStrategyServiceTest {

    @Mock
    private TradingStrategyRepository tradingStrategyRepository;

    @InjectMocks
    private TradingStrategyService tradingStrategyService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void saveStrategy_success() throws StrategyNotSavedException {
        TradingStrategy strategy = new TradingStrategy();

        doNothing().when(tradingStrategyRepository).saveStrategy(strategy);

        assertDoesNotThrow(() -> tradingStrategyService.saveStrategy(strategy));
        verify(tradingStrategyRepository, times(1)).saveStrategy(strategy);
    }

    @Test
    void findStrategyByID_found() throws StrategyNotFoundException {
        long strategyID = 1L;
        TradingStrategy expectedStrategy = new TradingStrategy();
        when(tradingStrategyRepository.findStrategyByID(strategyID)).thenReturn(Optional.of(expectedStrategy));

        Optional<TradingStrategy> resultStrategy = tradingStrategyService.findStrategyByID(strategyID);

        assertTrue(resultStrategy.isPresent());
        assertEquals(expectedStrategy, resultStrategy.get());
        verify(tradingStrategyRepository, times(1)).findStrategyByID(strategyID);
    }

    @Test
    void deleteStrategy_success() throws StrategyNotDeletedException {
        long strategyID = 1L;

        doNothing().when(tradingStrategyRepository).deleteStrategy(strategyID);

        assertDoesNotThrow(() -> tradingStrategyService.deleteStrategy(strategyID));
        verify(tradingStrategyRepository, times(1)).deleteStrategy(strategyID);
    }

    @Test
    void getAllStrategies_success() throws NoStrategiesFoundException {
        TradingStrategy strategy1 = new TradingStrategy();
        TradingStrategy strategy2 = new TradingStrategy();
        List<TradingStrategy> expectedStrategies = Arrays.asList(strategy1, strategy2);
        when(tradingStrategyRepository.getAllStrategies()).thenReturn(expectedStrategies);

        List<TradingStrategy> resultStrategies = tradingStrategyService.getAllStrategies();

        assertNotNull(resultStrategies);
        assertEquals(2, resultStrategies.size());
        verify(tradingStrategyRepository, times(1)).getAllStrategies();
    }

    @Test
    void findStrategyByName_found() throws StrategyNotFoundException {
        String strategyName = "Strategy 1";
        TradingStrategy expectedStrategy = new TradingStrategy();
        when(tradingStrategyRepository.findStrategyByName(strategyName)).thenReturn(Optional.of(expectedStrategy));

        Optional<TradingStrategy> resultStrategy = tradingStrategyService.findStrategyByName(strategyName);

        assertTrue(resultStrategy.isPresent());
        assertEquals(expectedStrategy, resultStrategy.get());
        verify(tradingStrategyRepository, times(1)).findStrategyByName(strategyName);
    }
}
