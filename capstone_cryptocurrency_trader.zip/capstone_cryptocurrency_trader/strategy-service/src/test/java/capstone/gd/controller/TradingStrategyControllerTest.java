package capstone.gd.controller;

import capstone.gd.model.StrategyType;
import capstone.gd.model.TradingStrategy;
import capstone.gd.model.UserPreferences;
import capstone.gd.repository.exception.StrategyNotDeletedException;
import capstone.gd.service.TradingStrategyService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willDoNothing;
import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(TradingStrategyController.class)
public class TradingStrategyControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TradingStrategyService tradingStrategyService;

    private TradingStrategy exampleStrategy;

    @BeforeEach
    public void setUp() {
        exampleStrategy = new TradingStrategy();
        exampleStrategy.setStrategyId(1L);
        exampleStrategy.setStrategyName("Example Strategy");
        exampleStrategy.setStrategyType(StrategyType.TREND_FOLLOWING);

        UserPreferences prefs = new UserPreferences();
        prefs.setUserPreferencesId(1L);
        prefs.setPortfolioAllocationPercentage(new BigDecimal("50"));
        prefs.setStopLossPercentage(new BigDecimal("5"));
        prefs.setTakeProfitPercentage(new BigDecimal("10"));
        exampleStrategy.setUserPreferences(prefs);

    }

    @Test
    public void getAllStrategies() throws Exception {
        given(tradingStrategyService.getAllStrategies()).willReturn(Collections.singletonList(exampleStrategy));

        mockMvc.perform(get("/api/tradingStrategies")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].strategyName", is(exampleStrategy.getStrategyName())));
    }

    // Test for GET /api/tradingStrategies/{id}
    @Test
    public void getStrategyByIdWhenExists() throws Exception {
        TradingStrategy strategy = new TradingStrategy(1L, "Strategy Name", StrategyType.TREND_FOLLOWING, new UserPreferences());
        given(tradingStrategyService.findStrategyByID(1L)).willReturn(Optional.of(strategy));

        mockMvc.perform(get("/api/tradingStrategies/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.strategyId", is(1)))
                .andExpect(jsonPath("$.strategyName", is("Strategy Name")));
    }

    @Test
    public void getStrategyByIdWhenNotExists() throws Exception {
        given(tradingStrategyService.findStrategyByID(anyLong())).willReturn(Optional.empty());

        mockMvc.perform(get("/api/tradingStrategies/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }


    // Test for POST /api/tradingStrategies
    @Test
    public void createStrategy() throws Exception {
        willDoNothing().given(tradingStrategyService).saveStrategy(any(TradingStrategy.class));

        mockMvc.perform(post("/api/tradingStrategies")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(exampleStrategy)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.strategyName", is("Example Strategy")));
    }

    // Test for PUT /api/tradingStrategies/{id}
    @Test
    public void updateStrategyWhenStrategyExists() throws Exception {
        given(tradingStrategyService.findStrategyByID(exampleStrategy.getStrategyId())).willReturn(Optional.of(exampleStrategy));
        willDoNothing().given(tradingStrategyService).saveStrategy(any(TradingStrategy.class));

        mockMvc.perform(put("/api/tradingStrategies/{id}", exampleStrategy.getStrategyId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"strategyName\":\"Updated Strategy\",\"strategyType\":\"MEAN_REVERSION\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.strategyName", is("Updated Strategy")));
    }

    @Test
    public void updateStrategyWhenStrategyDoesNotExist() throws Exception {
        given(tradingStrategyService.findStrategyByID(anyLong())).willReturn(Optional.empty());

        mockMvc.perform(put("/api/tradingStrategies/{id}", 99L)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"strategyName\":\"Non-existent Strategy\",\"strategyType\":\"MEAN_REVERSION\"}"))
                .andExpect(status().isNotFound());
    }

    // Test for DELETE /api/tradingStrategies/{id}
    @Test
    public void deleteStrategyWhenStrategyExists() throws Exception {
        willDoNothing().given(tradingStrategyService).deleteStrategy(anyLong());

        mockMvc.perform(delete("/api/tradingStrategies/{id}", 1L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    public void deleteStrategyWhenStrategyDoesNotExist() throws Exception {
        doThrow(new StrategyNotDeletedException("Could not delete strategy.")).when(tradingStrategyService).deleteStrategy(anyLong());

        mockMvc.perform(delete("/api/tradingStrategies/{id}", 99L)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError());
    }

    // Test for GET /api/tradingStrategies/{name}
    @Test
    public void getStrategyByNameWhenStrategyExists() throws Exception {
        TradingStrategy strategy = new TradingStrategy(1L, "Strategy Name", StrategyType.TREND_FOLLOWING, new UserPreferences());
        given(tradingStrategyService.findStrategyByName("Strategy Name")).willReturn(Optional.of(strategy));

        mockMvc.perform(get("/api/tradingStrategies/by-name/{name}", "Strategy Name")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.strategyId", is(1)))
                .andExpect(jsonPath("$.strategyName", is("Strategy Name")));
    }

    @Test
    public void getStrategyByNameWhenStrategyDoesNotExist() throws Exception {
        given(tradingStrategyService.findStrategyByName("NonExisting")).willReturn(Optional.empty());

        mockMvc.perform(get("/api/tradingStrategies/by-name/{name}", "NonExisting")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

}

