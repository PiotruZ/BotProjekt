package capstone.gd.repository;

import capstone.gd.model.StrategyType;
import capstone.gd.model.TradingStrategy;
import capstone.gd.model.UserPreferences;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TradingStrategyRepositoryImplTest {

    @Mock
    private DataSource dataSource;
    @Mock
    private Connection connection;
    @Mock
    private PreparedStatement preparedStatement;
    @Mock
    private ResultSet resultSet;

    private TradingStrategyRepositoryImpl repository;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        repository = new TradingStrategyRepositoryImpl(dataSource);

        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
        when(connection.prepareStatement(anyString(), eq(Statement.RETURN_GENERATED_KEYS))).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);
        when(preparedStatement.executeUpdate()).thenReturn(1);
        when(preparedStatement.getGeneratedKeys()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true, false);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void testSaveStrategy() throws Exception {
        when(connection.prepareStatement(anyString(), eq(Statement.RETURN_GENERATED_KEYS))).thenReturn(preparedStatement);
        when(preparedStatement.getGeneratedKeys()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true, true);
        when(resultSet.getLong(1)).thenReturn(1L);

        TradingStrategy strategy = new TradingStrategy();
        strategy.setStrategyName("Strategy 1");
        strategy.setStrategyType(StrategyType.TREND_FOLLOWING);
        UserPreferences prefs = new UserPreferences();
        prefs.setPortfolioAllocationPercentage(new BigDecimal("50"));
        prefs.setStopLossPercentage(new BigDecimal("10"));
        prefs.setTakeProfitPercentage(new BigDecimal("20"));
        strategy.setUserPreferences(prefs);

        assertDoesNotThrow(() -> repository.saveStrategy(strategy));
        verify(preparedStatement, times(2)).executeUpdate();
        verify(preparedStatement, times(2)).getGeneratedKeys();
    }


    @Test
    void testFindStrategyByID() throws Exception {
        when(resultSet.next()).thenReturn(true); // Simulate finding a strategy
        when(resultSet.getLong("strategy_id")).thenReturn(1L);
        when(resultSet.getString("strategy_name")).thenReturn("Strategy 1");
        when(resultSet.getString("strategy_type")).thenReturn(StrategyType.TREND_FOLLOWING.name());
        when(resultSet.getBigDecimal("portfolio_allocation_percentage")).thenReturn(new BigDecimal("50"));
        when(resultSet.getBigDecimal("stop_loss_percentage")).thenReturn(new BigDecimal("10"));
        when(resultSet.getBigDecimal("take_profit_percentage")).thenReturn(new BigDecimal("20"));

        Optional<TradingStrategy> foundStrategy = repository.findStrategyByID(1L);

        assertTrue(foundStrategy.isPresent());
        assertEquals("Strategy 1", foundStrategy.get().getStrategyName());
        assertEquals(StrategyType.TREND_FOLLOWING, foundStrategy.get().getStrategyType());
    }

    @Test
    void testDeleteStrategy() throws Exception {
        long strategyIdToDelete = 1L;

        assertDoesNotThrow(() -> repository.deleteStrategy(strategyIdToDelete));
        verify(preparedStatement, times(1)).setLong(1, strategyIdToDelete);
        verify(preparedStatement, times(1)).executeUpdate();
    }

    @Test
    void testGetAllStrategies() throws Exception {
        when(resultSet.next()).thenReturn(true, true, false); // Simulate finding two strategies, then end of results
        when(resultSet.getLong("strategy_id")).thenReturn(1L, 2L);
        when(resultSet.getString("strategy_name")).thenReturn("Strategy 1", "Strategy 2");
        when(resultSet.getString("strategy_type")).thenReturn(StrategyType.TREND_FOLLOWING.name(), StrategyType.MEAN_REVERSION.name());
        when(resultSet.getBigDecimal("portfolio_allocation_percentage")).thenReturn(new BigDecimal("50"), new BigDecimal("60"));
        when(resultSet.getBigDecimal("stop_loss_percentage")).thenReturn(new BigDecimal("10"), new BigDecimal("15"));
        when(resultSet.getBigDecimal("take_profit_percentage")).thenReturn(new BigDecimal("20"), new BigDecimal("25"));

        List<TradingStrategy> strategies = repository.getAllStrategies();

        assertNotNull(strategies);
        assertEquals(2, strategies.size()); // Verify that two strategies are found
        assertEquals("Strategy 1", strategies.get(0).getStrategyName());
        assertEquals(StrategyType.TREND_FOLLOWING, strategies.get(0).getStrategyType());
        assertEquals("Strategy 2", strategies.get(1).getStrategyName());
        assertEquals(StrategyType.MEAN_REVERSION, strategies.get(1).getStrategyType());
    }

    @Test
    void testFindStrategyByName() throws Exception {
        String strategyNameToFind = "Strategy 1";
        when(resultSet.next()).thenReturn(true).thenReturn(false); // Simulate finding a strategy, then end of results
        when(resultSet.getLong("strategy_id")).thenReturn(1L);
        when(resultSet.getString("strategy_name")).thenReturn(strategyNameToFind);
        when(resultSet.getString("strategy_type")).thenReturn(StrategyType.MEAN_REVERSION.name());
        when(resultSet.getBigDecimal("portfolio_allocation_percentage")).thenReturn(new BigDecimal("50"));
        when(resultSet.getBigDecimal("stop_loss_percentage")).thenReturn(new BigDecimal("10"));
        when(resultSet.getBigDecimal("take_profit_percentage")).thenReturn(new BigDecimal("20"));

        Optional<TradingStrategy> foundStrategy = repository.findStrategyByName(strategyNameToFind);

        assertTrue(foundStrategy.isPresent());
        assertEquals(strategyNameToFind, foundStrategy.get().getStrategyName());
        assertEquals(StrategyType.MEAN_REVERSION, foundStrategy.get().getStrategyType());
    }
}