package capstone.gd.repository;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.h2.tools.RunScript;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class IsolationLevelTest {

    private static DataSource dataSource;
    private static final String READ_PORTFOLIO_ALLOCATION_PERCENTAGE_SQL = "SELECT portfolio_allocation_percentage FROM user_preferences WHERE user_preferences_id = ?";
    private static final String UPDATE_PORTFOLIO_ALLOCATION_PERCENTAGE_SQL = "UPDATE user_preferences SET portfolio_allocation_percentage = ? WHERE user_preferences_id = ?";

    @BeforeAll
    static void setup() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH");
        config.setUsername("test");
        config.setPassword("");
        dataSource = new HikariDataSource(config);

        try (Connection conn = dataSource.getConnection()) {
            InputStream inputStream = TransactionalDeleteTest.class.getClassLoader().getResourceAsStream("init.sql");
            if (inputStream == null) {
                throw new RuntimeException("init.sql file not found");
            }
            RunScript.execute(conn, new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        } catch (SQLException e) {
            throw new RuntimeException("Error executing init.sql script", e);
        }
    }

    @Test
    void demonstrateNonRepeatableRead() throws Exception {
        // Transaction 1: Read data twice
        new Thread(() -> {
            try (Connection conn = dataSource.getConnection()) {
                conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED); // Default level
                conn.setAutoCommit(false);

                // First read
                BigDecimal firstRead = readPortfolioAllocationPercentage(conn, 1L);
                System.out.println("Transaction 1 - First read: " + firstRead);

                // Simulate time for another transaction to make changes
                Thread.sleep(2000);

                // Second read
                BigDecimal secondRead = readPortfolioAllocationPercentage(conn, 1L);
                System.out.println("Transaction 1 - Second read: " + secondRead);

                conn.commit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

        // Transaction 2: Update data
        new Thread(() -> {
            try (Connection conn = dataSource.getConnection()) {
                conn.setAutoCommit(false);
                updatePortfolioAllocationPercentage(conn, 1L, new BigDecimal("70.0")); // Update allocation
                conn.commit();
                System.out.println("Transaction 2 - Data update attempted.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

        // Add some delay to ensure both transactions complete
        Thread.sleep(5000);
    }

    @Test
    void demonstrateRepeatableRead() throws Exception {
        // Transaction 1: Read data twice with REPEATABLE READ isolation
        new Thread(() -> {
            try (Connection conn = dataSource.getConnection()) {
                // Set isolation level to REPEATABLE READ
                conn.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
                conn.setAutoCommit(false);

                // First read
                BigDecimal firstRead = readPortfolioAllocationPercentage(conn, 1L);
                System.out.println("Transaction 1 - First read: " + firstRead);

                // Wait to allow the second transaction to attempt an update
                Thread.sleep(2000);

                // Second read
                BigDecimal secondRead = readPortfolioAllocationPercentage(conn, 1L);
                System.out.println("Transaction 1 - Second read: " + secondRead);

                conn.commit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

        // Transaction 2: Attempt to update the data
        new Thread(() -> {
            try {
                // Adding delay to ensure this transaction starts after the first transaction's first read
                Thread.sleep(1000);

                try (Connection conn = dataSource.getConnection()) {
                    conn.setAutoCommit(false);
                    updatePortfolioAllocationPercentage(conn, 1L, new BigDecimal("70.0")); // Attempt to update
                    conn.commit();
                    System.out.println("Transaction 2 - Data update attempted.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

        // Wait to ensure both transactions complete
        Thread.sleep(5000);
    }

    private BigDecimal readPortfolioAllocationPercentage(Connection conn, long userPreferencesId) throws SQLException {
        try (PreparedStatement pstmt = conn.prepareStatement(READ_PORTFOLIO_ALLOCATION_PERCENTAGE_SQL)) {
            pstmt.setLong(1, userPreferencesId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal("portfolio_allocation_percentage");
                } else {
                    throw new SQLException("UserPreferences not found for ID: " + userPreferencesId);
                }
            }
        }
    }

    private void updatePortfolioAllocationPercentage(Connection conn, long userPreferencesId, BigDecimal newPercentage) throws SQLException {
        try (PreparedStatement pstmt = conn.prepareStatement(UPDATE_PORTFOLIO_ALLOCATION_PERCENTAGE_SQL)) {
            pstmt.setBigDecimal(1, newPercentage);
            pstmt.setLong(2, userPreferencesId);
            pstmt.executeUpdate();
        }
    }

}
