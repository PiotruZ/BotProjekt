package capstone.gd.repository;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.h2.tools.RunScript;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

public class TransactionalDeleteTest {

    private static DataSource dataSource;
    private static final String DELETE_STRATEGY_SQL = "DELETE FROM trading_strategy WHERE strategy_id = ?";
    private static final String DELETE_USER_PREFERENCES_SQL = "DELETE FROM user_preferences WHERE user_preferences_id = ?";
    private static final String CHECK_IF_STRATEGY_EXISTS_SQL = "SELECT 1 FROM trading_strategy WHERE strategy_id = ?";
    private static final String FETCH_USER_PREFS_SQL = "SELECT user_preferences_id FROM trading_strategy WHERE strategy_id = ?";
    private static final String CHECK_IF_USER_PREFS_EXIST_SQL = "SELECT 1 FROM user_preferences WHERE user_preferences_id = ?";

    @BeforeAll
    static void setup() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH");
        config.setUsername("test");
        config.setPassword("");
        dataSource = new HikariDataSource(config);

        try (Connection conn = dataSource.getConnection()) {
            InputStream inputStream = TransactionalDeleteTest.class.getClassLoader().getResourceAsStream("init.sql");
            if (inputStream == null) {
                throw new RuntimeException("init.sql file not found");
            }
            RunScript.execute(conn, new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        } catch (SQLException e) {
            throw new RuntimeException("Error executing init.sql script", e);
        }
    }

    @Test
    void testDeleteTransactionalWithError() {
        long strategyIdToDelete = 1; // Example ID

        Connection conn = null;
        try {
            conn = dataSource.getConnection();
            conn.setAutoCommit(false);

            // Fetch user_preferences_id associated with the strategy
            long userPreferencesId = fetchUserPreferencesIdForStrategy(conn, strategyIdToDelete);

            // Verify records exist before deletion
            assertTrue(checkIfStrategyExists(conn, strategyIdToDelete), "Strategy record should exist before deletion.");
            assertTrue(checkIfUserPreferencesExists(conn, userPreferencesId), "UserPreferences record should exist before deletion.");

            // Delete TradingStrategy
            try (PreparedStatement strategyStmt = conn.prepareStatement(DELETE_STRATEGY_SQL)) {
                strategyStmt.setLong(1, strategyIdToDelete);
                strategyStmt.executeUpdate();
            }

            // Simulate an error before deleting UserPreferences
            if (true) {
                throw new SQLException("Simulated error during transaction.");
            }

            // Delete UserPreferences
            try (PreparedStatement userPrefsStmt = conn.prepareStatement(DELETE_USER_PREFERENCES_SQL)) {
                userPrefsStmt.setLong(1, userPreferencesId);
                userPrefsStmt.executeUpdate();
            }

            conn.commit();
        } catch (SQLException e) {
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            System.out.println("Transaction failed and was rolled back due to error: " + e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    // Verify records still exist after attempted deletion and rollback
                    assertTrue(checkIfStrategyExists(conn, strategyIdToDelete), "Strategy record should still exist after rollback.");
                    assertTrue(checkIfUserPreferencesExists(conn, strategyIdToDelete), "UserPreferences record should still exist after rollback.");
                    System.out.println("Both records still exist if error occurred during transaction.");
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Test
    void testDeleteNonTransactionalWithError() {
        long strategyIdToDelete = 2;
        Connection conn = null;
        long userPreferencesId = -1;

        try {
            conn = dataSource.getConnection();

            // Fetch user_preferences_id associated with the strategy
            userPreferencesId = fetchUserPreferencesIdForStrategy(conn, strategyIdToDelete);

            // Verify records exist before deletion
            assertTrue(checkIfStrategyExists(conn, strategyIdToDelete), "Strategy record should exist before deletion.");
            assertTrue(checkIfUserPreferencesExists(conn, userPreferencesId), "UserPreferences record should exist before deletion.");

            // Delete TradingStrategy
            try (PreparedStatement strategyStmt = conn.prepareStatement(DELETE_STRATEGY_SQL)) {
                strategyStmt.setLong(1, strategyIdToDelete);
                strategyStmt.executeUpdate();
            }

            // Simulate an error before deleting UserPreferences
            if (true) {
                throw new SQLException("Simulated error");
            }

            // Try deleting UserPreferences
            try (PreparedStatement userPrefsStmt = conn.prepareStatement(DELETE_USER_PREFERENCES_SQL)) {
                userPrefsStmt.setLong(1, userPreferencesId);
                userPrefsStmt.executeUpdate();
            }

        } catch (SQLException ex) {
            System.out.println("An error occurred: " + ex.getMessage());
            try {
                // Verify TradingStrategy record does not exist after deletion, but before the error
                assertFalse(checkIfStrategyExists(conn, strategyIdToDelete), "Strategy record should not exist after deletion.");
                // UserPreferences record should still exist since its deletion was not executed
                assertTrue(checkIfUserPreferencesExists(conn, userPreferencesId), "UserPreferences record should still exist after simulated error.");
                System.out.println("User preferences still exist because error occurred after deleting trading strategy.");
            } catch (SQLException e) {
                e.printStackTrace();
                fail("Post-error verification failed: " + e.getMessage());
            }

        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private boolean checkIfStrategyExists(Connection conn, long strategyId) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(CHECK_IF_STRATEGY_EXISTS_SQL)) {
            stmt.setLong(1, strategyId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private long fetchUserPreferencesIdForStrategy(Connection conn, long strategyId) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(FETCH_USER_PREFS_SQL)) {
            stmt.setLong(1, strategyId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong("user_preferences_id");
                } else {
                    throw new SQLException("No user preferences found for strategy ID: " + strategyId);
                }
            }
        }
    }

    private boolean checkIfUserPreferencesExists(Connection conn, long userPreferencesId) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(CHECK_IF_USER_PREFS_EXIST_SQL)) {
            stmt.setLong(1, userPreferencesId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

}
