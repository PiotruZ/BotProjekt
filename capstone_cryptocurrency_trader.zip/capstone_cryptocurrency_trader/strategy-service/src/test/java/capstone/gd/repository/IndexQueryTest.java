package capstone.gd.repository;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.h2.tools.RunScript;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@Disabled
public class IndexQueryTest {

    private static TradingStrategyRepositoryImpl repository;
    private static final String DROP_INDEX_SQL = "DROP INDEX IF EXISTS idx_portfolio_allocation ON user_preferences";
    private static final String SELECT_ALLOCATION_PERCENTAGE_SQL = "SELECT * FROM user_preferences WHERE portfolio_allocation_percentage = 50";
    private static final String CREATE_INDEX_SQL = "CREATE INDEX idx_portfolio_allocation ON user_preferences(portfolio_allocation_percentage)";
    private static final String DROP_COMPOUND_INDEX_SQL = "DROP INDEX IF EXISTS idx_stop_loss_take_profit ON user_preferences";
    private static final String SELECT_STOP_LOSS_SQL = "SELECT * FROM user_preferences WHERE stop_loss_percentage = 5";
    private static final String SELECT_STOP_LOSS_TAKE_PROFIT_SQL = "SELECT * FROM user_preferences WHERE stop_loss_percentage = 5 AND take_profit_percentage = 10";
    private static final String CREATE_COMPOUND_INDEX_SQL = "CREATE INDEX idx_stop_loss_take_profit ON user_preferences(stop_loss_percentage, take_profit_percentage)";

    @BeforeAll
    static void setup() {
        // Configure the HikariCP connection pool to use H2 database
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH");
        config.setUsername("test");
        config.setPassword("");
        DataSource dataSource = new HikariDataSource(config);

        // Initialize the repository
        repository = new TradingStrategyRepositoryImpl(dataSource);

        // Use H2's RunScript to execute SQL script
        try (Connection conn = dataSource.getConnection()) {
            InputStream inputStream = TradingStrategyRepositoryImplIntegrationTest.class.getClassLoader().getResourceAsStream("bigInit.sql");
            if (inputStream == null) {
                throw new RuntimeException("bigInit.sql file not found");
            }
            // Run the script using H2's utility
            RunScript.execute(conn, new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        } catch (SQLException e) {
            throw new RuntimeException("Error executing bigInit.sql script", e);
        }
    }

    @Test
    void indexTest() {
        try (Connection conn = repository.getDataSource().getConnection();
             Statement stmt = conn.createStatement()) {

            // Drop index if exists to test performance without index
            stmt.execute(DROP_INDEX_SQL);

            long startTimeNoIndex = System.nanoTime();
            stmt.executeQuery(SELECT_ALLOCATION_PERCENTAGE_SQL);
            long endTimeNoIndex = System.nanoTime();

            // Create the index
            stmt.execute(CREATE_INDEX_SQL);

            long startTimeWithIndex = System.nanoTime();
            stmt.executeQuery(SELECT_ALLOCATION_PERCENTAGE_SQL);
            long endTimeWithIndex = System.nanoTime();

            System.out.println("Query time without index: " + ((endTimeNoIndex - startTimeNoIndex) / 1_000) + " microseconds");
            System.out.println("Query time with index: " + ((endTimeWithIndex - startTimeWithIndex) / 1_000) + " microseconds");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    void compoundIndexTest() {
        try (Connection conn = repository.getDataSource().getConnection();
             Statement stmt = conn.createStatement()) {

            // Drop compound index if exists to test performance without it
            stmt.execute(DROP_COMPOUND_INDEX_SQL);

            long startTimeTwoColumnsWithoutIndex = System.nanoTime();
            stmt.executeQuery(SELECT_STOP_LOSS_TAKE_PROFIT_SQL);
            long endTimeTwoColumnsWithoutIndex = System.nanoTime();

            // Create the compound index
            stmt.execute(CREATE_COMPOUND_INDEX_SQL);

            long startTimeWholeSet = System.nanoTime();
            stmt.executeQuery(SELECT_STOP_LOSS_TAKE_PROFIT_SQL);
            long endTimeWholeSet = System.nanoTime();

            long startTimePartialSet = System.nanoTime();
            stmt.executeQuery(SELECT_STOP_LOSS_SQL);
            long endTimePartialSet = System.nanoTime();

            System.out.println("Query time two columns without index: " + ((endTimeTwoColumnsWithoutIndex - startTimeTwoColumnsWithoutIndex) / 1_000) + " microseconds");
            System.out.println("Query time with whole set of indexed columns: " + ((endTimeWholeSet - startTimeWholeSet) / 1_000) + " microseconds");
            System.out.println("Query time with partial set of indexed columns: " + ((endTimePartialSet - startTimePartialSet) / 1_000) + " microseconds");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
