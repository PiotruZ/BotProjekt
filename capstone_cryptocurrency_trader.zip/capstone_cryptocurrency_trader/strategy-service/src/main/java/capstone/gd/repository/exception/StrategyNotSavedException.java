package capstone.gd.repository.exception;

public class StrategyNotSavedException extends Exception {
    public StrategyNotSavedException(String message) {
        super(message);
    }
}
