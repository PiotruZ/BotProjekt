package capstone.gd.service;

import capstone.gd.model.TradingStrategy;
import capstone.gd.repository.TradingStrategyRepository;
import capstone.gd.repository.exception.NoStrategiesFoundException;
import capstone.gd.repository.exception.StrategyNotDeletedException;
import capstone.gd.repository.exception.StrategyNotFoundException;
import capstone.gd.repository.exception.StrategyNotSavedException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TradingStrategyService {

    private final TradingStrategyRepository tradingStrategyRepository;

    public void saveStrategy(TradingStrategy strategy) throws StrategyNotSavedException {
        tradingStrategyRepository.saveStrategy(strategy);
    }

    public Optional<TradingStrategy> findStrategyByID(long strategyID) throws StrategyNotFoundException {
        return tradingStrategyRepository.findStrategyByID(strategyID);
    }

    public void deleteStrategy(long strategyID) throws StrategyNotDeletedException {
        tradingStrategyRepository.deleteStrategy(strategyID);
    }

    public List<TradingStrategy> getAllStrategies() throws NoStrategiesFoundException {
        return tradingStrategyRepository.getAllStrategies();
    }

    public Optional<TradingStrategy> findStrategyByName(String strategyName) throws StrategyNotFoundException {
        return tradingStrategyRepository.findStrategyByName(strategyName);
    }
}
