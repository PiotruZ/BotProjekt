package capstone.gd.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class StatisticalArbitrageStrategy extends TradingStrategy {
    List<StockPair> correlatedStockPairs;
    List<CorrelationCoefficient> correlationCoefficients;
    PriceDevationThreshold priceDevationThreshold;

    void evaluatePriceInefficiencies() {
    }

    EntryExitPoints determineEntryExitPoints() {
        BigDecimal entryPoint = null;
        BigDecimal exitPoint = null;
        return new EntryExitPoints(entryPoint, exitPoint);
    }
}
