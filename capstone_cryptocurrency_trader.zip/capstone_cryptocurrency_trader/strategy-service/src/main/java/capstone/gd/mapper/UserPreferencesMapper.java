package capstone.gd.mapper;

import capstone.gd.dto.UserPreferencesDTO;
import capstone.gd.model.UserPreferences;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UserPreferencesMapper {

    UserPreferencesMapper INSTANCE = Mappers.getMapper(UserPreferencesMapper.class);

    UserPreferences dtoToUserPreferences(UserPreferencesDTO dto);

    UserPreferencesDTO userPreferencesToDTO(UserPreferences userPreferences);
}
