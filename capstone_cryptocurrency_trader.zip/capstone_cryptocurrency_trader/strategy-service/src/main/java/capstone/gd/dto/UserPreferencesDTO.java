package capstone.gd.dto;

import java.math.BigDecimal;

public record UserPreferencesDTO(long userPreferencesId, BigDecimal portfolioAllocationPercentage,
                                 BigDecimal stopLossPercentage, BigDecimal takeProfitPercentage) {
}
