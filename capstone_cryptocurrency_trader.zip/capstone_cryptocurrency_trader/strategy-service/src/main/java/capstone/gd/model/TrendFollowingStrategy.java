package capstone.gd.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TrendFollowingStrategy extends TradingStrategy {
    List<MovingAverage> movingAverages;
    MacdSettings macdSettings;
    RsiSettings rsiSettings;

    void evaluteTrend() {

    }

    EntryExitPoints determineEntryExitPoints() {
        BigDecimal entryPoint = null;
        BigDecimal exitPoint = null;
        return new EntryExitPoints(entryPoint, exitPoint);
    }
}
