package capstone.gd.dto;

import capstone.gd.model.MacdSettings;
import capstone.gd.model.MovingAverage;
import capstone.gd.model.RsiSettings;

import java.util.List;

public record TrendFollowingStrategyDTO(long strategyId, String strategyName, UserPreferencesDTO userPreferencesDTO,
                                        List<MovingAverage> movingAverages, MacdSettings macdSettings,
                                        RsiSettings rsiSettings) {
}
