package capstone.gd.repository.exception;

public class StrategyNotFoundException extends Exception {
    public StrategyNotFoundException(String message) {
        super(message);
    }
}
