package capstone.gd.dto;

import capstone.gd.model.AveragePriceData;
import capstone.gd.model.PriceRange;

public record MeanReversionStrategyDTO(long strategyId, String strategyName, UserPreferencesDTO userPreferencesDTO,
                                       PriceRange priceRange, AveragePriceData averagePriceData) {
}
