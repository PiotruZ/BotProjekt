package capstone.gd.model;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class MovingAverage {
    Integer period;
    BigDecimal value;
}
