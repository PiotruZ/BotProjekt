package capstone.gd.model;

import lombok.Data;

@Data
public class MacdSettings {
    private double shortTermEMA;
    private double longTermEMA;
    private double signalLine;
}
