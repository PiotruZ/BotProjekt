package capstone.gd.model;

import lombok.Data;

@Data
public class StockPair {
    String stockA;
    String stockB;
}
