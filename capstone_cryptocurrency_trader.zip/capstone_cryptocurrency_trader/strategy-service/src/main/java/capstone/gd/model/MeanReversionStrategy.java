package capstone.gd.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Data
public class MeanReversionStrategy extends TradingStrategy {
    PriceRange priceRange;
    AveragePriceData averagePriceData;

    void evalutePriceDevation() {
    }

    EntryExitPoints determineEntryExitPoints() {
        BigDecimal entryPoint = null;
        BigDecimal exitPoint = null;
        return new EntryExitPoints(entryPoint, exitPoint);
    }
}
