package capstone.gd;

import capstone.gd.model.StrategyType;
import capstone.gd.model.TradingStrategy;
import capstone.gd.model.UserPreferences;
import capstone.gd.repository.TradingStrategyRepository;
import capstone.gd.repository.TradingStrategyRepositoryImpl;
import capstone.gd.repository.config.DatabaseConfig;
import capstone.gd.repository.exception.NoStrategiesFoundException;
import capstone.gd.repository.exception.StrategyNotDeletedException;
import capstone.gd.repository.exception.StrategyNotFoundException;
import capstone.gd.repository.exception.StrategyNotSavedException;
import capstone.gd.service.TradingStrategyService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@SpringBootApplication
public class Main {
    public static void main(String[] args) throws StrategyNotSavedException, StrategyNotFoundException, NoStrategiesFoundException, StrategyNotDeletedException {

        SpringApplication.run(Main.class, args);
        DataSource dataSource = new DatabaseConfig().dataSource();

        TradingStrategyRepository repository = new TradingStrategyRepositoryImpl(dataSource);

        TradingStrategyService service = new TradingStrategyService(repository);


        UserPreferences preferences = new UserPreferences(0L, // ID set by the database
                new BigDecimal("50.0"), // portfolioAllocationPercentage
                new BigDecimal("5.0"), // stopLossPercentage
                new BigDecimal("10.0")); // takeProfitPercentage


        TradingStrategy strategy = new TradingStrategy(0L, // ID set by the database
                "Example Strategy", StrategyType.MEAN_REVERSION, preferences);

        // Save the strategy (and implicitly the user preferences)
        service.saveStrategy(strategy);


        System.out.println("Strategy ID after saving: " + strategy.getStrategyId());

        // Find a strategy by ID

        long strategyIdToFind = strategy.getStrategyId();
        Optional<TradingStrategy> foundStrategy = service.findStrategyByID(strategyIdToFind);
        foundStrategy.ifPresent(s -> System.out.println("Found strategy: " + s.getStrategyName()));

        // List all strategies
        List<TradingStrategy> strategies = service.getAllStrategies();
        System.out.println("Listing all strategies:");
        strategies.forEach(s -> System.out.println("Strategy ID: " + s.getStrategyId() + ", Name: " + s.getStrategyName()));

        // Delete a strategy
        long strategyIdToDelete = strategy.getStrategyId();
        service.deleteStrategy(strategyIdToDelete);
        System.out.println("Strategy deleted: " + strategyIdToDelete);

        // Verify deletion by attempting to find the deleted strategy
        Optional<TradingStrategy> deletedStrategyCheck = service.findStrategyByID(strategyIdToDelete);
        if (deletedStrategyCheck.isEmpty()) {
            System.out.println("Verification: Strategy successfully deleted.");
        }

        // Optionally, list all strategies again to verify the deletion
        List<TradingStrategy> strategiesAfterDeletion = service.getAllStrategies();
        System.out.println("Strategies after deletion:");
        strategiesAfterDeletion.forEach(s -> System.out.println("Strategy ID: " + s.getStrategyId() + ", Name: " + s.getStrategyName()));
    }
}
