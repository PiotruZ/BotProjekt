package capstone.gd.controller;

import capstone.gd.model.TradingStrategy;
import capstone.gd.repository.exception.NoStrategiesFoundException;
import capstone.gd.repository.exception.StrategyNotDeletedException;
import capstone.gd.repository.exception.StrategyNotFoundException;
import capstone.gd.repository.exception.StrategyNotSavedException;
import capstone.gd.service.TradingStrategyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tradingStrategies")
public class TradingStrategyController {

    private final TradingStrategyService tradingStrategyService;

    public TradingStrategyController(TradingStrategyService tradingStrategyService) {
        this.tradingStrategyService = tradingStrategyService;
    }

    @GetMapping
    public ResponseEntity<List<TradingStrategy>> getAllStrategies() {
        try {
            List<TradingStrategy> strategies = tradingStrategyService.getAllStrategies();
            return new ResponseEntity<>(strategies, HttpStatus.OK);
        } catch (NoStrategiesFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<TradingStrategy> getStrategyById(@PathVariable long id) {
        try {
            Optional<TradingStrategy> strategy = tradingStrategyService.findStrategyByID(id);
            return strategy.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                    .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
        } catch (StrategyNotFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<TradingStrategy> createStrategy(@RequestBody TradingStrategy tradingStrategy) {
        try {
            tradingStrategyService.saveStrategy(tradingStrategy);
            return new ResponseEntity<>(tradingStrategy, HttpStatus.CREATED);
        } catch (StrategyNotSavedException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<TradingStrategy> updateStrategy(@PathVariable long id, @RequestBody TradingStrategy tradingStrategy) {
        try {
            Optional<TradingStrategy> updatedStrategy = tradingStrategyService.findStrategyByID(id)
                    .map(existingStrategy -> {
                        existingStrategy.setStrategyName(tradingStrategy.getStrategyName());
                        existingStrategy.setStrategyType(tradingStrategy.getStrategyType());
                        if (tradingStrategy.getUserPreferences() != null) {
                            existingStrategy.getUserPreferences().setPortfolioAllocationPercentage(tradingStrategy.getUserPreferences().getPortfolioAllocationPercentage());
                            existingStrategy.getUserPreferences().setStopLossPercentage(tradingStrategy.getUserPreferences().getStopLossPercentage());
                            existingStrategy.getUserPreferences().setTakeProfitPercentage(tradingStrategy.getUserPreferences().getTakeProfitPercentage());
                        }
                        // Save the updated strategy
                        try {
                            tradingStrategyService.saveStrategy(existingStrategy);
                            return existingStrategy;
                        } catch (StrategyNotSavedException e) {
                            throw new RuntimeException(e);
                        }
                    });

            return updatedStrategy.map(strategy -> new ResponseEntity<>(strategy, HttpStatus.OK)).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
        } catch (StrategyNotFoundException | RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStrategy(@PathVariable long id) {
        try {
            tradingStrategyService.deleteStrategy(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (StrategyNotDeletedException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/by-name/{name}")
    public ResponseEntity<TradingStrategy> getStrategyByName(@PathVariable String name) {
        if (name != null) {
            try {
                Optional<TradingStrategy> strategy = tradingStrategyService.findStrategyByName(name);
                return strategy.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                        .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
            } catch (StrategyNotFoundException e) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

}