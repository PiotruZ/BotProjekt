package capstone.gd.model;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CorrelationCoefficient {
    StockPair stockPair;
    BigDecimal coefficient;
}
