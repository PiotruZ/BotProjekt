package capstone.gd.model;

public enum StrategyType {
    TREND_FOLLOWING,
    STATISTICAL_ARBITRAGE,
    MEAN_REVERSION;

    public static StrategyType fromString(String type) {
        for (StrategyType strategyType : StrategyType.values()) {
            if (strategyType.name().equalsIgnoreCase(type)) {
                return strategyType;
            }
        }
        throw new IllegalArgumentException("Couldn't find strategy " + type);
    }
}
