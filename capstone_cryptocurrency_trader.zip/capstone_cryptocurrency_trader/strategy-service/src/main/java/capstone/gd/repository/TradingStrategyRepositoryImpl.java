package capstone.gd.repository;

import capstone.gd.model.StrategyType;
import capstone.gd.model.TradingStrategy;
import capstone.gd.model.UserPreferences;
import capstone.gd.repository.exception.NoStrategiesFoundException;
import capstone.gd.repository.exception.StrategyNotDeletedException;
import capstone.gd.repository.exception.StrategyNotFoundException;
import capstone.gd.repository.exception.StrategyNotSavedException;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
@Data
public final class TradingStrategyRepositoryImpl implements TradingStrategyRepository {

    @Autowired
    private final DataSource dataSource;

    private static final String INSERT_STRATEGY_SQL = "INSERT INTO trading_strategy(strategy_name, strategy_type, user_preferences_id) VALUES (?, ?, ?)";
    private static final String INSERT_USER_PREFERENCE_SQL = "INSERT INTO user_preferences(portfolio_allocation_percentage, stop_loss_percentage, take_profit_percentage) VALUES (?, ?, ?)";
    private static final String DELETE_SQL = "DELETE FROM trading_strategy WHERE strategy_id = ?";
    private static final String FIND_BY_ID_SQL = "SELECT * FROM trading_strategy ts JOIN user_preferences up ON ts.user_preferences_id = up.user_preferences_id WHERE ts.strategy_id = ?";
    private static final String GET_ALL_SQL = "SELECT * FROM trading_strategy ts JOIN user_preferences up ON ts.user_preferences_id = up.user_preferences_id";
    private static final String FIND_BY_NAME_SQL = "SELECT * FROM trading_strategy ts JOIN user_preferences up ON ts.user_preferences_id = up.user_preferences_id WHERE ts.strategy_name = ?";

    @Override
    public void saveStrategy(TradingStrategy strategy) throws StrategyNotSavedException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement prefsStmt = conn.prepareStatement(INSERT_USER_PREFERENCE_SQL, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement strategyStmt = conn.prepareStatement(INSERT_STRATEGY_SQL, Statement.RETURN_GENERATED_KEYS)) {

            UserPreferences prefs = strategy.getUserPreferences();
            prefsStmt.setBigDecimal(1, prefs.getPortfolioAllocationPercentage());
            prefsStmt.setBigDecimal(2, prefs.getStopLossPercentage());
            prefsStmt.setBigDecimal(3, prefs.getTakeProfitPercentage());
            prefsStmt.executeUpdate();

            try (ResultSet prefsResultSet = prefsStmt.getGeneratedKeys()) {
                if (prefsResultSet.next()) {
                    long userPreferencesId = prefsResultSet.getLong(1);
                    strategy.getUserPreferences().setUserPreferencesId(userPreferencesId);

                    strategyStmt.setString(1, strategy.getStrategyName());
                    strategyStmt.setString(2, strategy.getStrategyType().name());
                    strategyStmt.setLong(3, userPreferencesId);
                    strategyStmt.executeUpdate();
                } else {
                    throw new StrategyNotSavedException("Failed to save user preferences, no ID obtained.");
                }
            }
            try (ResultSet strategyResultSet = strategyStmt.getGeneratedKeys()) {
                if (strategyResultSet.next()) {
                    long strategyId = strategyResultSet.getLong(1);
                    strategy.setStrategyId(strategyId);
                } else {
                    throw new StrategyNotSavedException("Failed to save strategy, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new StrategyNotSavedException("Strategy could not be saved.");
        }
    }


    @Override
    public Optional<TradingStrategy> findStrategyByID(long strategyID) throws StrategyNotFoundException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(FIND_BY_ID_SQL)) {

            stmt.setLong(1, strategyID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return Optional.of(createStrategyFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new StrategyNotFoundException("Strategy could not be found");
        }
        return Optional.empty();
    }

    @Override
    public void deleteStrategy(long strategyID) throws StrategyNotDeletedException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(DELETE_SQL)) {

            stmt.setLong(1, strategyID);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new StrategyNotDeletedException("Strategy could not be deleted.");
        }
    }

    @Override
    public List<TradingStrategy> getAllStrategies() throws NoStrategiesFoundException {
        List<TradingStrategy> strategies = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(GET_ALL_SQL)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                strategies.add(createStrategyFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new NoStrategiesFoundException("Could not find any strategies.");
        }
        return strategies;
    }

    @Override
    public Optional<TradingStrategy> findStrategyByName(String strategyName) throws StrategyNotFoundException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(FIND_BY_NAME_SQL)) {

            stmt.setString(1, strategyName);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return Optional.of(createStrategyFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new StrategyNotFoundException("Strategy could not be found.");
        }
        return Optional.empty();
    }

    private TradingStrategy createStrategyFromResultSet(ResultSet rs) throws SQLException {

        TradingStrategy strategy = new TradingStrategy();
        strategy.setStrategyId(rs.getLong("strategy_id"));
        strategy.setStrategyName(rs.getString("strategy_name"));
        strategy.setStrategyType(StrategyType.fromString(rs.getString("strategy_type")));

        UserPreferences prefs = new UserPreferences();
        prefs.setPortfolioAllocationPercentage(rs.getBigDecimal("portfolio_allocation_percentage"));
        prefs.setStopLossPercentage(rs.getBigDecimal("stop_loss_percentage"));
        prefs.setTakeProfitPercentage(rs.getBigDecimal("take_profit_percentage"));
        strategy.setUserPreferences(prefs);

        return strategy;
    }
}

