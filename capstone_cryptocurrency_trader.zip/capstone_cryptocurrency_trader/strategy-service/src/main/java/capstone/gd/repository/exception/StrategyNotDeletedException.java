package capstone.gd.repository.exception;

public class StrategyNotDeletedException extends Exception {
    public StrategyNotDeletedException(String message) {
        super(message);
    }
}
