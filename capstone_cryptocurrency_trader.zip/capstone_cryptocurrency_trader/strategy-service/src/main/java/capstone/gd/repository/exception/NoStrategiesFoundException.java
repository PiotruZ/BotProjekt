package capstone.gd.repository.exception;

public class NoStrategiesFoundException extends Exception {
    public NoStrategiesFoundException(String message) {
        super(message);
    }
}
