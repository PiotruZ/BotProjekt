package capstone.gd.dto;

import capstone.gd.model.CorrelationCoefficient;
import capstone.gd.model.PriceDevationThreshold;
import capstone.gd.model.StockPair;

import java.util.List;

public record StatisticalArbitrageStrategyDTO(long strategyId, String strategyName,
                                              UserPreferencesDTO userPreferencesDTO,
                                              List<StockPair> correlatedStockPairs,
                                              List<CorrelationCoefficient> correlationCoefficients,
                                              PriceDevationThreshold priceDevationThreshold) {
}
