package capstone.gd.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TradingStrategy {
    long strategyId;
    String strategyName;
    StrategyType strategyType;
    UserPreferences userPreferences;

    public TradingStrategy(long strategyId, String strategyName, StrategyType strategyType, UserPreferences userPreferences) {
        this.strategyId = strategyId;
        this.strategyName = strategyName;
        this.strategyType = strategyType;
        this.userPreferences = userPreferences;
    }

    void determineTradeOrder(UserPreferences preferences, EntryExitPoints entryExitPoints) {
    }

    public void setStrategyId(long ID) {
        strategyId = ID;
    }

    public long getStrategyId() {
        return strategyId;
    }
}
