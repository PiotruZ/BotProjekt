package capstone.gd.mapper;

import capstone.gd.dto.MeanReversionStrategyDTO;
import capstone.gd.dto.StatisticalArbitrageStrategyDTO;
import capstone.gd.dto.TrendFollowingStrategyDTO;
import capstone.gd.model.MeanReversionStrategy;
import capstone.gd.model.StatisticalArbitrageStrategy;
import capstone.gd.model.TrendFollowingStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(uses = UserPreferencesMapper.class)

public interface TradingStrategyMapper {

    TradingStrategyMapper INSTANCE = Mappers.getMapper(TradingStrategyMapper.class);

    @Mapping(source = "userPreferences", target = "userPreferencesDTO")
    TrendFollowingStrategyDTO trendFollowingStrategyToDTO(TrendFollowingStrategy strategy);

    @Mappings({
            @Mapping(source = "userPreferencesDTO", target = "userPreferences"),
            @Mapping(target = "strategyType", expression = "java(capstone.gd.model.StrategyType.TREND_FOLLOWING)")
    })
    TrendFollowingStrategy dtoToTrendFollowingStrategy(TrendFollowingStrategyDTO dto);


    @Mapping(source = "userPreferences", target = "userPreferencesDTO")
    MeanReversionStrategyDTO meanReversionStrategyToDTO(MeanReversionStrategy strategy);

    @Mappings({
            @Mapping(source = "userPreferencesDTO", target = "userPreferences"),
            @Mapping(target = "strategyType", expression = "java(capstone.gd.model.StrategyType.MEAN_REVERSION)")
    })
    MeanReversionStrategy dtoToMeanReversionStrategy(MeanReversionStrategyDTO dto);

    @Mapping(source = "userPreferences", target = "userPreferencesDTO")
    StatisticalArbitrageStrategyDTO statisticalArbitrageStrategyToDTO(StatisticalArbitrageStrategy strategy);

    @Mappings({
            @Mapping(source = "userPreferencesDTO", target = "userPreferences"),
            @Mapping(target = "strategyType", expression = "java(capstone.gd.model.StrategyType.STATISTICAL_ARBITRAGE)")
    })
    StatisticalArbitrageStrategy dtoToStatisticalArbitrageStrategy(StatisticalArbitrageStrategyDTO dto);
}
