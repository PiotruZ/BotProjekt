package capstone.gd.model;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class RsiSettings {
    private Integer period;
    private BigDecimal overboughtThreshold;
    private BigDecimal oversoldThreshold;
}
