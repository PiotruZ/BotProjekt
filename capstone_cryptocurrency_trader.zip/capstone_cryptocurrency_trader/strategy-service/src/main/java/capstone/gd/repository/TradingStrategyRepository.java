package capstone.gd.repository;

import capstone.gd.model.TradingStrategy;
import capstone.gd.repository.exception.NoStrategiesFoundException;
import capstone.gd.repository.exception.StrategyNotDeletedException;
import capstone.gd.repository.exception.StrategyNotFoundException;
import capstone.gd.repository.exception.StrategyNotSavedException;

import java.util.List;
import java.util.Optional;

public interface TradingStrategyRepository {
    void saveStrategy(TradingStrategy strategy) throws StrategyNotSavedException;

    Optional<TradingStrategy> findStrategyByID(long strategyID) throws StrategyNotFoundException;

    void deleteStrategy(long StrategyID) throws StrategyNotDeletedException;

    List<TradingStrategy> getAllStrategies() throws NoStrategiesFoundException;

    Optional<TradingStrategy> findStrategyByName(String strategyName) throws StrategyNotFoundException;
}
